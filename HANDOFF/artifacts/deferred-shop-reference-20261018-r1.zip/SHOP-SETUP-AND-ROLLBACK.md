# Per-shop setup, validation and rollback worksheet
Status for BOTH Bankstown and Roselands: DEFERRED / NOT CONNECTED BY THIS PACK.
Complete separately for each shop:
- Legal seller/ABN verified by owner: UNVERIFIED (retain only approved masked evidence here).
- Correct Square account and environment: UNVERIFIED.
- Native shop selection and its own Square location: UNVERIFIED.
- OAuth scopes/expiry and merchant/location ownership: UNVERIFIED; enter credentials only in the authorized service.
- Per-item GST classification/rounding: UNREVIEWED in item-tax-review.csv.
- Prices/options/defaults/min/max/per-location availability: NOT ACCEPTED FOR DESTINATION.
- Square gift-card/loyalty programme and seller-specific rules: NOT ACCEPTED.
- Staff/timecards/permissions and installed shop-specific kitchen devices: NOT ACCEPTED.
- Destination backup, rollback receipt and post-change verification: NOT ACCEPTED.

Routing: catering and large orders use Revesby; ordinary small orders use the chosen connected store. The owner's AUD300 threshold is known, but its accounting basis (discounts, fees, tips, rounding) is still unresolved. Do not implement a new basis or activate destination ordering from this worksheet.

Execution sequence after owner authorizes the deferred connection:
1. Read HANDOFF/2026-10-16-SHOP-REPLICATION-PACK.md and current release gates. Authenticate the intended seller; verify legal entity, environment, location, scopes and device context. Do not connect or select another shop as a fallback.
2. Approve target taxes before selling. Reconcile catalogue-public.json with the current Revesby provider source and destination data. The public available flag is not destination inventory.
3. Use the existing Square Accounts Preview: copy Revesby menu here. Preserve the preview/hash/counts/warnings. Resolve excluded features, tax warnings and all item/variation/modifier mappings before a separately approved apply.
4. Apply only the approved unchanged plan. Preserve phase-one/phase-two mappings and errors. On interruption, read back actual destination state; do not assume all-or-nothing execution or automatically delete provider objects.
5. Validate wrong/missing/revoked account/location denial, seller-scoped payment/order/retry/refund/reporting, exact pickup promise/preparation timing, loyalty/gift-card rules, staff role boundaries and actual KDS receipt. Synthetic checks are not provider acceptance.

Rollback boundaries:
- Website rollback requires its fresh verified backup/restore and independent snippet/configuration evidence; never upload an older package as the current candidate.
- Turn off the affected shop's ordering/payments through the approved control if required; do not reroute an already-paid order to another merchant.
- Catalogue copy is not reversible by deleting all destination items. Preserve original IDs/versioned provider readback and perform only an owner-approved reconciliation. Do not revoke accounts, issue refunds, remove staff or alter device configuration automatically.
- Re-read merchant/environment/location and catalogue state after any approved change. Record verified/unverified/failed per requirement and keep the other store's acceptance separate.
