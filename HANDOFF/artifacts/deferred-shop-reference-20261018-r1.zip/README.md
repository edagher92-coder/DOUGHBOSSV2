# Deferred-shop catalogue reference — NOT an account configuration or Square import
This pack preserves the public website menu and a review worksheet for Bankstown and Roselands, whose connections remain deferred. It contains no access tokens, credentials, customer/staff data, Square object IDs or active merchant configuration.

Source/runtime commit: 9f37ccf77670b0175049e02c9896f28912f7488c. Canonical handoff baseline: 2cdc65e148f5b1de8ab7120324721e6734d0260d, codex/2.51-handoff-20261016. Native R18 passed 3593/3593 synthetic WordPress/MySQL assertions and 239 installed runtime byte checks. These facts are not private-restore, provider or production acceptance.

catalogue-public.json is a timestamped public website reference, not a Square export or directly importable API payload. Preserve displayed AUD prices; the owner's GST-inclusive-price instruction is not per-item tax classification. Every row in item-tax-review.csv remains UNREVIEWED. Do not add GST on top or assume every item is taxable.
Descriptions/dietary text are copied reference content, not new ingredient, allergen, religious or dietary certification. Image URLs can be branded fallback tiles; media binaries and current live-media byte parity are not included. Versioned candidate source retains its own images, but that does not attest to the live URL bytes.

The existing Square Accounts workflow previews a copy from the connected Revesby Square catalogue, not from this JSON. Copying is add-missing only, two-phase and can partially succeed. It excludes images, inventory, item options, per-location price overrides, custom attributes and tax objects. Target taxes need their own approved configuration; matching name/rate is not legal tax approval.
Never reuse Revesby merchant IDs, tokens, groups, staff/payroll records or device assignments in another seller. Never claim cross-seller loyalty/gift-card redemption without product/account acceptance.

Before any release: complete private-backup restore/boot, fresh production backup/rollback and whole-installed-tree reconciliation. The accepted local package pair is recorded in manifest.json; these archives are not included here and have not been deployed. Keep orders/payments/Ads off until their separate gates pass.

Offline integrity: manifest.json lists every other member's size and SHA-256. Validate the exact complete inventory and each digest. The manifest does not self-attest provider correctness. The capture script is not included and no file auto-runs when this pack is extracted. Do not put secrets into the review worksheet.
