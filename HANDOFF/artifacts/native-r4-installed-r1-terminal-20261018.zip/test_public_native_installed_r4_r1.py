"""Focused, host-only source checks for the public installed R4 candidate."""

import ast
import hashlib
import os
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
PROFILE = "public_native_installed_r4_profile_r1.py"
EXECUTOR = "public_native_installed_r4_executor_r1.py"
CALLER = "run_public_native_installed_r4_r1.py"
FROZEN = "public_installed_boot_probe_executor_r2.py"
SOURCE = "public_linux_admission_r4.py"


def load_profile():
    path = HERE / PROFILE
    namespace = {"__name__": "profile_source_test", "__file__": str(path)}
    exec(compile(path.read_bytes(), str(path), "exec", dont_inherit=True), namespace)
    return namespace


class ProfileSourceTests(unittest.TestCase):
    def setUp(self):
        self.p = load_profile()
        self.source = (HERE / SOURCE).read_bytes()

    def test_frozen_public_source_pin_and_wire_budget(self):
        self.assertEqual(len(self.source), self.p["ADMISSION_SOURCE_BYTES"])
        self.assertEqual(hashlib.sha256(self.source).hexdigest(), self.p["ADMISSION_SOURCE_SHA256"])
        command = self.p["wire_command"](self.source)
        self.assertLessEqual(len(command.encode("ascii")), 7000)
        self.assertIn("base64 -d | gzip -d", command)
        raw = self.p["render_guest_bootstrap"](self.source)
        self.assertIn(b"source_wire", raw)
        self.assertIn(b"python3 -I -S -B /run/public-native-r4/public_linux_admission_r4.py", raw)
        self.assertIn(b"python3 -B -m unittest -q", raw)
        self.assertIn(b"python3 -B test_native_admission_binding_r2.py --linux-io", raw)
        self.assertNotIn(b"python3 -I -S -B -m unittest", raw)
        self.assertIn(b"PUBLIC_NATIVE_R4_TESTS=$tests", raw)
        self.assertIn(b"PUBLIC_NATIVE_R4_IO=$io", raw)
        self.assertIn(b"post_inventory", raw)
        self.assertIn(b"post_process", raw)
        self.assertIn(b"grep -qx 'OK'", raw)
        self.assertIn(b"io_rows=$(grep -c", raw)
        self.assertNotIn(b"tar -xf", raw)
        manifest = self.p["render_manifest"](HERE)
        self.assertIs(manifest["installed_boot_acceptance"], False)
        self.assertIs(manifest["restore_acceptance"], False)
        self.assertLess(len(self.p["compressed_bootstrap"](self.source)), len(raw))

    def test_wire_refuses_wrong_public_source(self):
        for invalid in (b"", self.source[:-1], self.source + b"x", "not-bytes"):
            with self.subTest(kind=type(invalid).__name__):
                with self.assertRaises(self.p["Stop"]):
                    self.p["wire_command"](invalid)

    def test_exact_two_disk_installed_topology(self):
        argv = self.p["qemu_argv"](HERE)
        self.assertEqual(argv.count("-drive"), 2)
        self.assertIn("-nodefaults", argv)
        self.assertIn("-nic", argv); self.assertEqual(argv[argv.index("-nic") + 1], "none")
        self.assertIn("-kernel", argv); self.assertIn("-initrd", argv)
        self.assertTrue(any("readonly=on" in value and "native-admission-public-r4.tar" in value for value in argv))
        self.assertTrue(any("public-native-installed-r4-r1-overlay.qcow2" in value for value in argv))
        self.assertFalse(any(".iso" in value or "-cdrom" == value for value in argv))
        self.p["validate_argv"](argv, HERE)
        with self.assertRaises(self.p["Stop"]): self.p["validate_argv"](argv[:-1], HERE)

    def test_closed_success_markers_reject_forged_or_duplicate_success(self):
        parse = self.p["parse_serial"]
        good = (b"Ran 81 tests in 0.001s\nOK\n"
                b'{"admission_bound": false, "checks_passed": 9, "format": "NATIVE_ADMISSION_PUBLIC_IO_R2", "last_check": "ROOT_RESTORED", "pass": true, "preparation_executed": false, "private_input_opened": false}\n'
                b"PUBLIC_NATIVE_R4_TESTS=81\nPUBLIC_NATIVE_R4_IO=9\nPUBLIC_NATIVE_R4_ROOT=ROOT_RESTORED\nPUBLIC_NATIVE_R4_EXIT=0\nPUBLIC_NATIVE_R4_STATUS=OK\n")
        self.assertIsNone(parse(good))
        for bad in (good.replace(b"=81", b"=80"), good + b"PUBLIC_NATIVE_R4_STATUS=OK\n",
                    good + b"PUBLIC_NATIVE_R4_CHECK_FAIL=forged\n", good.replace(b"STATUS=OK", b"STATUS=FAIL"),
                    good.replace(b'"checks_passed": 9', b'"checks_passed": 8'),
                    good.replace(b"Ran 81 tests", b"Ran 80 tests")):
            with self.subTest(bad=bad[-32:]):
                with self.assertRaises(self.p["Stop"]): parse(bad)


class CandidateSourceTests(unittest.TestCase):
    def sources(self):
        return {name: (HERE / name).read_bytes() for name in (PROFILE, EXECUTOR, CALLER)}

    def test_source_bytes_are_parseable_and_do_not_create_bytecode(self):
        before = {p.name for p in HERE.glob("__pycache__/*.pyc")}
        for name, data in self.sources().items():
            with self.subTest(name=name): ast.parse(data, filename=name)
        after = {p.name for p in HERE.glob("__pycache__/*.pyc")}
        self.assertEqual(after, before)

    def test_import_and_cli_are_inert(self):
        for name in (PROFILE, EXECUTOR):
            tree = ast.parse((HERE / name).read_text(encoding="utf-8"), filename=name)
            calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                     and isinstance(node.func, ast.Attribute) and node.func.attr == "Popen"]
            self.assertTrue(calls if name == EXECUTOR else not calls)
        namespace = {"__name__": "caller_source_test", "__file__": str(HERE / CALLER)}
        exec(compile((HERE / CALLER).read_bytes(), str(HERE / CALLER), "exec", dont_inherit=True), namespace)
        old_argv = sys.argv
        try:
            sys.argv = [str(HERE / CALLER)]
            with self.assertRaisesRegex(SystemExit, "NOT_ADMITTED"):
                namespace["main"]()
        finally:
            sys.argv = old_argv

    def test_executor_reuses_frozen_helpers_and_local_serial_seam(self):
        text = (HERE / EXECUTOR).read_text(encoding="utf-8")
        self.assertIn("import public_installed_boot_probe_executor_r2 as frozen", text)
        for helper in ("_digest = frozen._digest", "_verify_inputs = frozen._verify_inputs",
                       "_exclusive = frozen._exclusive", "_artifact_identity = frozen._artifact_identity",
                       "_owned_process = frozen._owned_process"):
            self.assertIn(helper, text)
        self.assertIn('FROZEN_PROBE = "public_installed_boot_probe_r1.py"', text)
        self.assertIn('FROZEN_GUARD = "public_installed_boot_image_guard_r1.py"', text)
        self.assertIn("PUBLIC_NATIVE_R4_READY", text)
        self.assertIn("profile.wire_command(admission_source)", text)
        self.assertIn("range(0, len(command), PROFILE[\"write_bytes\"])", text)
        self.assertIn("PROFILE[\"write_interval\"]", text)
        self.assertIn("profile.parse_serial(bytes(serial))", text)
        for gate in ("def _inspect_chain", "frozen.guard.validate_backing_chain", "def _image_check",
                     "pre_chain = _inspect_chain", "post_chain = _inspect_chain", "_image_check(root, profile.BASE"):
            self.assertIn(gate, text)

    def test_caller_is_bound_and_does_not_admit_absent_plan(self):
        text = (HERE / CALLER).read_text(encoding="utf-8")
        for token in ("require_interpreter()", "read_bound(root,PLAN,sys.argv[1])",
                      "len(rows) != 3385", "not_profile_dependencies", "load_verified(root,sources)",
                      "PUBLIC_NATIVE_INSTALLED_R4_OPERATION_START"):
            self.assertIn(token, text)
        self.assertNotIn("subprocess", text)
        self.assertFalse((HERE / "PUBLIC-NATIVE-INSTALLED-R4-R1-OPERATION.json").exists())


if __name__ == "__main__":
    unittest.main()
