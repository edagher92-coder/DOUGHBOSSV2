"""Hash-bound executor for the public installed-kernel R4 source candidate.

The only operation seam is ``execute``. Import and CLI are inert; an exact,
separately approved plan must construct ``Admission`` before any child exists.
"""

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import time

import public_native_installed_r4_profile_r1 as profile
import public_installed_boot_probe_executor_r2 as frozen

MIB = 1024 * 1024
EXECUTOR = "public_native_installed_r4_executor_r1.py"
PROFILE_MODULE = "public_native_installed_r4_profile_r1.py"
FROZEN_HELPER = "public_installed_boot_probe_executor_r2.py"
FROZEN_PROBE = "public_installed_boot_probe_r1.py"
FROZEN_GUARD = "public_installed_boot_image_guard_r1.py"
PROFILE = {"mode": profile.MODE, "public_only": True, "restore_acceptance": False,
           "private_backup_attached": False, "seconds": 600, "log_bytes": 4 * MIB,
           "write_bytes": 4, "write_interval": .2, "cleanup_seconds": 3,
           "support_closure": "ROOT_REVIEWED_PUBLIC_TOOL_CLOSURE"}
PROFILE_SHA256 = hashlib.sha256(json.dumps(PROFILE, sort_keys=True).encode("ascii")).hexdigest()
REQUIRED = (EXECUTOR, PROFILE_MODULE, FROZEN_HELPER, FROZEN_PROBE, FROZEN_GUARD, profile.BASE, profile.KERNEL,
            profile.INITRAMFS, profile.TOOL, profile.IMAGE_TOOL, profile.PACK,
            profile.MANIFEST, profile.ADMISSION_SOURCE, profile.BOOT_RECEIPT)
APPROVAL = "ROOT_APPROVED_PUBLIC_NATIVE_INSTALLED_R4_ONLY"
TERMINAL_HANDSHAKE = b"exec /bin/sh -c 'while IFS= read -r l; do eval \"$l\"; done'\n"
READY_MARKER = b"PUBLIC_NATIVE_R4_READY"
READY_COMMAND = b"printf 'PUBLIC_NATIVE_R4_READY\\n'\n"

Pin = frozen.Pin


@dataclass(frozen=True)
class Admission:
    root: str
    executor_sha256: str
    profile_module_sha256: str
    frozen_helper_sha256: str
    profile_sha256: str
    pins: tuple[Pin, ...]
    approval: str
    public_tool_closure_reviewed: bool


def _safe_path(root, name, *, exists=True):
    if type(name) is not str or not name or "\\" in name or "\0" in name or ":" in name:
        raise profile.Stop("PATH")
    parts = PurePosixPath(name).parts
    if not parts or any(part in ("", ".", "..") for part in parts):
        raise profile.Stop("PATH")
    root = profile._root(root)
    path = root.joinpath(*parts)
    if path.parent != root and root not in path.parents:
        raise profile.Stop("PATH")
    if exists and not os.path.lexists(path):
        raise profile.Stop("PATH")
    return path


# Frozen generic file/identity/process helpers are deliberately imported rather
# than duplicated. The operation-specific profile, serial markers and result
# parser remain local to this executor.
_digest = frozen._digest
_verify_inputs = frozen._verify_inputs
_exclusive = frozen._exclusive
_artifact_identity = frozen._artifact_identity
_owned_process = frozen._owned_process


def _admit(root, admission):
    root = profile._root(root)
    if (type(admission) is not Admission or admission.root != str(root)
            or admission.approval != APPROVAL or admission.profile_sha256 != PROFILE_SHA256
            or admission.public_tool_closure_reviewed is not True or type(admission.pins) is not tuple):
        raise profile.Stop("NOT_ADMITTED")
    pins = {}
    for pin in admission.pins:
        if (type(pin) is not Pin or pin.name in pins or type(pin.size) is not int or pin.size < 0
                or type(pin.sha256) is not str or re.fullmatch(r"[0-9a-f]{64}", pin.sha256) is None):
            raise profile.Stop("ADMISSION_PIN_SCHEMA")
        _safe_path(root, pin.name)
        if pin.name not in REQUIRED and not pin.name.startswith("qemu-test-tools/"):
            raise profile.Stop("ADMISSION_PIN_SCOPE")
        pins[pin.name] = pin
    if not set(REQUIRED).issubset(pins):
        raise profile.Stop("ADMISSION_PINS_MISSING")
    if (pins[EXECUTOR].sha256 != admission.executor_sha256
            or pins[PROFILE_MODULE].sha256 != admission.profile_module_sha256
            or pins[FROZEN_HELPER].sha256 != admission.frozen_helper_sha256):
        raise profile.Stop("ADMISSION_CODE_BINDING")
    if (Path(__file__).absolute() != _safe_path(root, EXECUTOR)
            or Path(profile.__file__).absolute() != _safe_path(root, PROFILE_MODULE)
            or Path(frozen.__file__).absolute() != _safe_path(root, FROZEN_HELPER)):
        raise profile.Stop("ADMISSION_MODULE_LOCATION")
    for name, (size, digest) in profile.INPUT_PINS.items():
        pin = pins.get(name)
        if pin is None or pin.sha256 != digest or (size is not None and pin.size != size):
            raise profile.Stop("PROFILE_INPUT_PIN:" + name)
    for name in profile.OUTPUT_NAMES:
        if os.path.lexists(_safe_path(root, name, exists=False)):
            raise profile.Stop("STALE_OUTPUT")
    return root, pins


def _verify_local_inputs(root, pins, previous=None):
    snapshots = {}
    for name, pin in pins.items():
        identity, digest = _digest(_safe_path(root, name))
        if identity[2] != pin.size or digest != pin.sha256 or (pin.mtime_ns is not None and identity[3] != pin.mtime_ns):
            raise profile.Stop("INPUT_PIN:" + name)
        if previous is not None and previous.get(name) != identity:
            raise profile.Stop("INPUT_IDENTITY:" + name)
        snapshots[name] = identity
    return snapshots


def _create_overlay(root):
    with _exclusive(root, profile.OVERLAY) as output:
        before = frozen._identity(os.fstat(output.fileno()))
        if before[2] != 0:
            raise profile.Stop("OVERLAY_RESERVATION")
        output.flush(); os.fsync(output.fileno())
    frozen._owned_process(profile.overlay_create_argv(root), 120, 4 * MIB)
    after = frozen._identity(frozen._plain_file_info(_safe_path(root, profile.OVERLAY)))
    if after[:2] != before[:2] or after[2] <= 0:
        raise profile.Stop("OVERLAY_RESERVATION")
    return after


def _image_info_argv(root):
    return [str(_safe_path(root, profile.IMAGE_TOOL)), "info", "--output=json", "--backing-chain",
            str(_safe_path(root, profile.OVERLAY))]


def _inspect_chain(root, overlay_identity):
    overlay = _artifact_identity(root, profile.OVERLAY, overlay_identity)
    before = frozen._identity(frozen._plain_file_info(overlay))
    raw = frozen._owned_process(_image_info_argv(root), 120, 4 * MIB)
    if frozen._identity(frozen._plain_file_info(overlay)) != before:
        raise profile.Stop("IMAGE_CHAIN_IDENTITY")
    try:
        decoded = json.loads(raw.decode("ascii"))
        frozen.guard.validate_backing_chain(decoded, str(overlay), str(_safe_path(root, profile.BASE)))
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
        raise profile.Stop("IMAGE_CHAIN")
    return before


def _image_check(root, name, identity=None):
    path = _safe_path(root, name)
    before = frozen._identity(frozen._plain_file_info(path))
    if identity is not None and before[:2] != identity[:2]:
        raise profile.Stop("IMAGE_CHECK_IDENTITY")
    raw = frozen._owned_process([str(_safe_path(root, profile.IMAGE_TOOL)), "check", "--output=json", str(path)],
                                120, 4 * MIB)
    if frozen._identity(frozen._plain_file_info(path)) != before:
        raise profile.Stop("IMAGE_CHECK_IDENTITY")
    try:
        report = json.loads(raw.decode("ascii"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise profile.Stop("IMAGE_CHECK_JSON")
    if (type(report) is not dict or type(report.get("check-errors")) is not int
            or report["check-errors"] != 0 or report.get("corruptions", 0) != 0):
        raise profile.Stop("IMAGE_CHECK")
    return before


def _run(root, log, admission_source):
    """The frozen 4-byte/.2s echoed serial handshake, with local R4 payload."""
    argv = profile.qemu_argv(root); profile.validate_argv(argv, root)
    env = {key: os.environ[key] for key in ("SystemRoot", "WINDIR") if key in os.environ}
    child = subprocess.Popen(argv, cwd=root, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, bufsize=0, shell=False, close_fds=True)
    owner_pid, owner_args = child.pid, tuple(child.args); serial = bytearray(); eof = False; last_write = None
    deadline = time.monotonic() + PROFILE["seconds"]
    def owned():
        if child.pid != owner_pid or tuple(child.args) != owner_args: raise profile.Stop("PROCESS_IDENTITY")
    def pump():
        nonlocal eof
        owned()
        if time.monotonic() >= deadline: raise profile.Stop("TIMEOUT")
        try: block = os.read(child.stdout.fileno(), 4096)
        except BlockingIOError: block = None
        if block == b"": eof = True
        if block:
            if len(serial) + len(block) > PROFILE["log_bytes"]: raise profile.Stop("LOG_OVERFLOW")
            serial.extend(block)
            if log.write(block) != len(block): raise profile.Stop("LOG_WRITE")
            log.flush()
    def send(command, barrier=None):
        nonlocal last_write
        owned()
        if child.poll() is not None: raise profile.Stop("PROCESS_EARLY_EXIT")
        for offset in range(0, len(command), PROFILE["write_bytes"]):
            while last_write is not None and time.monotonic() - last_write < PROFILE["write_interval"]:
                pump(); time.sleep(.02)
            pump()
            if child.poll() is not None: raise profile.Stop("PROCESS_EARLY_EXIT")
            if offset == 0 and barrier is not None and barrier() is not True: raise profile.Stop("TERMINAL_HANDSHAKE")
            block = command[offset:offset + PROFILE["write_bytes"]]
            if child.stdin.write(block) != len(block): raise profile.Stop("SERIAL_WRITE")
            child.stdin.flush(); last_write = time.monotonic()
    def wait_for(predicate, allow_exit=False):
        while not predicate():
            pump()
            if not allow_exit and child.poll() is not None: raise profile.Stop("PROCESS_EARLY_EXIT")
            if eof and not predicate() and not allow_exit: raise profile.Stop("SERIAL_EOF")
            time.sleep(.02)
    def echo(command, start):
        wait_for(lambda: b"\n" in bytes(serial[start:]).replace(b"\r", b""))
        actual = bytes(serial[start:]).replace(b"\r", b"").split(b"\n", 1)[0] + b"\n"
        if actual != command.replace(b"\r", b""): raise profile.Stop("SERIAL_ECHO")
    def prompt():
        return re.search(rb"(?:^|\n)[^\r\n\x1b]*[~/:]# (?:\x1b\[6n)?$", bytes(serial)) is not None
    try:
        os.set_blocking(child.stdout.fileno(), False); wait_for(lambda: bytes(serial).endswith(b"login: "))
        start=len(serial); send(b"root\n"); echo(b"root\n", start); wait_for(prompt)
        start=len(serial); send(TERMINAL_HANDSHAKE); echo(TERMINAL_HANDSHAKE, start); end=start+bytes(serial[start:]).index(b"\n")+1
        def clean_exec():
            if bytes(serial[end:]): raise profile.Stop("TERMINAL_HANDSHAKE")
            return True
        start=len(serial); send(READY_COMMAND, clean_exec); echo(READY_COMMAND, start); ready=start+bytes(serial[start:]).index(b"\n")+1
        def ready_barrier():
            tail=bytes(serial[ready:]).replace(b"\r", b""); expected=READY_MARKER+b"\n"
            if not expected.startswith(tail): raise profile.Stop("TERMINAL_HANDSHAKE")
            return tail == expected
        wait_for(ready_barrier); start=len(serial); command=profile.wire_command(admission_source).encode("ascii")+b"\n"
        send(command, ready_barrier); echo(command, start); wait_for(lambda: child.poll() is not None and eof, True)
        if child.wait(timeout=PROFILE["cleanup_seconds"]) != 0: raise profile.Stop("QEMU_EXIT")
        profile.parse_serial(bytes(serial)); return bytes(serial), 0
    finally:
        if child.poll() is None:
            child.terminate()
            try: child.wait(timeout=PROFILE["cleanup_seconds"])
            except subprocess.TimeoutExpired: child.kill(); child.wait(timeout=PROFILE["cleanup_seconds"])
        child.stdin.close(); child.stdout.close()
        if child.poll() is None: raise profile.Stop("PROCESS_NOT_CLOSED")


def execute(root, admission=None):
    root, pins = _admit(root, admission); pre = _verify_local_inputs(root, pins)
    admission_source = _safe_path(root, profile.ADMISSION_SOURCE).read_bytes()
    profile._checked_admission_source(admission_source)
    base_pre = _image_check(root, profile.BASE)
    overlay = _create_overlay(root)
    pre_chain = _inspect_chain(root, overlay)
    with _exclusive(root, profile.SERIAL_LOG) as log:
        serial, exit_code = _run(root, log, admission_source); log.flush(); os.fsync(log.fileno())
    post_chain = _inspect_chain(root, overlay)
    _image_check(root, profile.BASE, base_pre)
    _image_check(root, profile.OVERLAY, overlay)
    post = _verify_local_inputs(root, pins, pre)
    result = {"format": "PUBLIC_NATIVE_INSTALLED_R4_RESULT", "status": "PUBLIC_NATIVE_INSTALLED_R4_OK",
              "public_only": True, "restore_acceptance": False, "private_backup_attached": False,
              "clean_closeout": exit_code == 0, "pre_pins_verified": bool(pre), "post_pins_verified": bool(post),
              "pre_chain_verified": bool(pre_chain), "post_chain_verified": bool(post_chain),
              "serial_bytes": len(serial), "tests": 81, "io_checks": 9, "root": "ROOT_RESTORED"}
    with _exclusive(root, profile.RESULT) as output:
        payload = json.dumps(result, sort_keys=True, separators=(",", ":")).encode("ascii")
        if output.write(payload) != len(payload): raise profile.Stop("RESULT_WRITE")
        output.flush(); os.fsync(output.fileno())
    return result


if __name__ == "__main__":
    raise SystemExit("NOT_ADMITTED: executor import only")
