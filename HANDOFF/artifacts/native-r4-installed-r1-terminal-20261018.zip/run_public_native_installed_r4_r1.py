"""Exact-plan caller for the inert public installed-kernel R4 executor.

It intentionally cannot execute without a root-reviewed plan whose hash is
given on the command line.  It dynamically loads only byte-pinned local source
and leaves no imported candidate module cached after returning.
"""

PLAN = "PUBLIC-NATIVE-INSTALLED-R4-R1-OPERATION.json"
CALLER = "run_public_native_installed_r4_r1.py"
PROFILE_MODULE = "public_native_installed_r4_profile_r1.py"
EXECUTOR = "public_native_installed_r4_executor_r1.py"
FROZEN_HELPER = "public_installed_boot_probe_executor_r2.py"
FROZEN_PROBE = "public_installed_boot_probe_r1.py"
FROZEN_GUARD = "public_installed_boot_image_guard_r1.py"
ACTUAL = "qemu-test-tools"


def require_interpreter():
    import sys
    if not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode):
        raise SystemExit("NOT_ADMITTED: interpreter requires -I -S -B")


def _is_reparse(info):
    return bool(getattr(info, "st_file_attributes", 0) & 0x400)


def checked_root(root):
    import os, stat
    root = root.absolute(); info = os.lstat(root)
    if not root.is_absolute() or _is_reparse(info) or not stat.S_ISDIR(info.st_mode):
        raise RuntimeError("ROOT_NOT_PLAIN_DIRECTORY")
    return root


def checked_file(root, name):
    import os, stat
    if (type(name) is not str or not name or "/" in name or "\\" in name or ":" in name
            or "\0" in name or name in (".", "..")):
        raise RuntimeError("BOUND_PATH")
    path = root / name; info = os.lstat(path)
    if _is_reparse(info) or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise RuntimeError("BOUND_FILE_IDENTITY")
    return path


def read_bound(root, name, expected_sha256):
    import hashlib, os, re
    if type(expected_sha256) is not str or re.fullmatch(r"[0-9a-f]{64}", expected_sha256) is None:
        raise RuntimeError("BOUND_HASH")
    path = checked_file(root, name); before = os.stat(path)
    identity = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
    if before.st_size > 16 * 1024 * 1024: raise RuntimeError("BOUND_SIZE")
    with open(path, "rb") as source:
        if (lambda i:(i.st_dev,i.st_ino,i.st_size,i.st_mtime_ns))(os.fstat(source.fileno())) != identity:
            raise RuntimeError("BOUND_IDENTITY")
        data = source.read(16 * 1024 * 1024 + 1)
        if len(data) != before.st_size: raise RuntimeError("BOUND_SIZE")
        if (lambda i:(i.st_dev,i.st_ino,i.st_size,i.st_mtime_ns))(os.fstat(source.fileno())) != identity:
            raise RuntimeError("BOUND_IDENTITY")
    after = os.stat(path)
    if (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns) != identity: raise RuntimeError("BOUND_IDENTITY")
    if hashlib.sha256(data).hexdigest() != expected_sha256: raise RuntimeError("BOUND_HASH")
    return data


def public_files(root, exclusions):
    import os, stat
    if type(exclusions) is not tuple or any(type(name) is not str for name in exclusions):
        raise RuntimeError("EXCLUSION_SCHEMA")
    base = root / ACTUAL; info = os.lstat(base)
    if _is_reparse(info) or not stat.S_ISDIR(info.st_mode): raise RuntimeError("TOOL_ROOT_NOT_PLAIN_DIRECTORY")
    found = []
    def walk_error(error):
        raise error
    for directory, dirs, files in os.walk(base, followlinks=False, onerror=walk_error):
        for name in dirs:
            info=os.lstat(type(root)(directory)/name)
            if _is_reparse(info) or not stat.S_ISDIR(info.st_mode): raise RuntimeError("TOOL_DIRECTORY_IDENTITY")
        for name in files:
            path=type(root)(directory)/name; info=os.lstat(path)
            if _is_reparse(info) or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1: raise RuntimeError("TOOL_FILE_IDENTITY")
            relative=path.relative_to(root).as_posix()
            if relative not in exclusions: found.append(relative)
    return tuple(sorted(found))


def load_verified(root, sources):
    import sys, types
    # The frozen helper first supplies its original module name; candidate
    # profile/executor are then loaded only from the byte-bound mapping.
    order = (FROZEN_PROBE[:-3], FROZEN_GUARD[:-3], FROZEN_HELPER[:-3], PROFILE_MODULE[:-3], EXECUTOR[:-3])
    if any(name in sys.modules for name in order): raise RuntimeError("LOCAL_MODULE_PRELOADED")
    loaded=[]
    try:
        for name in order:
            code=compile(sources[name+".py"], str(root/(name+".py")), "exec", dont_inherit=True)
            module=types.ModuleType(name); module.__file__=str(root/(name+".py")); module.__package__=""
            sys.modules[name]=module; loaded.append(module); exec(code,module.__dict__)
        return tuple(loaded)
    except BaseException:
        for module in loaded:
            if sys.modules.get(module.__name__) is module: del sys.modules[module.__name__]
        raise


def main():
    import json, pathlib, sys
    require_interpreter()
    if len(sys.argv) != 2: raise SystemExit("NOT_ADMITTED: exact operation-plan SHA-256 required")
    root=checked_root(pathlib.Path.cwd()); plan_bytes=read_bound(root,PLAN,sys.argv[1])
    try: plan=json.loads(plan_bytes.decode("ascii"))
    except (UnicodeDecodeError,json.JSONDecodeError): raise RuntimeError("PLAN_SCHEMA")
    if (type(plan) is not dict or plan.get("operation_admission") != "OPERATION_ADMITTED_PUBLIC_ONLY"
            or plan.get("independent_operation_review") != "SHIP" or plan.get("public_only") is not True
            or plan.get("private_backup") is not False or plan.get("one_attempt_only") is not True
            or plan.get("root") != str(root)):
        raise RuntimeError("NOT_ADMITTED")
    expected={CALLER,PROFILE_MODULE,EXECUTOR,FROZEN_HELPER,FROZEN_PROBE,FROZEN_GUARD}; files=plan.get("files")
    if type(files) is not dict or set(files) != expected: raise RuntimeError("BOUND_FILES_SCHEMA")
    sources={name:read_bound(root,name,digest) for name,digest in files.items()}
    if pathlib.Path(__file__).absolute()!=checked_file(root,CALLER): raise RuntimeError("CALLER_LOCATION")
    _, _, frozen, profile, executor = load_verified(root,sources)
    try:
        if (plan.get("mode") != profile.MODE or plan.get("profile_sha256") != executor.PROFILE_SHA256
                or plan.get("overlay_argv") != profile.overlay_create_argv(root)
                or plan.get("qemu_argv") != profile.qemu_argv(root)
                or plan.get("fresh_output_names") != list(profile.OUTPUT_NAMES)):
            raise RuntimeError("PROFILE_PIN")
        profile.validate_argv(plan["qemu_argv"],root)
        closure_name=plan.get("tool_closure_receipt"); closure_sha=plan.get("tool_closure_receipt_sha256")
        closure=json.loads(read_bound(root,closure_name,closure_sha).decode("ascii")); rows=closure.get("pins")
        exclusions=tuple(closure.get("not_profile_dependencies",()))
        if (closure.get("status") != "PUBLIC_TOOL_CLOSURE_MATCHED" or type(rows) is not list or len(rows) != 3385
                or set(exclusions) != {"qemu-test-tools/share/QEMU,cgthree.bin","qemu-test-tools/share/QEMU,tcx.bin"}):
            raise RuntimeError("TOOL_CLOSURE_SCHEMA")
        by_name={}; pins={}
        for row in rows:
            if type(row) is not dict or set(row)!={"name","size","sha256","mtime_ns"} or row["name"] in by_name:
                raise RuntimeError("TOOL_PIN_SCHEMA")
            pin=executor.Pin(row["name"],row["size"],row["sha256"],row["mtime_ns"]); by_name[pin.name]=pin; pins[pin.name]=pin
        if set(public_files(root,exclusions)) != set(by_name)-set(exclusions): raise RuntimeError("TOOL_INVENTORY_DRIFT")
        for name in executor.REQUIRED:
            if name in pins: continue
            path=checked_file(root,name); size=path.stat().st_size
            if name in files: digest=files[name]
            elif name in profile.INPUT_PINS:
                expected_size,digest=profile.INPUT_PINS[name]
                if expected_size is not None and size != expected_size: raise RuntimeError("PROFILE_INPUT_SIZE")
            else: digest=executor._digest(path)[1]
            pins[name]=executor.Pin(name,size,digest)
        admission=executor.Admission(str(root),files[EXECUTOR],files[PROFILE_MODULE],files[FROZEN_HELPER],
                                     plan["profile_sha256"],tuple(pins.values()),executor.APPROVAL,True)
        print("PUBLIC_NATIVE_INSTALLED_R4_OPERATION_START",flush=True)
        result=executor.execute(root,admission)
        print(json.dumps({key:result.get(key) for key in ("status","clean_closeout","pre_pins_verified","post_pins_verified")},sort_keys=True),flush=True)
        return 0 if result.get("status")=="PUBLIC_NATIVE_INSTALLED_R4_OK" else 1
    finally:
        for module in (executor,profile,frozen):
            if sys.modules.get(module.__name__) is module: del sys.modules[module.__name__]


if __name__ == "__main__":
    raise SystemExit(main())
