import os,stat,hashlib,tarfile,io,json,re
from pathlib import Path
S=358400
H='794ae82f5bcc44f2d058d51f096c7a286fde84ba44191e0dad6c29f0e7d0cbfd'
MH='e9583a98a68c9ea021f8e0a4aa991301188eb2de2837f782de25894c809b51fa'
MN='NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json'
T=Path('/root/public-native-admission-source-r4')
assert os.geteuid()==os.getegid()==0
assert set(os.listdir('/sys/class/net'))=={'lo'}
expected={'vda','vda1','vda2','vdb'}|{'loop'+str(i) for i in range(8)}
assert set(os.listdir('/sys/class/block'))==expected
assert all(not os.path.lexists('/sys/class/block/loop'+str(i)+'/loop/backing_file') for i in range(8))
assert not os.path.lexists('/dev/vdc')
for p in (Path('/'),T.parent):
 s=os.lstat(p)
 assert stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and not s.st_mode&0o022
assert not os.path.lexists(T)
d=os.lstat('/dev/vdb')
assert stat.S_ISBLK(d.st_mode) and d.st_uid==0 and d.st_gid==6 and stat.S_IMODE(d.st_mode)==0o660
K=Path('/sys/class/block/vdb')
assert (K/'ro').read_text().strip()=='1' and (K/'size').read_text().strip()=='700'
assert (K/'dev').read_text().strip()==str(os.major(d.st_rdev))+':'+str(os.minor(d.st_rdev))
with os.fdopen(os.open('/dev/vdb',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC),'rb') as f:
 b=f.read(S+1)
 z=os.fstat(f.fileno())
 assert (z.st_dev,z.st_ino,z.st_rdev)==(d.st_dev,d.st_ino,d.st_rdev)
assert len(b)==S and hashlib.sha256(b).hexdigest()==H
with tarfile.open(fileobj=io.BytesIO(b),mode='r:') as t:
 ms=t.getmembers()
 assert len(ms)==25 and len({m.name for m in ms})==25
 assert all(m.type==tarfile.REGTYPE and m.uid==m.gid==0 and not m.pax_headers and not m.linkname and 0<m.size<=65536 and re.fullmatch(r'[A-Za-z0-9_.-]+',m.name) and not m.mode&0o7000 for m in ms)
 data={m.name:t.extractfile(m).read() for m in ms}
assert hashlib.sha256(data[MN]).hexdigest()==MH
doc=json.loads(data[MN])
assert doc['format']==1 and doc['scope']=='PUBLIC_SYNTHETIC_ONLY_NO_PRIVATE_INPUT'
es=doc['sourceFiles']
assert len(es)==24 and len({e['Path'] for e in es})==24
assert set(data)=={e['Path'] for e in es}|{MN}
for e in es:
 v=data[e['Path']]
 assert len(v)==e['Bytes'] and hashlib.sha256(v).hexdigest().upper()==e['Sha256']
os.mkdir(T,0o700)
fd=os.open(T,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
 os.fchmod(fd,0o700)
 for name,v in data.items():
  with os.fdopen(os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=fd),'wb') as f:
   os.fchmod(f.fileno(),0o600)
   assert f.write(v)==len(v)
   f.flush()
   os.fsync(f.fileno())
 os.fsync(fd)
finally:
 os.close(fd)
s=os.lstat(T)
assert stat.S_ISDIR(s.st_mode) and stat.S_IMODE(s.st_mode)==0o700 and s.st_uid==s.st_gid==0
assert set(os.listdir(T))==set(data)
for name,v in data.items():
 s=os.lstat(T/name)
 assert stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600 and (T/name).read_bytes()==v
print(json.dumps({'format':'NATIVE_ADMISSION_PUBLIC_GUEST_R4','state':'PUBLIC_SOURCE_ADMITTED','regular_files':25,'source_files':24,'private_input_opened':False},sort_keys=True))

