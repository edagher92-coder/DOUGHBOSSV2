"""Synthetic R2 caller checks; never launch QEMU or read a private backup."""

import builtins
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


HERE = Path(__file__).absolute().parent
CALLER = "run_public_installed_boot_probe_r2_20261018.py"
PROFILE = "public_installed_boot_probe_r1.py"
GUARD = "public_installed_boot_image_guard_r1.py"
EXECUTOR = "public_installed_boot_probe_executor_r2.py"


def read_caller(path):
    module = types.ModuleType("synthetic_probe_r2_caller")
    module.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    return module


class CallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="synthetic-public-probe-r2-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).absolute()
        self.module_names = (PROFILE[:-3], GUARD[:-3], EXECUTOR[:-3])
        self.previous = {name: sys.modules.pop(name, None) for name in self.module_names}
        self.addCleanup(self.clean_modules)
        for name in (CALLER, PROFILE, GUARD, EXECUTOR):
            (self.root / name).write_bytes((HERE / name).read_bytes())
        self.caller = read_caller(self.root / CALLER)
        self.sources = {
            name: (self.root / name).read_bytes()
            for name in (PROFILE, GUARD, EXECUTOR)
        }
        self.executions = []
        self.addCleanup(patch.stopall)
        patch("subprocess.Popen", side_effect=AssertionError("CHILD_FORBIDDEN")).start()
        patch("os.system", side_effect=AssertionError("CHILD_FORBIDDEN")).start()

    def clean_modules(self):
        for name, previous in self.previous.items():
            sys.modules.pop(name, None)
            if previous is not None:
                sys.modules[name] = previous

    @staticmethod
    def digest(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def fixture(self, status="PUBLIC_INSTALLED_BOOT_ONLY_OK"):
        profile, guard, executor = self.caller.load_verified(self.root, self.sources)
        for name in executor.REQUIRED:
            path = self.root / name
            if not path.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(("synthetic:" + name).encode("ascii"))

        input_pins = {
            name: ((self.root / name).stat().st_size, self.digest(self.root / name))
            for name in profile.INPUT_PINS
        }
        receipt_hash = self.digest(self.root / profile.R8_RECEIPT)
        profile.INPUT_PINS = input_pins
        profile.R8_RECEIPT_SHA = receipt_hash

        excluded = [
            "qemu-test-tools/share/QEMU,cgthree.bin",
            "qemu-test-tools/share/QEMU,tcx.bin",
        ]
        real_tool_names = [profile.TOOL, profile.IMAGE_TOOL, *excluded]
        rows = []
        for name in real_tool_names:
            path = self.root / name
            if not path.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"synthetic public tool")
            info = path.stat()
            rows.append({"name": name, "size": info.st_size, "sha256": self.digest(path),
                         "mtime_ns": info.st_mtime_ns})
        for number in range(3385 - len(rows)):
            rows.append({"name": f"qemu-test-tools/synthetic-{number}.bin", "size": 0,
                         "sha256": hashlib.sha256(b"").hexdigest(), "mtime_ns": 1})
        closure = {
            "status": "PUBLIC_TOOL_CLOSURE_MATCHED",
            "pins": rows,
            "not_profile_dependencies": excluded,
        }
        closure_raw = json.dumps(closure, sort_keys=True).encode("ascii")
        closure_name = "synthetic-public-tool-closure.json"
        (self.root / closure_name).write_bytes(closure_raw)
        self.inventory = tuple(
            sorted(row["name"] for row in rows if row["name"] not in excluded)
        )
        self.plan = {
            "operation_admission": "OPERATION_ADMITTED_PUBLIC_ONLY",
            "independent_operation_review": "SHIP",
            "public_only": True,
            "private_backup": False,
            "one_attempt_only": True,
            "root": str(self.root),
            "files": {
                name: self.digest(self.root / name)
                for name in (CALLER, PROFILE, GUARD, EXECUTOR)
            },
            "mode": profile.MODE,
            "profile_sha256": executor.PROFILE_SHA256,
            "overlay_argv": profile.overlay_create_argv(self.root),
            "qemu_argv": profile.qemu_argv(self.root),
            "fresh_output_names": list(profile.OUTPUT_NAMES),
            "tool_closure_receipt": closure_name,
            "tool_closure_receipt_sha256": hashlib.sha256(closure_raw).hexdigest(),
        }
        for name in self.module_names:
            sys.modules.pop(name, None)
        original_loader = self.caller.load_verified

        def synthetic_loader(root, sources):
            loaded_profile, loaded_guard, loaded_executor = original_loader(root, sources)
            loaded_profile.INPUT_PINS = input_pins
            loaded_profile.R8_RECEIPT_SHA = receipt_hash

            def fake_execute(actual_root, admission):
                self.executions.append(admission)
                return {
                    "status": status,
                    "clean_closeout": status == "PUBLIC_INSTALLED_BOOT_ONLY_OK",
                    "post_pins_verified": True,
                    "pre_chain_verified": True,
                    "post_chain_verified": True,
                }

            loaded_executor.execute = fake_execute
            return loaded_profile, loaded_guard, loaded_executor

        patch.object(self.caller, "load_verified", side_effect=synthetic_loader).start()
        patch.object(self.caller, "public_files", return_value=self.inventory).start()
        return profile, guard, executor

    def invoke(self, plan=None):
        raw = json.dumps(self.plan if plan is None else plan, sort_keys=True).encode("ascii")
        (self.root / self.caller.PLAN).write_bytes(raw)
        plan_hash = hashlib.sha256(raw).hexdigest()
        previous = Path.cwd()
        try:
            os.chdir(self.root)
            with patch.object(sys, "argv", [CALLER, plan_hash]), \
                    patch.object(self.caller, "require_interpreter"), \
                    contextlib.redirect_stdout(io.StringIO()):
                self.caller.main()
        finally:
            os.chdir(previous)

    def test_import_is_inert_even_when_imports_are_forbidden(self):
        source = (self.root / CALLER).read_bytes()
        with patch.object(builtins, "__import__", side_effect=AssertionError("IMPORT_FORBIDDEN")):
            exec(compile(source, CALLER, "exec"), {"__name__": "inert_import"})

    def test_each_missing_interpreter_flag_stops_before_plan_io(self):
        for missing in ("isolated", "no_site", "dont_write_bytecode"):
            values = {"isolated": 1, "no_site": 1, "dont_write_bytecode": 1}
            values[missing] = 0
            with self.subTest(missing=missing), \
                    patch.object(sys, "flags", types.SimpleNamespace(**values)), \
                    patch.object(self.caller, "read_bound", side_effect=AssertionError("PLAN_IO_FORBIDDEN")):
                with self.assertRaisesRegex(SystemExit, "-I -S -B"):
                    self.caller.main()

    def test_default_cli_has_no_admission_or_io(self):
        with patch.object(sys, "argv", [CALLER]), \
                patch.object(self.caller, "read_bound", side_effect=AssertionError("IO_FORBIDDEN")):
            with self.assertRaisesRegex(SystemExit, "NOT_ADMITTED"):
                self.caller.main()

    def test_wrong_plan_hash_and_source_hash_stop_before_verified_load(self):
        (self.root / self.caller.PLAN).write_bytes(b"{}")
        previous = Path.cwd()
        try:
            os.chdir(self.root)
            with patch.object(sys, "argv", [CALLER, "0" * 64]), \
                    patch.object(self.caller, "require_interpreter"), \
                    patch.object(self.caller, "load_verified", side_effect=AssertionError("EXEC_FORBIDDEN")):
                with self.assertRaisesRegex(RuntimeError, "BOUND_HASH"):
                    self.caller.main()
        finally:
            os.chdir(previous)
        self.fixture()
        self.plan["files"][PROFILE] = "0" * 64
        with patch.object(self.caller, "load_verified", side_effect=AssertionError("EXEC_FORBIDDEN")):
            with self.assertRaisesRegex(RuntimeError, "BOUND_HASH"):
                self.invoke()

    def test_missing_or_private_operation_admission_stops_before_source_execution(self):
        self.fixture()
        for mutation in (
            lambda plan: plan.pop("operation_admission"),
            lambda plan: plan.__setitem__("private_backup", True),
            lambda plan: plan.__setitem__("one_attempt_only", False),
        ):
            plan = dict(self.plan)
            mutation(plan)
            with self.subTest(plan=plan), \
                    patch.object(self.caller, "load_verified", side_effect=AssertionError("EXEC_FORBIDDEN")):
                with self.assertRaisesRegex(RuntimeError, "NOT_ADMITTED"):
                    self.invoke(plan)

    def test_path_escape_and_hardlink_sources_are_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "BOUND_PATH"):
            self.caller.read_bound(self.root, "../outside.py", "0" * 64)
        linked = self.root / "linked.py"
        os.link(self.root / PROFILE, linked)
        with self.assertRaisesRegex(RuntimeError, "BOUND_FILE_IDENTITY"):
            self.caller.read_bound(self.root, PROFILE, self.digest(self.root / PROFILE))

    def test_preloaded_verified_modules_are_not_overwritten(self):
        for name in self.module_names:
            with self.subTest(name=name):
                prior = types.ModuleType(name)
                sys.modules[name] = prior
                with self.assertRaisesRegex(RuntimeError, "LOCAL_MODULE_PRELOADED"):
                    self.caller.load_verified(self.root, self.sources)
                self.assertIs(sys.modules[name], prior)
                del sys.modules[name]

    def test_loader_executes_retained_verified_bytes_and_binds_exact_modules(self):
        (self.root / PROFILE).write_bytes(b"raise AssertionError('UNVERIFIED_REREAD')")
        profile, guard, executor = self.caller.load_verified(self.root, self.sources)
        self.assertEqual(profile.MODE, "PUBLIC_INSTALLED_BOOT_PROBE_R1")
        self.assertIs(executor.probe, profile)
        self.assertIs(executor.guard, guard)
        self.assertEqual(profile.__file__, str(self.root / PROFILE))

    def test_full_caller_uses_frozen_probe_wiring_and_executes_once(self):
        self.fixture()
        with self.assertRaises(SystemExit) as outcome:
            self.invoke()
        self.assertEqual(outcome.exception.code, 0)
        self.assertEqual(len(self.executions), 1)
        admission = self.executions[0]
        self.assertEqual(admission.profile_sha256, self.plan["profile_sha256"])
        self.assertEqual(admission.executor_sha256, self.plan["files"][EXECUTOR])
        self.assertEqual(admission.profile_module_sha256, self.plan["files"][PROFILE])
        self.assertEqual(admission.guard_module_sha256, self.plan["files"][GUARD])
        self.assertTrue(admission.public_tool_closure_reviewed)

    def test_profile_and_closure_mismatch_stop_before_execute(self):
        self.fixture()
        self.plan["profile_sha256"] = "0" * 64
        with self.assertRaisesRegex(RuntimeError, "PROFILE_PIN"):
            self.invoke()
        self.assertEqual(self.executions, [])
        self.fixture()
        closure_path = self.root / self.plan["tool_closure_receipt"]
        closure = json.loads(closure_path.read_text("ascii"))
        closure["pins"] = closure["pins"][:-1]
        raw = json.dumps(closure, sort_keys=True).encode("ascii")
        closure_path.write_bytes(raw)
        self.plan["tool_closure_receipt_sha256"] = hashlib.sha256(raw).hexdigest()
        with self.assertRaisesRegex(RuntimeError, "TOOL_CLOSURE_SCHEMA"):
            self.invoke()
        self.assertEqual(self.executions, [])

    def test_pre_and_post_inventory_drift_cannot_be_reported_as_success(self):
        self.fixture()
        with patch.object(self.caller, "public_files", return_value=self.inventory + ("unexpected.dll",)):
            with self.assertRaisesRegex(RuntimeError, "TOOL_INVENTORY_DRIFT"):
                self.invoke()
        self.assertEqual(self.executions, [])
        self.fixture()
        with patch.object(self.caller, "public_files", side_effect=[self.inventory, self.inventory + ("unexpected.dll",)]):
            with self.assertRaisesRegex(RuntimeError, "TOOL_INVENTORY_DRIFT"):
                self.invoke()
        self.assertEqual(len(self.executions), 1)

    def test_postcheck_does_not_hide_original_operation_exception(self):
        self.fixture()
        loader = self.caller.load_verified.side_effect

        def failing_loader(root, sources):
            profile, guard, executor = loader(root, sources)
            executor.execute = lambda *args: (_ for _ in ()).throw(RuntimeError("original-operation"))
            return profile, guard, executor

        with patch.object(self.caller, "load_verified", side_effect=failing_loader), \
                patch.object(self.caller, "public_files", side_effect=[self.inventory, self.inventory + ("unexpected.dll",)]), \
                contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, "^original-operation$"):
                self.invoke()

    def test_executor_failure_result_exits_nonzero(self):
        self.fixture(status="FAILED")
        with self.assertRaises(SystemExit) as outcome:
            self.invoke()
        self.assertEqual(outcome.exception.code, 1)
        self.assertEqual(len(self.executions), 1)

    def test_public_inventory_rejects_hardlinks_and_reparse_root(self):
        base = self.root / "qemu-test-tools"
        base.mkdir(exist_ok=True)
        one = base / "one.bin"
        one.write_bytes(b"synthetic")
        self.assertEqual(self.caller.public_files(self.root, ()), ("qemu-test-tools/one.bin",))
        os.link(one, base / "two.bin")
        with self.assertRaisesRegex(RuntimeError, "TOOL_FILE_IDENTITY"):
            self.caller.public_files(self.root, ())
        fake = types.SimpleNamespace(st_mode=0o040755, st_file_attributes=0x400)
        with patch("os.lstat", return_value=fake):
            with self.assertRaisesRegex(RuntimeError, "TOOL_ROOT_NOT_PLAIN_DIRECTORY"):
                self.caller.public_files(self.root, ())


if __name__ == "__main__":
    unittest.main()
