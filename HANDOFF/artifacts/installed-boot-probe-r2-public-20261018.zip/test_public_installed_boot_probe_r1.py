"""Synthetic-only direct boot profile checks. Never starts QEMU or creates images."""
import hashlib
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).absolute().parent
SOURCE = HERE / "public_installed_boot_probe_r1.py"
module = types.ModuleType("public_installed_boot_probe_r1")
module.__file__ = str(SOURCE)
sys.modules[module.__name__] = module
with patch("subprocess.Popen", side_effect=AssertionError("NO_CHILD")), \
        patch("os.system", side_effect=AssertionError("NO_CHILD")):
    exec(compile(SOURCE.read_bytes(), str(SOURCE), "exec"), module.__dict__)
Stop = module.Stop
parse_serial = module.parse_serial
GOOD = b"\n".join(expected for _, expected in module.MARKERS) + b"\n"


class TestParseSerial(unittest.TestCase):
    def test_crlf_success(self):
        data = (
            b"boot log line\r\n"
            b"PUBLIC_BOOT_R1_KERNEL=6.18.56-0-virt\r\n"
            b"PUBLIC_BOOT_R1_ROOT=27ef448f-e239-45d8-8401-78b6d8a9cc46\r\n"
            b"PUBLIC_BOOT_R1_RUNTIME=PHP84_PY3_MARIADB_PRESENT\r\n"
            b"PUBLIC_BOOT_R1_STATUS=OK\r\n"
            b"PUBLIC_BOOT_R1_EXIT=0\r\n"
            b"another line\r\n"
        )
        self.assertIsNone(parse_serial(data, Stop))

    def test_check_fail_overrides_success(self):
        data = (
            b"PUBLIC_BOOT_R1_KERNEL=6.18.56-0-virt\r\n"
            b"PUBLIC_BOOT_R1_ROOT=27ef448f-e239-45d8-8401-78b6d8a9cc46\r\n"
            b"PUBLIC_BOOT_R1_RUNTIME=PHP84_PY3_MARIADB_PRESENT\r\n"
            b"PUBLIC_BOOT_R1_STATUS=OK\r\n"
            b"PUBLIC_BOOT_R1_EXIT=0\r\n"
            b"PUBLIC_BOOT_R1_CHECK_FAIL=BAD_LABEL\r\n"
        )
        with self.assertRaises(Stop) as ctx:
            parse_serial(data, Stop)
        self.assertEqual(str(ctx.exception), "SERIAL_CHECK_FAIL:BAD_LABEL")

    def test_duplicate_prefix_value(self):
        data = (
            b"PUBLIC_BOOT_R1_KERNEL=6.18.56-0-virt\r\n"
            b"PUBLIC_BOOT_R1_KERNEL=6.18.56-0-virt\r\n"
            b"PUBLIC_BOOT_R1_ROOT=27ef448f-e239-45d8-8401-78b6d8a9cc46\r\n"
            b"PUBLIC_BOOT_R1_RUNTIME=PHP84_PY3_MARIADB_PRESENT\r\n"
            b"PUBLIC_BOOT_R1_STATUS=OK\r\n"
            b"PUBLIC_BOOT_R1_EXIT=0\r\n"
        )
        with self.assertRaises(Stop) as ctx:
            parse_serial(data, Stop)
        self.assertEqual(str(ctx.exception), "SERIAL_STATUS")

    def test_order_and_bounds(self):
        data = (
            b"PUBLIC_BOOT_R1_ROOT=27ef448f-e239-45d8-8401-78b6d8a9cc46\r\n"
            b"PUBLIC_BOOT_R1_KERNEL=6.18.56-0-virt\r\n"
            b"PUBLIC_BOOT_R1_RUNTIME=PHP84_PY3_MARIADB_PRESENT\r\n"
            b"PUBLIC_BOOT_R1_STATUS=OK\r\n"
            b"PUBLIC_BOOT_R1_EXIT=0\r\n"
        )
        with self.assertRaises(Stop) as ctx:
            parse_serial(data, Stop)
        self.assertEqual(str(ctx.exception), "SERIAL_STATUS_ORDER")

        big = b"x" * 4194305
        with self.assertRaises(Stop) as ctx2:
            parse_serial(big, Stop)
        self.assertEqual(str(ctx2.exception), "SERIAL_BOUND")


class ProfileTests(unittest.TestCase):
    def test_fixed_direct_kernel_profile_has_no_network_or_host_share(self):
        root = Path(r"C:\Codex\Synthetic")
        argv = module.qemu_argv(root)
        self.assertEqual(argv[argv.index("-kernel")+1], (root/module.KERNEL).as_posix())
        self.assertEqual(argv[argv.index("-initrd")+1], (root/module.INITRAMFS).as_posix())
        self.assertEqual(argv[argv.index("-nic")+1], "none")
        self.assertIn("-nodefaults", argv)
        self.assertIn("-no-user-config", argv)
        self.assertEqual(argv[argv.index("-monitor")+1], "none")
        self.assertEqual(sum(value == "-drive" for value in argv), 2)
        self.assertNotIn("restore-guest.qcow2,format", " ".join(argv))
        self.assertNotIn("-virtfs", argv)
        self.assertNotIn("-fsdev", argv)
        self.assertNotIn("-cdrom", argv)
        module.validate_argv(argv, root)
        with self.assertRaisesRegex(Stop, "TOPOLOGY"):
            module.validate_argv(argv + ["-nic", "user"], root)

    def test_overlay_has_explicit_public_backing_and_format(self):
        root = Path(r"C:\Codex\Synthetic")
        argv = module.overlay_create_argv(root)
        self.assertEqual(argv[1:6], ["create", "-f", "qcow2", "-F", "qcow2"])
        self.assertEqual(argv[6:], ["-b", (root/module.BASE).as_posix(),
                                    (root/module.OVERLAY).as_posix()])

    def test_paths_reject_relative_traversal_and_qemu_option_injection(self):
        for root in ("relative", r"C:\Codex\..\escape", "C:/Codex/a,b", "C:/Codex/a=b",
                     "C:/Codex/bad\npath", "C:/Codex/bad\0path"):
            with self.subTest(root=root), self.assertRaisesRegex(Stop, "ROOT_PATH"):
                module.qemu_argv(root)

    def test_script_is_fixed_bounded_and_readonly_to_host(self):
        script = module.render_guest_script()
        self.assertTrue(script.startswith(b"#!/bin/sh\nset -eu\n"))
        self.assertLessEqual(len(script), 4096)
        self.assertEqual(len(module.render_script_disk()), 4096)
        self.assertEqual(module.render_script_disk()[len(script):], bytes(4096-len(script)))
        for required in (b"6.18.56-0-virt", module.APPEND.encode(),
                         b"[ ! -e \"$d/loop/backing_file\" ]\n [ ! -L",
                         b"php84 -n -r", b"python3 -I -S -B",
                         b"mariadbd --no-defaults --version", b"poweroff -f"):
            self.assertIn(required, script)
        for forbidden in (b"wp-config", b"curl ", b"wget ", b"/dev/vdc", b"mysql -",
                          b"mariadbd --initialize", b"mount -", b"apk add", b"eval "):
            self.assertNotIn(forbidden, script)

    def test_script_transfer_binds_exact_length_and_digest(self):
        command = module.serial_command()
        script = module.render_guest_script()
        self.assertIn("count="+str(len(script)), command)
        self.assertIn(hashlib.sha256(script).hexdigest(), command)
        self.assertIn("sha256sum -c - && sh ", command)
        self.assertNotIn("base64", command)

    def test_root_mount_options_require_exact_rw_and_no_ro(self):
        script = module.render_guest_script().decode("ascii")
        self.assertIn('check=ROOT_MOUNT_READ_WRITE', script)
        self.assertIn('n=split($4,a,",")', script)
        self.assertIn('if(a[i]=="rw") w++; if(a[i]=="ro") r++', script)
        self.assertIn("END { print w+0,r+0 }' /proc/mounts)\" = '1 0'", script)
        self.assertLess(script.index('check=ROOT_MOUNT_READ_WRITE'),
                        script.index('echo PUBLIC_BOOT_R1_ROOT='))

    def test_installed_modules_require_metadata_elf_and_version_match(self):
        script = module.render_guest_script().decode("ascii")
        self.assertIn('[ -s /lib/modules/6.18.56-0-virt/modules.dep ]', script)
        self.assertIn('[ -s /lib/modules/6.18.56-0-virt/modules.builtin ]', script)
        self.assertIn('kernel/fs/ext4/ext4.ko.gz', script)
        self.assertIn('kernel/drivers/block/virtio_blk.ko.gz', script)
        self.assertIn('vermagic=6.18.56-0-virt ', script)
        self.assertIn('read(16777217)', script)
        self.assertIn('len(b)<=16777216', script)
        self.assertLess(script.index('check=INSTALLED_MODULE_VERMAGIC'),
                        script.index('echo PUBLIC_BOOT_R1_RUNTIME='))

    def test_manifest_cannot_admit_or_claim_execution(self):
        manifest = module.render_manifest(Path(r"C:\Codex\Synthetic"))
        self.assertEqual(manifest["operation_admission"], "NOT_ADMITTED")
        for field in ("execution_implemented", "installed_boot_acceptance",
                      "restore_acceptance", "private_backup_attached"):
            self.assertIs(manifest[field], False)
        self.assertEqual(len(set(manifest["fresh_output_names"])), 4)

    def test_rendered_module_check_executes_against_positive_and_negative_fixtures(self):
        import io
        import shlex
        lines = module.render_guest_script().decode("ascii").splitlines()
        command = next(line for line in lines if line.startswith("python3 -I -S -B -c 'import gzip;"))
        code = compile(shlex.split(command)[-1], "<fixed-module-check>", "exec")
        names = ("kernel/fs/ext4/ext4.ko.gz", "kernel/drivers/block/virtio_blk.ko.gz")
        good_module = b"\x7fELF\0vermagic=6.18.56-0-virt SMP\0"

        class FakePath:
            def __init__(self, value):
                self.value = value
            def __truediv__(self, value):
                if value not in (*names, "modules.dep"):
                    raise AssertionError("unexpected fixture path")
                return FakePath(value)
            def read_bytes(self):
                assert self.value == "modules.dep"
                return dep

        for case in ("good", "missing_dependency", "wrong_version", "not_elf", "oversize"):
            dep = b"\n".join(name.encode()+b":" for name in names)
            payload = good_module
            if case == "missing_dependency":
                dep = b"unrelated.ko.gz:"
            elif case == "wrong_version":
                payload = payload.replace(b"6.18.56", b"6.18.52")
            elif case == "not_elf":
                payload = payload.replace(b"\x7fELF", b"text")
            elif case == "oversize":
                payload += bytes(16777217-len(payload))
            with self.subTest(case=case), patch("pathlib.Path", FakePath), \
                    patch("gzip.open", side_effect=lambda *args: io.BytesIO(payload)):
                if case == "good":
                    exec(code, {})
                else:
                    with self.assertRaises(AssertionError):
                        exec(code, {})

    def test_every_conflicting_missing_or_duplicate_marker_rejects(self):
        for prefix, expected in module.MARKERS:
            for serial in (GOOD.replace(expected, prefix+b"WRONG"),
                           GOOD.replace(expected+b"\n", b""),
                           GOOD + expected+b"\n", GOOD+prefix+b"CONFLICT\n"):
                with self.subTest(prefix=prefix, serial=serial), self.assertRaisesRegex(Stop, "SERIAL_STATUS"):
                    parse_serial(serial)

    def test_failure_labels_are_bounded_and_never_authority(self):
        prefix = b"PUBLIC_BOOT_R1_CHECK_FAIL="
        for label in (b"", b"lower", b"A"*65, b"A\x1b[0m", b"\xff", b"A B"):
            with self.subTest(label=label), self.assertRaisesRegex(Stop, "^SERIAL_CHECK_FAIL$"):
                parse_serial(GOOD+prefix+label+b"\n")
        with self.assertRaisesRegex(Stop, "^SERIAL_CHECK_FAIL$"):
            parse_serial(GOOD+prefix+b"FIRST\n"+prefix+b"SECOND\n")

    def test_exact_bytes_type_and_bound(self):
        class BytesSubclass(bytes):
            pass
        for bad in (None, "", bytearray(GOOD), BytesSubclass(GOOD)):
            with self.subTest(value=type(bad)), self.assertRaisesRegex(Stop, "SERIAL_BOUND"):
                parse_serial(bad)
        self.assertIsNone(parse_serial(GOOD+b"x"*(4194304-len(GOOD))))

    def test_cli_has_no_execution(self):
        with patch("subprocess.Popen", side_effect=AssertionError("NO_CHILD")), \
                patch("os.system", side_effect=AssertionError("NO_CHILD")), \
                self.assertRaisesRegex(SystemExit, "NOT_ADMITTED"):
            exec(compile(SOURCE.read_bytes(), str(SOURCE), "exec"), {"__name__": "__main__"})


if __name__ == "__main__":
    unittest.main()

