"""Synthetic R2 executor checks; never launch QEMU or qemu-img."""

import contextlib
import io
import json
from pathlib import Path
import runpy
import threading
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

import public_installed_boot_probe_executor_r2 as executor
import public_installed_boot_probe_r1 as probe


class MemoryFile(io.BytesIO):
    def close(self):
        self.saved = self.getvalue()
        super().close()

    def fileno(self):
        return 123


class SyntheticImagePipe:
    def __init__(self, child, chunks=None, blocking=False):
        self.child = child
        self.chunks = list(chunks or [])
        self.blocking = blocking
        self.reads = 0
        self.closed = False
        self.finished = False

    def read(self, size):
        self.reads += 1
        if self.blocking:
            self.child.stopped.wait(1)
        if self.chunks:
            return self.chunks.pop(0)
        if not self.finished:
            self.finished = True
            self.child.stream_done()
        return b""

    def close(self):
        self.closed = True
        self.child.stopped.set()


class SyntheticImageChild:
    def __init__(self, argv, stdout_chunks=None, stderr_chunks=None, blocking=False):
        self.args = argv
        self.pid = 4321
        self.code = None
        self.terminated = False
        self.killed = False
        self.stopped = threading.Event()
        self._done_lock = threading.Lock()
        self._done_streams = 0
        self.stdout = SyntheticImagePipe(self, stdout_chunks, blocking)
        self.stderr = SyntheticImagePipe(self, stderr_chunks, blocking)

    @property
    def returncode(self):
        return self.code

    def stream_done(self):
        with self._done_lock:
            self._done_streams += 1
            if self._done_streams == 2 and self.code is None:
                self.code = 0
                self.stopped.set()

    def poll(self):
        return self.code

    def wait(self, timeout):
        if self.code is None and not self.stopped.wait(timeout):
            raise executor.subprocess.TimeoutExpired(self.args, timeout)
        return self.code

    def terminate(self):
        self.terminated = True
        self.code = -15
        self.stopped.set()

    def kill(self):
        self.killed = True
        self.code = -9
        self.stopped.set()


class SyntheticChild:
    """Minimal serial child for the copied, already accepted transport seam."""

    def __init__(self, argv, scenario="ok"):
        self.args = argv
        self.pid = 1234
        self.scenario = scenario
        self.code = None
        self.pending = bytearray()
        self.commands = []
        self.line_echo = False
        self.ready = False
        self.eof_sent = False
        self.exit_polls = 0
        self.queue = [] if scenario == "timeout" else [b"alpine login: "]
        self.stdin = SimpleNamespace(write=self.write, flush=lambda: None, close=lambda: None)
        self.stdout = SimpleNamespace(fileno=lambda: 234, close=lambda: None)
        self.terminated = False
        self.killed = False

    def write(self, data):
        self.pending.extend(data)
        if self.pending.endswith(b"\n"):
            command = bytes(self.pending)
            self.pending.clear()
            self.commands.append(command)
            if command == b"root\n":
                self.queue.append(
                    b"wrong\r\n" if self.scenario == "login-echo" else b"root\r\nlocalhost:~# \x1b[6n"
                )
            elif command == executor.TERMINAL_HANDSHAKE:
                self.line_echo = True
                echo = command.replace(b"\n", b"\r\n")
                suffix = b"localhost:~# " if self.scenario == "exec-prompt" else b""
                self.queue.append(echo + suffix)
            elif command == executor.READY_COMMAND:
                self.ready = True
                ready = executor.READY_MARKER + b"\r\n"
                if self.scenario == "ready-extra":
                    ready += b"unexpected\r\n"
                self.queue.extend((command.replace(b"\n", b"\r\n"), ready))
            else:
                if not self.line_echo or not self.ready:
                    raise AssertionError("LONG_COMMAND_BEFORE_READY")
                markers = b"\r\n".join(expected for _, expected in probe.MARKERS) + b"\r\n"
                if self.scenario == "guest-fail":
                    markers += b"PUBLIC_BOOT_R1_CHECK_FAIL=INSTALLED_KERNEL\r\n"
                self.queue.append(command.replace(b"\n", b"\r\n") + markers)
                if self.scenario != "eof-first":
                    self.code = 7 if self.scenario == "exit" else 0
        return len(data)

    def read(self, descriptor, count):
        if self.scenario == "identity":
            self.pid += 1
        if self.scenario == "overflow":
            return b"x" * 4096
        if self.queue:
            return self.queue.pop(0)
        if self.scenario == "eof-first" and self.ready and len(self.commands) == 4:
            self.eof_sent = True
            return b""
        if self.code is not None:
            return b""
        raise BlockingIOError

    def poll(self):
        if self.eof_sent and self.code is None:
            self.exit_polls += 1
            if self.exit_polls >= 3:
                self.code = 0
        return self.code

    def wait(self, timeout):
        if self.code is None:
            raise executor.subprocess.TimeoutExpired(self.args, timeout)
        return self.code

    def terminate(self):
        self.terminated = True
        self.code = -15

    def kill(self):
        self.killed = True
        self.code = -9


class ExecutorTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(executor.__file__).parent.absolute()
        self.no_child = patch.object(
            executor.subprocess, "Popen", side_effect=AssertionError("CHILD_FORBIDDEN")
        )
        self.no_child.start()
        self.addCleanup(self.no_child.stop)

    def admission(self, **changes):
        pins = []
        for name in executor.REQUIRED:
            size, digest = 1, "a" * 64
            if name in probe.INPUT_PINS:
                expected_size, digest = probe.INPUT_PINS[name]
                size = 1 if expected_size is None else expected_size
            elif name == probe.R8_RECEIPT:
                digest = probe.R8_RECEIPT_SHA
            pins.append(executor.Pin(name, size, digest))
        fields = {
            "root": str(self.root),
            "executor_sha256": "a" * 64,
            "profile_module_sha256": "a" * 64,
            "guard_module_sha256": "a" * 64,
            "profile_sha256": executor.PROFILE_SHA256,
            "pins": tuple(pins),
            "approval": executor.APPROVAL,
            "public_tool_closure_reviewed": True,
        }
        fields.update(changes)
        return executor.Admission(**fields)

    def test_cli_and_import_are_inert(self):
        with patch.object(executor, "_exclusive", side_effect=AssertionError("WRITE_FORBIDDEN")):
            with self.assertRaisesRegex(SystemExit, "NOT_ADMITTED"):
                runpy.run_path(executor.__file__, run_name="__main__")

    def test_execute_without_exact_admission_stops_before_io(self):
        with patch.object(executor, "_verify_inputs", side_effect=AssertionError("IO_FORBIDDEN")):
            with self.assertRaisesRegex(probe.Stop, "NOT_ADMITTED"):
                executor.execute(self.root)

    def test_admission_rejects_authority_and_binding_changes(self):
        changes = (
            {"approval": "wrong"},
            {"profile_sha256": "0" * 64},
            {"public_tool_closure_reviewed": False},
            {"executor_sha256": "b" * 64},
            {"profile_module_sha256": "b" * 64},
            {"guard_module_sha256": "b" * 64},
            {"pins": ()},
        )
        with patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name), \
                patch.object(executor.os.path, "lexists", return_value=False):
            for change in changes:
                with self.subTest(change=change), self.assertRaises(probe.Stop):
                    executor._admit(self.root, self.admission(**change))

    def test_admission_rejects_duplicate_private_and_stale_outputs(self):
        pins = self.admission().pins
        extras = (pins[0], executor.Pin("private-backup.tar", 1, "b" * 64))
        with patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name), \
                patch.object(executor.os.path, "lexists", return_value=False):
            for extra in extras:
                with self.subTest(extra=extra.name), self.assertRaises(probe.Stop):
                    executor._admit(self.root, self.admission(pins=pins + (extra,)))
        with patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name), \
                patch.object(executor.os.path, "lexists", return_value=True):
            with self.assertRaisesRegex(probe.Stop, "STALE_OUTPUT"):
                executor._admit(self.root, self.admission())

    def test_zero_length_tool_pin_is_valid_but_negative_is_not(self):
        pin = executor.Pin("qemu-test-tools/empty.cache", 0, executor._sha256(b""), 4)
        with patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name), \
                patch.object(executor.os.path, "lexists", return_value=False):
            _, admitted = executor._admit(self.root, self.admission(pins=self.admission().pins + (pin,)))
            self.assertIn(pin.name, admitted)
            bad = executor.Pin(pin.name, -1, pin.sha256, 4)
            with self.assertRaisesRegex(probe.Stop, "ADMISSION_PIN_SCHEMA"):
                executor._admit(self.root, self.admission(pins=self.admission().pins + (bad,)))

    def test_verify_inputs_rejects_digest_and_identity_drift(self):
        pin = executor.Pin("qemu-test-tools/a", 3, "a" * 64, 4)
        with patch.object(executor, "_safe_path", return_value=self.root / "synthetic"):
            with patch.object(executor, "_digest", return_value=((1, 2, 3, 4), "b" * 64)):
                with self.assertRaisesRegex(probe.Stop, "INPUT_PIN"):
                    executor._verify_inputs(self.root, {pin.name: pin})
            with patch.object(executor, "_digest", return_value=((1, 2, 3, 4), "a" * 64)):
                with self.assertRaisesRegex(probe.Stop, "INPUT_IDENTITY"):
                    executor._verify_inputs(self.root, {pin.name: pin}, {pin.name: (1, 9, 3, 4)})

    def test_image_output_limit_stops_before_unbounded_buffering_and_closes_pipes(self):
        chunks = [b"x" * 32 for _ in range(64)]
        child = SyntheticImageChild(["qemu-img", "info"], stdout_chunks=chunks)
        self.no_child.stop()
        try:
            with patch.object(executor.subprocess, "Popen", return_value=child):
                with self.assertRaisesRegex(probe.Stop, "IMAGE_TOOL_OUTPUT"):
                    executor._owned_process(["qemu-img", "info"], 1, 64)
        finally:
            self.no_child.start()
        self.assertTrue(child.terminated or child.killed)
        self.assertLess(child.stdout.reads, len(chunks), "overflow must stop before the producer is drained")
        self.assertTrue(child.stdout.closed)
        self.assertTrue(child.stderr.closed)
        self.assertIsNotNone(child.poll())

    def test_image_timeout_reaps_owned_child_and_closes_pipes(self):
        child = SyntheticImageChild(["qemu-img", "info"], blocking=True)
        self.no_child.stop()
        try:
            with patch.object(executor.subprocess, "Popen", return_value=child):
                with self.assertRaisesRegex(probe.Stop, "IMAGE_TOOL_TIMEOUT"):
                    executor._owned_process(["qemu-img", "info"], 0.02, 64)
        finally:
            self.no_child.start()
        self.assertTrue(child.terminated or child.killed)
        self.assertTrue(child.stdout.closed)
        self.assertTrue(child.stderr.closed)
        self.assertIsNotNone(child.poll())

    def test_overlay_reservation_is_closed_before_owned_image_tool_populates_it(self):
        with tempfile.TemporaryDirectory(prefix="probe-overlay-") as folder:
            root = Path(folder).absolute()
            states = []

            def populate(argv, timeout, output_limit):
                path = root / probe.OVERLAY
                states.append(path.exists())
                with open(path, "r+b") as target:
                    target.write(b"qcow2-synthetic")
                return b""

            with patch.object(probe, "overlay_create_argv", return_value=["qemu-img", "create"]), \
                    patch.object(executor, "_owned_process", side_effect=populate):
                identity = executor._create_overlay(root)
            self.assertEqual(states, [True])
            self.assertEqual(identity[2], len(b"qcow2-synthetic"))

    def test_overlay_replacement_after_reservation_is_rejected(self):
        with tempfile.TemporaryDirectory(prefix="probe-overlay-swap-") as folder:
            root = Path(folder).absolute()

            def replace(argv, timeout, output_limit):
                path = root / probe.OVERLAY
                path.unlink()
                path.write_bytes(b"replacement")
                return b""

            with patch.object(probe, "overlay_create_argv", return_value=["qemu-img", "create"]), \
                    patch.object(executor, "_owned_process", side_effect=replace):
                with self.assertRaisesRegex(probe.Stop, "OVERLAY_RESERVATION"):
                    executor._create_overlay(root)

    def test_image_chain_requires_exact_guard_acceptance_and_no_overlay_drift(self):
        overlay_identity = (1, 2, 3, 4)
        decoded = [{"filename": "overlay"}, {"filename": "base"}]
        info = SimpleNamespace(st_dev=1, st_ino=2, st_size=3, st_mtime_ns=4,
                               st_file_attributes=0, st_mode=0o100600, st_nlink=1)
        with patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name), \
                patch.object(executor, "_artifact_identity", return_value=self.root / probe.OVERLAY), \
                patch.object(executor, "_plain_file_info", return_value=info), \
                patch.object(executor, "_owned_process", return_value=json.dumps(decoded).encode("ascii")), \
                patch.object(executor.guard, "validate_backing_chain") as validate:
            executor._inspect_chain(self.root, overlay_identity)
            validate.assert_called_once()
        changed = SimpleNamespace(st_dev=1, st_ino=2, st_size=4, st_mtime_ns=5,
                                  st_file_attributes=0, st_mode=0o100600, st_nlink=1)
        with patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name), \
                patch.object(executor, "_artifact_identity", return_value=self.root / probe.OVERLAY), \
                patch.object(executor, "_plain_file_info", side_effect=[info, changed]), \
                patch.object(executor, "_owned_process", return_value=b"[]"):
            with self.assertRaisesRegex(probe.Stop, "IMAGE_CHAIN_IDENTITY"):
                executor._inspect_chain(self.root, overlay_identity)

    def run_transport(self, scenario):
        child = SyntheticChild(probe.qemu_argv(self.root), scenario)
        now = [0.0]
        self.no_child.stop()
        try:
            with contextlib.ExitStack() as stack:
                stack.enter_context(patch.object(executor.subprocess, "Popen", return_value=child))
                stack.enter_context(patch.object(executor.os, "set_blocking"))
                stack.enter_context(patch.object(executor.os, "read", side_effect=child.read))
                stack.enter_context(patch.object(executor.time, "monotonic", side_effect=lambda: now[0]))
                stack.enter_context(patch.object(executor.time, "sleep", side_effect=lambda delay: now.__setitem__(0, now[0] + delay)))
                stack.enter_context(patch.dict(executor.PROFILE, seconds=3 if scenario == "timeout" else 600,
                                                log_bytes=8192 if scenario == "overflow" else 4 * executor.MIB))
                result = executor._run(self.root, io.BytesIO())
        finally:
            self.no_child.start()
        return result, child

    def test_transport_accepts_exact_ready_barrier_and_public_markers(self):
        (serial, code), child = self.run_transport("ok")
        self.assertEqual(code, 0)
        self.assertTrue(all(expected in serial for _, expected in probe.MARKERS))
        self.assertEqual(child.commands[:3], [b"root\n", executor.TERMINAL_HANDSHAKE, executor.READY_COMMAND])

    def test_transport_rejects_handshake_marker_guest_exit_timeout_and_identity_failures(self):
        cases = {"login-echo": "SERIAL_ECHO", "exec-prompt": "TERMINAL_HANDSHAKE",
                 "ready-extra": "TERMINAL_HANDSHAKE", "guest-fail": "SERIAL_CHECK_FAIL",
                 "exit": "QEMU_EXIT", "timeout": "TIMEOUT",
                 "identity": "PROCESS_IDENTITY", "overflow": "LOG_OVERFLOW"}
        for scenario, error in cases.items():
            with self.subTest(scenario=scenario), self.assertRaisesRegex(probe.Stop, error):
                self.run_transport(scenario)

    def test_execute_success_sets_only_public_installed_boot_acceptance(self):
        opened = {}
        def exclusive(root, name):
            opened[name] = MemoryFile()
            return opened[name]
        verify_calls = []
        def verify(root, pins, previous=None):
            verify_calls.append(previous)
            return {} if previous is None else previous
        fake_info = SimpleNamespace(st_dev=1, st_ino=2, st_size=0, st_mtime_ns=3)
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(executor, "_admit", return_value=(self.root, {})))
            stack.enter_context(patch.object(executor, "_verify_inputs", side_effect=verify))
            stack.enter_context(patch.object(executor, "_exclusive", side_effect=exclusive))
            stack.enter_context(patch.object(executor.os, "fstat", return_value=fake_info))
            stack.enter_context(patch.object(executor.os, "fsync"))
            stack.enter_context(patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name))
            stack.enter_context(patch.object(executor, "_create_script_disk", return_value=(1, 2, probe.SCRIPT_BYTES, 4)))
            stack.enter_context(patch.object(executor, "_create_overlay", return_value=(1, 3, 99, 4)))
            stack.enter_context(patch.object(executor, "_inspect_chain", return_value=(1, 3, 99, 4)))
            stack.enter_context(patch.object(executor, "_artifact_identity", side_effect=lambda root, name, identity, size=None: root / name))
            stack.enter_context(patch.object(executor, "_plain_file_info", return_value=SimpleNamespace(
                st_dev=1, st_ino=3, st_size=99, st_mtime_ns=4,
                st_file_attributes=0, st_mode=0o100600, st_nlink=1)))
            stack.enter_context(patch.object(executor, "_digest", return_value=((1, 2, probe.SCRIPT_BYTES, 4), executor._sha256(probe.render_script_disk()))))
            stack.enter_context(patch.object(executor, "_run", return_value=(b"serial", 0)))
            stack.enter_context(patch.object(probe, "parse_serial"))
            result = executor.execute(self.root, object())
        self.assertEqual(result["status"], "PUBLIC_INSTALLED_BOOT_ONLY_OK")
        self.assertTrue(result["installed_boot_acceptance"])
        self.assertFalse(result["restore_acceptance"])
        self.assertFalse(result["private_backup_attached"])
        self.assertTrue(result["pre_chain_verified"] and result["post_chain_verified"])
        self.assertGreaterEqual(len(verify_calls), 3)
        self.assertEqual(json.loads(opened[probe.RESULT].saved), result)

    def test_final_image_inspection_drift_fails_before_installed_boot_acceptance(self):
        opened = {}

        def exclusive(root, name):
            opened[name] = MemoryFile()
            return opened[name]

        drifted = {"value": False}
        inspections = {"count": 0}

        def inspect(root, identity):
            inspections["count"] += 1
            if inspections["count"] == 2:
                drifted["value"] = True
            return identity

        def verify(root, pins, previous=None):
            if previous is not None and drifted["value"]:
                raise probe.Stop("INPUT_IDENTITY:synthetic")
            return {} if previous is None else previous

        fake_info = SimpleNamespace(st_dev=1, st_ino=2, st_size=0, st_mtime_ns=3)
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(executor, "_admit", return_value=(self.root, {})))
            stack.enter_context(patch.object(executor, "_verify_inputs", side_effect=verify))
            stack.enter_context(patch.object(executor, "_exclusive", side_effect=exclusive))
            stack.enter_context(patch.object(executor.os, "fstat", return_value=fake_info))
            stack.enter_context(patch.object(executor.os, "fsync"))
            stack.enter_context(patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name))
            stack.enter_context(patch.object(executor, "_create_script_disk", return_value=(1, 2, probe.SCRIPT_BYTES, 4)))
            stack.enter_context(patch.object(executor, "_create_overlay", return_value=(1, 3, 99, 4)))
            stack.enter_context(patch.object(executor, "_inspect_chain", side_effect=inspect))
            stack.enter_context(patch.object(executor, "_artifact_identity", side_effect=lambda root, name, identity, size=None: root / name))
            stack.enter_context(patch.object(executor, "_plain_file_info", return_value=SimpleNamespace(
                st_dev=1, st_ino=3, st_size=99, st_mtime_ns=4,
                st_file_attributes=0, st_mode=0o100600, st_nlink=1)))
            stack.enter_context(patch.object(executor, "_digest", return_value=((1, 2, probe.SCRIPT_BYTES, 4), executor._sha256(probe.render_script_disk()))))
            stack.enter_context(patch.object(executor, "_run", return_value=(b"serial", 0)))
            stack.enter_context(patch.object(probe, "parse_serial"))
            result = executor.execute(self.root, object())
        self.assertEqual(inspections["count"], 2)
        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(result["error"], "INPUT_IDENTITY:synthetic")
        self.assertFalse(result["post_pins_verified"])
        self.assertFalse(result["installed_boot_acceptance"])
        self.assertFalse(result["restore_acceptance"])
        self.assertEqual(json.loads(opened[probe.RESULT].saved), result)

    def test_execute_failure_preserves_diagnostic_and_never_claims_acceptance(self):
        opened = {}
        def exclusive(root, name):
            opened[name] = MemoryFile()
            return opened[name]
        fake_info = SimpleNamespace(st_dev=1, st_ino=2, st_size=0, st_mtime_ns=3)
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(executor, "_admit", return_value=(self.root, {})))
            stack.enter_context(patch.object(executor, "_verify_inputs", return_value={}))
            stack.enter_context(patch.object(executor, "_exclusive", side_effect=exclusive))
            stack.enter_context(patch.object(executor.os, "fstat", return_value=fake_info))
            stack.enter_context(patch.object(executor.os, "fsync"))
            stack.enter_context(patch.object(executor, "_safe_path", side_effect=lambda root, name, exists=True: root / name))
            stack.enter_context(patch.object(executor, "_create_script_disk", side_effect=probe.Stop("SCRIPT_WRITE")))
            stack.enter_context(patch.object(executor, "_artifact_identity", side_effect=lambda root, name, identity, size=None: root / name))
            result = executor.execute(self.root, object())
        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(result["error"], "SCRIPT_WRITE")
        self.assertFalse(result["installed_boot_acceptance"])
        self.assertFalse(result["restore_acceptance"])


if __name__ == "__main__":
    unittest.main()
