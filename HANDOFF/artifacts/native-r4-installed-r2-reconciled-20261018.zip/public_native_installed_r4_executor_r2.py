"""R2 framed serial executor. Import and CLI are inert; execute requires admission."""
from dataclasses import dataclass
import hashlib, json, os, re, subprocess, time
from pathlib import Path, PurePosixPath
import public_native_installed_r4_profile_r2 as profile
import public_installed_boot_probe_executor_r2 as frozen

MIB = 1024 * 1024
EXECUTOR = "public_native_installed_r4_executor_r2.py"
PROFILE_MODULE = "public_native_installed_r4_profile_r2.py"
R1_PROFILE = "public_native_installed_r4_profile_r1.py"
FROZEN_HELPER = "public_installed_boot_probe_executor_r2.py"
FROZEN_PROBE = "public_installed_boot_probe_r1.py"
FROZEN_GUARD = "public_installed_boot_image_guard_r1.py"
PROFILE = {"mode": profile.MODE, "public_only": True, "seconds": 600, "log_bytes": 4*MIB,
           "write_bytes": 4, "write_interval": .2, "cleanup_seconds": 3}
PROFILE_SHA256 = hashlib.sha256(json.dumps(PROFILE,sort_keys=True).encode("ascii")).hexdigest()
REQUIRED = (EXECUTOR,PROFILE_MODULE,R1_PROFILE,FROZEN_HELPER,FROZEN_PROBE,FROZEN_GUARD,profile.BASE,profile.KERNEL,
            profile.INITRAMFS,profile.TOOL,profile.IMAGE_TOOL,profile.PACK,profile.MANIFEST,profile.ADMISSION_SOURCE,profile.BOOT_RECEIPT)
APPROVAL = "ROOT_APPROVED_PUBLIC_NATIVE_INSTALLED_R4_R2_ONLY"
TERMINAL_HANDSHAKE=b"exec /bin/sh -c 'while IFS= read -r l; do eval \"$l\"; done'\n"
READY_COMMAND=b"printf 'PUBLIC_NATIVE_R4_READY\\n'\n"; READY_MARKER=b"PUBLIC_NATIVE_R4_READY\n"
Pin=frozen.Pin

@dataclass(frozen=True)
class Admission:
    root:str; executor_sha256:str; profile_module_sha256:str; r1_profile_sha256:str; frozen_helper_sha256:str
    profile_sha256:str; pins:tuple; approval:str; public_tool_closure_reviewed:bool

def _safe(root,name,exists=True):
    if type(name) is not str or not name or "\\" in name or "\0" in name or ":" in name or ".." in PurePosixPath(name).parts: raise profile.Stop("PATH")
    path=profile._root(root).joinpath(*PurePosixPath(name).parts)
    if exists and not os.path.lexists(path): raise profile.Stop("PATH")
    return path

_digest=frozen._digest; _exclusive=frozen._exclusive; _artifact_identity=frozen._artifact_identity; _owned_process=frozen._owned_process

def strict_frame_echo(expected, observed):
    """Validate one echo without removing XOFF or any other control byte."""
    if type(expected) is not bytes or type(observed) is not bytes or not expected.endswith(b"\n"):
        raise profile.Stop("SERIAL_ECHO")
    normalized=observed.replace(b"\r",b"")
    if b"\n" not in normalized or normalized.split(b"\n",1)[0]+b"\n"!=expected:
        raise profile.Stop("SERIAL_ECHO")
    if normalized.split(b"\n",1)[1]: raise profile.Stop("FRAME_SUFFIX")

def validate_frame_sequence(commands, observed):
    """Host-only test seam: rejects missing, reordered, duplicate, corrupt or extra frames."""
    if type(commands) is not tuple or type(observed) is not tuple or len(commands)!=len(observed): raise profile.Stop("FRAME_SEQUENCE")
    for command,reply in zip(commands,observed):
        if type(command) is not str or len(command.encode("ascii"))>profile.FRAME_LIMIT: raise profile.Stop("FRAME_LENGTH")
        strict_frame_echo(command.encode("ascii")+b"\n",reply)

def _admit(root,admission):
    root=profile._root(root)
    if type(admission) is not Admission or admission.root!=str(root) or admission.approval!=APPROVAL or admission.profile_sha256!=PROFILE_SHA256 or admission.public_tool_closure_reviewed is not True: raise profile.Stop("NOT_ADMITTED")
    pins={}
    for pin in admission.pins:
        if type(pin) is not Pin or pin.name in pins or type(pin.size) is not int or pin.size<0 or type(pin.sha256) is not str or re.fullmatch(r"[0-9a-f]{64}",pin.sha256) is None: raise profile.Stop("ADMISSION_PIN_SCHEMA")
        _safe(root,pin.name); pins[pin.name]=pin
    if not set(REQUIRED).issubset(pins): raise profile.Stop("ADMISSION_PINS_MISSING")
    if (pins[EXECUTOR].sha256!=admission.executor_sha256 or pins[PROFILE_MODULE].sha256!=admission.profile_module_sha256 or pins[R1_PROFILE].sha256!=admission.r1_profile_sha256 or pins[FROZEN_HELPER].sha256!=admission.frozen_helper_sha256): raise profile.Stop("ADMISSION_CODE_BINDING")
    for name,(size,digest) in profile.INPUT_PINS.items():
        if name not in pins or pins[name].sha256!=digest or size is not None and pins[name].size!=size: raise profile.Stop("PROFILE_INPUT_PIN:"+name)
    if any(os.path.lexists(_safe(root,name,False)) for name in profile.OUTPUT_NAMES): raise profile.Stop("STALE_OUTPUT")
    return root,pins

def _verify(root,pins,previous=None):
    found={}
    for name,pin in pins.items():
        identity,digest=_digest(_safe(root,name))
        if identity[2]!=pin.size or digest!=pin.sha256 or pin.mtime_ns is not None and identity[3]!=pin.mtime_ns: raise profile.Stop("INPUT_PIN:"+name)
        if previous is not None and previous.get(name)!=identity: raise profile.Stop("INPUT_IDENTITY:"+name)
        found[name]=identity
    return found

def _write_result(root,payload):
    if os.path.lexists(_safe(root,profile.RESULT,False)): return False
    with _exclusive(root,profile.RESULT) as out:
        data=json.dumps(payload,sort_keys=True,separators=(",",":")).encode("ascii")
        if out.write(data)!=len(data): raise profile.Stop("RESULT_WRITE")
        out.flush(); os.fsync(out.fileno())
    return True

def _create_overlay(root):
    with _exclusive(root,profile.OVERLAY) as out:
        before=frozen._identity(os.fstat(out.fileno()))
        if before[2]!=0: raise profile.Stop("OVERLAY_RESERVATION")
        out.flush(); os.fsync(out.fileno())
    frozen._owned_process(profile.overlay_create_argv(root),120,4*MIB)
    after=frozen._identity(frozen._plain_file_info(_safe(root,profile.OVERLAY)))
    if after[:2]!=before[:2] or after[2]<=0: raise profile.Stop("OVERLAY_RESERVATION")
    return after

def _image_check(root,name,identity=None):
    path=_safe(root,name); before=frozen._identity(frozen._plain_file_info(path))
    if identity is not None and before[:2]!=identity[:2]: raise profile.Stop("IMAGE_CHECK_IDENTITY")
    raw=frozen._owned_process([str(_safe(root,profile.IMAGE_TOOL)),"check","--output=json",str(path)],120,4*MIB)
    if frozen._identity(frozen._plain_file_info(path))!=before: raise profile.Stop("IMAGE_CHECK_IDENTITY")
    try: report=json.loads(raw.decode("ascii"))
    except (UnicodeDecodeError,json.JSONDecodeError): raise profile.Stop("IMAGE_CHECK_JSON")
    if type(report) is not dict or report.get("check-errors")!=0 or report.get("corruptions",0)!=0: raise profile.Stop("IMAGE_CHECK")
    return {"name":name,"ok":True}

def _post_image_checks(root,overlay):
    findings=[]
    for name,identity in ((profile.BASE,None),(profile.OVERLAY,overlay)):
        if name==profile.OVERLAY and overlay is None and not os.path.lexists(_safe(root,name,False)): continue
        try: findings.append(_image_check(root,name,identity))
        except BaseException as error: findings.append({"name":name,"ok":False,"error_type":type(error).__name__,"error":str(error)})
    return findings

def _run(root,log,admission_source):
    """Short strict echo frames; no control-byte filtering or later write after failure."""
    argv=profile.qemu_argv(root); profile.validate_argv(argv,root)
    env={k:os.environ[k] for k in ("SystemRoot","WINDIR") if k in os.environ}
    child=subprocess.Popen(argv,cwd=root,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,bufsize=0,shell=False,close_fds=True)
    owner=(child.pid,tuple(child.args)); serial=bytearray(); deadline=time.monotonic()+PROFILE["seconds"]; eof=False; last=None
    def pump():
        nonlocal eof
        if (child.pid,tuple(child.args))!=owner: raise profile.Stop("PROCESS_IDENTITY")
        if time.monotonic()>=deadline: raise profile.Stop("TIMEOUT")
        try: block=os.read(child.stdout.fileno(),4096)
        except BlockingIOError: block=None
        if block==b"": eof=True
        if block:
            if len(serial)+len(block)>PROFILE["log_bytes"]: raise profile.Stop("LOG_OVERFLOW")
            serial.extend(block)
            if log.write(block)!=len(block): raise profile.Stop("LOG_WRITE")
            log.flush()
    def wait(predicate,terminal=False):
        while not predicate():
            pump()
            if not terminal and (eof or child.poll() is not None): raise profile.Stop("PROCESS_EARLY_EXIT")
            time.sleep(.02)
    def send(command,barrier=None):
        nonlocal last
        for off in range(0,len(command),PROFILE["write_bytes"]):
            while last is not None and time.monotonic()-last<PROFILE["write_interval"]: pump(); time.sleep(.02)
            pump()
            if off==0 and barrier is not None and barrier() is not True: raise profile.Stop("FRAME_BARRIER")
            if child.poll() is not None: raise profile.Stop("PROCESS_EARLY_EXIT")
            part=command[off:off+PROFILE["write_bytes"]]
            if child.stdin.write(part)!=len(part): raise profile.Stop("SERIAL_WRITE")
            child.stdin.flush(); last=time.monotonic()
    def echo(command,start,strict=False):
        wait(lambda:b"\n" in bytes(serial[start:]).replace(b"\r",b""))
        actual=bytes(serial[start:]).replace(b"\r",b"").split(b"\n",1)[0]+b"\n"
        if actual!=command: raise profile.Stop("SERIAL_ECHO")
        end=start+bytes(serial[start:]).index(b"\n")+1
        if strict:
            until=time.monotonic()+PROFILE["write_interval"]
            while time.monotonic()<until: pump(); time.sleep(.02)
            if bytes(serial[end:]): raise profile.Stop("FRAME_SUFFIX")
        return end
    try:
        os.set_blocking(child.stdout.fileno(),False); wait(lambda:bytes(serial).endswith(b"login: "))
        start=len(serial); send(b"root\n"); echo(b"root\n",start)
        wait(lambda:re.search(rb"(?:^|\n)[^\r\n\x1b]*[~/:]# (?:\x1b\[6n)?$",bytes(serial)) is not None)
        start=len(serial); send(TERMINAL_HANDSHAKE); echo(TERMINAL_HANDSHAKE,start)
        start=len(serial); send(READY_COMMAND); echo(READY_COMMAND,start)
        wait(lambda:bytes(serial).replace(b"\r",b"").endswith(READY_MARKER))
        commands,_,_=profile.framed_commands(admission_source)
        for index,frame in enumerate(commands):
            command=frame.encode("ascii")+b"\n"; start=len(serial); send(command,lambda: not bytes(serial[start:]))
            if index+1<len(commands): echo(command,start,strict=True)
            else: echo(command,start)
        wait(lambda:child.poll() is not None and eof,True)
        if child.wait(timeout=PROFILE["cleanup_seconds"])!=0: raise profile.Stop("QEMU_EXIT")
        profile.parse_serial(bytes(serial)); return bytes(serial)
    finally:
        if child.poll() is None:
            child.terminate()
            try: child.wait(timeout=PROFILE["cleanup_seconds"])
            except subprocess.TimeoutExpired: child.kill(); child.wait(timeout=PROFILE["cleanup_seconds"])
        child.stdin.close(); child.stdout.close()
        if child.poll() is None: raise profile.Stop("PROCESS_NOT_CLOSED")

def execute(root,admission=None):
    root,pins=_admit(root,admission); pre=_verify(root,pins); original=None; serial=b""; post=None; overlay=None; images=[]
    try:
        source=_safe(root,profile.ADMISSION_SOURCE).read_bytes(); profile._checked_admission_source(source)
        overlay=_create_overlay(root)
        with _exclusive(root,profile.SERIAL_LOG) as log: serial=_run(root,log,source); log.flush(); os.fsync(log.fileno())
        images=_post_image_checks(root,overlay)
        if not all(item["ok"] for item in images): raise profile.Stop("POST_IMAGE_CHECK")
        post=_verify(root,pins,pre)
        result={"format":"PUBLIC_NATIVE_INSTALLED_R4_R2_RESULT","status":"PUBLIC_NATIVE_INSTALLED_R4_OK","native_acceptance":False,"clean_closeout":True,"post_pins_verified":bool(post),"post_image_checks":images,"serial_bytes":len(serial)}
        _write_result(root,result); return result
    except BaseException as error:
        original=error
        try: post=_verify(root,pins,pre); post_error=None
        except BaseException as verification_error: post_error=type(verification_error).__name__
        images=_post_image_checks(root,overlay)
        result={"format":"PUBLIC_NATIVE_INSTALLED_R4_R2_RESULT","status":"FAILED","native_acceptance":False,"error_type":type(error).__name__,"error":str(error),"serial_bytes":len(serial),"post_pins_verified":post is not None,"post_pin_error":post_error,"post_image_checks":images}
        _write_result(root,result)
        raise original

if __name__=="__main__": raise SystemExit("NOT_ADMITTED: executor import only")
