"""Synthetic regressions for scoping the immutable R2 log's unittest report."""
import importlib,json,pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
subject=importlib.import_module("public_native_r4_result_reconcile_r1")

class ResultBoundaryTests(unittest.TestCase):
    def fixture(self):
        report={"format":"NATIVE_ADMISSION_PUBLIC_IO_R2","pass":True,"checks_passed":9,"last_check":"ROOT_RESTORED","private_input_opened":False,"admission_bound":False,"preparation_executed":False}
        return b"\n".join((b"[0.1] Calibrating delay loop (skipped)",json.dumps(subject.ADMISSION).encode(),b"Ran 81 tests in 1.0s",b"OK",json.dumps(report).encode(),b"PUBLIC_NATIVE_R4_TESTS=81",b"PUBLIC_NATIVE_R4_IO=9",b"PUBLIC_NATIVE_R4_ROOT=ROOT_RESTORED",b"PUBLIC_NATIVE_R4_EXIT=0",b"PUBLIC_NATIVE_R4_STATUS=OK"))

    def test_boot_skip_is_not_a_test_skip(self):
        self.assertEqual(subject.parse_serial(self.fixture())["tests_passed"],81)
        with self.assertRaises(subject.frozen.Stop): subject.frozen.parse_serial(self.fixture())

    def test_real_skipped_test_still_blocks(self):
        with self.assertRaises(subject.frozen.Stop): subject.parse_serial(self.fixture().replace(b"OK\n",b"OK (skipped=1)\n"))

    def test_missing_duplicate_and_false_admission_block(self):
        admission=json.dumps(subject.ADMISSION).encode()
        for data in (self.fixture().replace(admission,b""),self.fixture()+b"\n"+admission,self.fixture().replace(b'"private_input_opened": false',b'"private_input_opened": true',1)):
            with self.subTest(data=data),self.assertRaises(subject.frozen.Stop): subject.parse_serial(data)

    def test_missing_duplicate_wrong_or_reordered_markers_block(self):
        data=self.fixture()
        for bad in (data.replace(b"PUBLIC_NATIVE_R4_TESTS=81",b""),data+b"\nPUBLIC_NATIVE_R4_TESTS=81",data.replace(b"TESTS=81",b"TESTS=80"),data.replace(b"PUBLIC_NATIVE_R4_ROOT=ROOT_RESTORED",b"PUBLIC_NATIVE_R4_EXIT=0").replace(b"PUBLIC_NATIVE_R4_IO=9",b"PUBLIC_NATIVE_R4_ROOT=ROOT_RESTORED")):
            with self.subTest(data=bad),self.assertRaises(subject.frozen.Stop): subject.parse_serial(bad)

    def test_results_before_boundary_and_failures_block(self):
        for prefix in (b"PUBLIC_NATIVE_R4_STATUS=FAIL\n",b"PUBLIC_NATIVE_R4_CHECK_FAIL=x\n",b"Ran 81 tests in 1.0s\n",b"OK\n"):
            with self.subTest(prefix=prefix),self.assertRaises(subject.frozen.Stop): subject.parse_serial(prefix+self.fixture())
        for suffix in (b"PUBLIC_NATIVE_R4_CHECK_FAIL=x",b"PUBLIC_NATIVE_R4_STATUS=FAIL",b"skipped=1"):
            with self.subTest(suffix=suffix),self.assertRaises(subject.frozen.Stop): subject.parse_serial(self.fixture()+b"\n"+suffix)

    def test_bad_io_and_test_count_block(self):
        for bad in (self.fixture().replace(b'"checks_passed": 9',b'"checks_passed": 8'),self.fixture().replace(b"Ran 81 tests",b"Ran 80 tests"),self.fixture()+b"\nOK"):
            with self.subTest(data=bad),self.assertRaises(subject.frozen.Stop): subject.parse_serial(bad)

if __name__=="__main__": unittest.main()
