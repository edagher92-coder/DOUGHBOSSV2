"""Focused no-VM tests for the R2 framed transport and failed-receipt seam."""
import ast, contextlib, hashlib, importlib, json, os, stat, sys, tempfile, types, unittest
from unittest import mock
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))  # Test-only source path; runtime caller preloads byte-pinned modules.
PROFILE="public_native_installed_r4_profile_r2.py"
EXECUTOR="public_native_installed_r4_executor_r2.py"
CALLER="run_public_native_installed_r4_r2.py"
SOURCE="public_linux_admission_r4.py"

class FramedProfileTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p=importlib.import_module("public_native_installed_r4_profile_r2")
        cls.e=importlib.import_module("public_native_installed_r4_executor_r2")
        cls.source=(HERE/SOURCE).read_bytes()

    def test_short_frames_reconstruct_exact_compressed_bootstrap(self):
        frames,chunks,raw=self.p.framed_commands(self.source)
        self.assertTrue(frames and chunks)
        self.assertTrue(all(len(frame.encode("ascii"))<=self.p.FRAME_LIMIT for frame in frames))
        self.assertLessEqual(sum(len(frame.encode("ascii"))+1 for frame in frames),self.p.WIRE_LIMIT)
        import base64
        self.assertEqual(base64.b64decode("".join(chunks)),raw)
        self.assertEqual(raw,self.p.compressed_bootstrap(self.source))
        staged="".join(chunks).encode("ascii")
        self.assertEqual(hashlib.sha256(staged).hexdigest(),frames[-1].split("echo '")[1].split("  ")[0])
        self.assertTrue(frames[0].startswith("umask 077; set -C; : > "))
        self.assertEqual(hashlib.sha256(self.p.render_guest_bootstrap(self.source)).hexdigest(),
                         frames[-1].split("echo '")[2].split("  ")[0])

    def test_synthetic_exact_echo_and_negative_controls(self):
        frames,_,_=self.p.framed_commands(self.source)
        replies=tuple(frame.encode("ascii")+b"\n" for frame in frames)
        self.e.validate_frame_sequence(frames,replies)
        bad=[replies[:2]+(replies[1],)+replies[3:], replies[:-1],
             replies[:1]+(replies[1]+b"\x13",)+replies[2:],
             replies[:1]+(replies[2],replies[1])+replies[3:],
             replies+(b"extra\n",)]
        for observed in bad:
            with self.subTest(length=len(observed)):
                with self.assertRaises(self.p.Stop): self.e.validate_frame_sequence(frames,tuple(observed))
        overlong=("x"*(self.p.FRAME_LIMIT+1),)+frames[1:]
        with self.assertRaises(self.p.Stop): self.e.validate_frame_sequence(overlong,replies)

    def test_no_later_write_after_first_failed_echo_model(self):
        frames,_,_=self.p.framed_commands(self.source); writes=[]
        replies=[frame.encode("ascii")+b"\n" for frame in frames]; replies[1]+=b"\x13"
        for index,frame in enumerate(frames):
            writes.append(frame)
            try: self.e.strict_frame_echo(frame.encode("ascii")+b"\n",replies[index])
            except self.p.Stop: break
        self.assertEqual(writes, list(frames[:2]))
        self.assertNotIn(frames[2],writes)

    def test_run_transport_stops_before_later_frame_after_xoff(self):
        for delayed in (False,True):
            with self.subTest(delayed=delayed): self._assert_transport_stops_on_xoff(delayed)

    def _assert_transport_stops_on_xoff(self,delayed):
        """Exercise _run's real pacing/send/echo loop with a mocked serial child."""
        e,p=self.e,self.p; frames,_,_=p.framed_commands(self.source); queue=[b"login: "]; sent=[]; completed=[]; children=[]; buffer=bytearray(); frame_index=0; injected=False
        class Stream:
            def fileno(self): return 9
            def close(self): pass
        class In:
            def write(self,data):
                nonlocal frame_index
                sent.append(bytes(data)); buffer.extend(data)
                while b"\n" in buffer:
                    line,_,remaining=buffer.partition(b"\n"); buffer[:]=remaining; command=bytes(line)+b"\n"; completed.append(command)
                    if command==b"root\n": queue.append(command+b"~# ")
                    elif command==e.TERMINAL_HANDSHAKE: queue.append(command)
                    elif command==e.READY_COMMAND: queue.append(command+e.READY_MARKER)
                    else:
                        queue.append(command+(b"\x13" if frame_index==1 and not delayed else b"")); frame_index+=1
                return len(data)
            def flush(self): pass
            def close(self): pass
        class Child:
            pid=73
            def __init__(self,args): self.args=args; self.stdin=In(); self.stdout=Stream(); self.returncode=None; children.append(self)
            def poll(self): return self.returncode
            def terminate(self): self.returncode=0
            def kill(self): self.returncode=0
            def wait(self,timeout=None): self.returncode=0 if self.returncode is None else self.returncode; return self.returncode
        original=(e.subprocess.Popen,e.os.read,e.os.set_blocking,e.time.monotonic,e.time.sleep,e.PROFILE["write_interval"])
        tick=[0.0]
        try:
            e.subprocess.Popen=lambda args,**kwargs: Child(args)
            def read_ready(fd,size):
                nonlocal injected
                if queue: return queue.pop(0)
                if delayed and not injected and len(completed)==4 and sys._getframe(2).f_code.co_name=="send":
                    injected=True; return b"\x13"
                raise BlockingIOError
            e.os.read=read_ready
            e.os.set_blocking=lambda fd,enabled: None
            e.time.monotonic=lambda: tick.__setitem__(0,tick[0]+.0001) or tick[0]
            e.time.sleep=lambda seconds: None; e.PROFILE["write_interval"]=.001
            with self.assertRaisesRegex(e.profile.Stop,"FRAME_BARRIER" if delayed else "FRAME_SUFFIX|SERIAL_ECHO"): e._run(HERE, __import__("io").BytesIO(), self.source)
        finally:
            e.subprocess.Popen,e.os.read,e.os.set_blocking,e.time.monotonic,e.time.sleep,e.PROFILE["write_interval"]=original
        self.assertIn(frames[0].encode("ascii")+b"\n",completed)
        if delayed:
            self.assertTrue(injected)
            self.assertEqual(b"".join(sent),b"root\n"+e.TERMINAL_HANDSHAKE+e.READY_COMMAND+frames[0].encode("ascii")+b"\n")
        else: self.assertIn(frames[1].encode("ascii")+b"\n",completed)
        self.assertNotIn(frames[2].encode("ascii")+b"\n",completed)
        self.assertEqual(len(children),1); self.assertEqual(children[0].returncode,0)

    def test_rejects_invalid_source_and_r1_names_are_not_outputs(self):
        with self.assertRaises(self.p.Stop): self.p.framed_commands(self.source[:-1])
        self.assertNotIn("r1", " ".join(self.p.OUTPUT_NAMES))
        self.assertEqual(self.p.render_guest_bootstrap(self.source),
                         importlib.import_module("public_native_installed_r4_profile_r1").render_guest_bootstrap(self.source))

class FailureReceiptTests(unittest.TestCase):
    def test_exception_emits_failed_receipt_and_preserves_original(self):
        e=importlib.import_module("public_native_installed_r4_executor_r2")
        captured=[]; original=(e._admit,e._verify,e._run,e._write_result,e._create_overlay,e._post_image_checks)
        with tempfile.TemporaryDirectory() as raw:
            root=Path(raw); (root/e.profile.ADMISSION_SOURCE).write_bytes((HERE/SOURCE).read_bytes())
            try:
                e._admit=lambda root,admission:(Path(root),{})
                e._verify=lambda root,pins,previous=None:{}
                e._create_overlay=lambda root:(1,2,3,4)
                e._run=lambda root,log,source:(_ for _ in ()).throw(e.profile.Stop("SYNTHETIC_TRANSPORT"))
                e._post_image_checks=lambda root,overlay:[{"name":"restore-guest.qcow2","ok":True},{"name":e.profile.OVERLAY,"ok":False,"error":"synthetic"}]
                e._write_result=lambda root,payload: captured.append(payload) or True
                with self.assertRaisesRegex(e.profile.Stop,"SYNTHETIC_TRANSPORT"): e.execute(root,object())
            finally: e._admit,e._verify,e._run,e._write_result,e._create_overlay,e._post_image_checks=original
        self.assertEqual(len(captured),1); self.assertEqual(captured[0]["status"],"FAILED")
        self.assertFalse(captured[0]["native_acceptance"]); self.assertEqual(captured[0]["error"],"SYNTHETIC_TRANSPORT")
        self.assertFalse(captured[0]["post_image_checks"][1]["ok"])

    def test_post_pin_drift_is_recorded_without_masking_transport_error(self):
        e=importlib.import_module("public_native_installed_r4_executor_r2"); captured=[]
        original=(e._admit,e._verify,e._run,e._write_result,e._create_overlay,e._post_image_checks)
        with tempfile.TemporaryDirectory() as raw:
            root=Path(raw); (root/e.profile.ADMISSION_SOURCE).write_bytes((HERE/SOURCE).read_bytes()); calls=[]
            try:
                e._admit=lambda root,admission:(Path(root),{})
                def verify(root,pins,previous=None):
                    calls.append(previous)
                    if previous is not None: raise e.profile.Stop("INPUT_IDENTITY:pack")
                    return {}
                e._verify=verify; e._create_overlay=lambda root:(1,2,3,4)
                e._run=lambda root,log,source:(_ for _ in ()).throw(e.profile.Stop("SERIAL_ECHO"))
                e._post_image_checks=lambda root,overlay:[]; e._write_result=lambda root,payload: captured.append(payload) or True
                with self.assertRaisesRegex(e.profile.Stop,"SERIAL_ECHO"): e.execute(root,object())
            finally: e._admit,e._verify,e._run,e._write_result,e._create_overlay,e._post_image_checks=original
        self.assertEqual(captured[0]["error"],"SERIAL_ECHO")
        self.assertEqual(captured[0]["post_pin_error"],"Stop")

class SourceTests(unittest.TestCase):
    def test_ast_and_inert_caller(self):
        for name in (PROFILE,EXECUTOR,CALLER): ast.parse((HERE/name).read_bytes(),filename=name)
        namespace={"__name__":"caller_source_test","__file__":str(HERE/CALLER)}; exec(compile((HERE/CALLER).read_bytes(),str(HERE/CALLER),"exec"),namespace)
        old=sys.argv
        try:
            sys.argv=[str(HERE/CALLER)]
            with self.assertRaisesRegex(SystemExit,"NOT_ADMITTED"): namespace["main"]()
        finally: sys.argv=old

    def test_fresh_outputs_and_unadmitted_draft_only(self):
        p=importlib.import_module("public_native_installed_r4_profile_r2")
        self.assertFalse(any((HERE/name).exists() for name in p.OUTPUT_NAMES))
        plan=HERE/"PUBLIC-NATIVE-INSTALLED-R4-R2-OPERATION.json"
        if plan.exists():
            draft=json.loads(plan.read_bytes())
            self.assertEqual(draft["operation_admission"],"NOT_ADMITTED")
            self.assertEqual(draft["independent_operation_review"],"PENDING")

    def test_closure_inventory_rejects_unexpected_and_missing_files(self):
        caller=importlib.import_module("run_public_native_installed_r4_r2")
        class Pin:
            def __init__(self,name,size,sha256,mtime_ns): self.name,self.size,self.sha256,self.mtime_ns=name,size,sha256,mtime_ns
        def digest(path):
            info=os.stat(path); return (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns),hashlib.sha256(Path(path).read_bytes()).hexdigest()
        fake=types.SimpleNamespace(Pin=Pin,_digest=digest)
        with tempfile.TemporaryDirectory() as raw:
            root=Path(raw); tools=root/"qemu-test-tools"; tools.mkdir()
            excluded=("qemu-test-tools/share/QEMU,cgthree.bin","qemu-test-tools/share/QEMU,tcx.bin")
            for name,data in (("qemu-test-tools/a.bin",b"a"),(excluded[0],b"b"),(excluded[1],b"c")):
                path=root/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(data)
            rows=[]
            for path in sorted(tools.rglob("*")):
                if path.is_file():
                    info=os.stat(path); rows.append({"name":path.relative_to(root).as_posix(),"size":info.st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"mtime_ns":info.st_mtime_ns})
            pins={row["name"]:Pin(row["name"],row["size"],row["sha256"],row["mtime_ns"]) for row in rows}
            caller.compare_tool_inventory(root,pins,excluded,fake)
            (root/excluded[0]).write_bytes(b"changed")
            with self.assertRaisesRegex(RuntimeError,"EXCLUDED_ROM_DRIFT"): caller.compare_tool_inventory(root,pins,excluded,fake)
            (root/excluded[0]).write_bytes(b"b")
            info=os.stat(root/excluded[0]); pins[excluded[0]]=Pin(excluded[0],info.st_size,hashlib.sha256(b"b").hexdigest(),info.st_mtime_ns)
            (tools/"unexpected.bin").write_bytes(b"x")
            with self.assertRaisesRegex(RuntimeError,"TOOL_INVENTORY_DRIFT"): caller.compare_tool_inventory(root,pins,excluded,fake)
            (tools/"unexpected.bin").unlink(); (tools/"a.bin").unlink()
            with self.assertRaisesRegex(RuntimeError,"TOOL_INVENTORY_DRIFT"): caller.compare_tool_inventory(root,pins,excluded,fake)

    def test_closure_reparse_nonregular_and_walk_errors_fail_closed(self):
        caller=importlib.import_module("run_public_native_installed_r4_r2")
        with tempfile.TemporaryDirectory() as raw:
            root=Path(raw); base=root/"qemu-test-tools"; base.mkdir(); real_lstat=os.lstat
            fake_info=types.SimpleNamespace(st_file_attributes=0x400,st_mode=stat.S_IFREG,st_nlink=1)
            with mock.patch("os.lstat",side_effect=lambda path: fake_info if Path(path)==base else real_lstat(path)):
                with self.assertRaisesRegex(RuntimeError,"TOOL_ROOT_NOT_PLAIN_DIRECTORY"): caller.public_files(root,())
            bad_info=types.SimpleNamespace(st_file_attributes=0,st_mode=stat.S_IFDIR,st_nlink=1)
            with mock.patch("os.walk",return_value=[(str(base),[],["not-file"])]), mock.patch("os.lstat",side_effect=lambda path: bad_info if Path(path)==base/"not-file" else real_lstat(path)):
                with self.assertRaisesRegex(RuntimeError,"TOOL_FILE_IDENTITY"): caller.public_files(root,())
            def denied(*unused,**kwargs): kwargs["onerror"](OSError("denied")); return iter(())
            with mock.patch("os.walk",side_effect=denied):
                with self.assertRaises(OSError): caller.public_files(root,())

    def test_closure_duplicate_and_schema_rows_fail_before_inventory(self):
        caller=importlib.import_module("run_public_native_installed_r4_r2")
        with tempfile.TemporaryDirectory() as raw:
            root=Path(raw); (root/"qemu-test-tools").mkdir(); (root/"qemu-test-tools"/"a").write_bytes(b"a")
            info=os.stat(root/"qemu-test-tools"/"a")
            row={"name":"qemu-test-tools/a","size":1,"sha256":hashlib.sha256(b"a").hexdigest(),"mtime_ns":info.st_mtime_ns}
            receipt={"status":"PUBLIC_TOOL_CLOSURE_MATCHED","pins":[row]*3385,"not_profile_dependencies":["qemu-test-tools/share/QEMU,cgthree.bin","qemu-test-tools/share/QEMU,tcx.bin"]}
            data=json.dumps(receipt).encode("ascii"); (root/"closure.json").write_bytes(data)
            plan={"tool_closure_receipt":"closure.json","tool_closure_receipt_sha256":hashlib.sha256(data).hexdigest()}
            fake=types.SimpleNamespace(Pin=lambda name,size,sha256,mtime_ns: types.SimpleNamespace(name=name,size=size,sha256=sha256,mtime_ns=mtime_ns),_digest=lambda path: (_ for _ in ()).throw(AssertionError("no inventory")))
            with self.assertRaisesRegex(RuntimeError,"TOOL_PIN_SCHEMA"): caller.validate_tool_closure(root,plan,fake)

    def test_post_inventory_failure_does_not_replace_operation_failure(self):
        caller=importlib.import_module("run_public_native_installed_r4_r2")
        with self.assertRaisesRegex(ValueError,"operation"):
            caller.preserve_operation_error(lambda: (_ for _ in ()).throw(ValueError("operation")),
                                            lambda: (_ for _ in ()).throw(RuntimeError("post")))
        with self.assertRaisesRegex(RuntimeError,"post"):
            caller.preserve_operation_error(lambda: 0,lambda: (_ for _ in ()).throw(RuntimeError("post")))

    def test_main_streams_large_required_input_without_source_reader(self):
        caller=importlib.import_module("run_public_native_installed_r4_r2")
        real=importlib.import_module("public_native_installed_r4_executor_r2")
        with tempfile.TemporaryDirectory() as raw:
            root=Path(raw); large=root/"large-base.qcow2"
            with large.open("wb") as out: out.truncate(16*1024*1024+1)
            identity,digest=real._digest(large)
            names=(caller.CALLER,caller.PROFILE,caller.R1_PROFILE,caller.EXECUTOR,caller.HELPER,caller.PROBE,caller.GUARD)
            for name in names: (root/name).write_bytes(b"# fixture\n")
            files={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
            profile=types.SimpleNamespace(MODE="TEST",INPUT_PINS={large.name:(identity[2],digest)},OUTPUT_NAMES=(),qemu_argv=lambda root:[],overlay_create_argv=lambda root:[])
            plan={"operation_admission":"OPERATION_ADMITTED_PUBLIC_ONLY","independent_operation_review":"SHIP","public_only":True,"private_backup":False,"one_attempt_only":True,"root":str(root),"files":files,"mode":"TEST","profile_sha256":"profile","qemu_argv":[],"overlay_argv":[],"fresh_output_names":[]}
            data=json.dumps(plan).encode("ascii"); (root/caller.PLAN).write_bytes(data)
            seen=[]
            def execute(root,admission):
                pin=next(pin for pin in admission.pins if pin.name==large.name)
                self.assertEqual((pin.size,pin.sha256),(identity[2],digest)); seen.append(admission)
                return {"status":"PUBLIC_NATIVE_INSTALLED_R4_OK"}
            executor=types.SimpleNamespace(REQUIRED=names+(large.name,),_digest=real._digest,Pin=real.Pin,Admission=real.Admission,APPROVAL="TEST",PROFILE_SHA256="profile",execute=execute)
            with mock.patch.object(caller,"_interpreter"),mock.patch.object(caller,"__file__",str(root/caller.CALLER)),mock.patch.object(Path,"cwd",return_value=root),mock.patch.object(sys,"argv",[caller.CALLER,hashlib.sha256(data).hexdigest()]),mock.patch.object(caller,"_load",return_value=(None,None,None,None,profile,executor)),mock.patch.object(caller,"validate_tool_closure",return_value={}),mock.patch.object(caller,"_read",wraps=caller._read) as small_read,mock.patch.dict(sys.modules):
                self.assertEqual(caller.main(),0)
                self.assertEqual(len(seen),1)
                self.assertNotIn(large.name,[call.args[1] for call in small_read.call_args_list])
                for bad in ((identity[2]+1,digest),(identity[2],"0"*64)):
                    profile.INPUT_PINS={large.name:bad}
                    with self.assertRaisesRegex(RuntimeError,"REQUIRED_INPUT_PIN"): caller.main()
                self.assertEqual(len(seen),1)

if __name__=="__main__": unittest.main()
