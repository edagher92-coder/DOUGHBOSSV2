"""Read-only result replay; never alters or launches the terminal R2 operation."""
import json
import re
import public_native_installed_r4_profile_r1 as frozen

ADMISSION={"format":"NATIVE_ADMISSION_PUBLIC_GUEST_R4","private_input_opened":False,"regular_files":25,"source_files":24,"state":"PUBLIC_SOURCE_ADMITTED"}

def parse_serial(data):
    if type(data) is not bytes or len(data)>4*1024*1024: raise frozen.Stop("SERIAL_BOUND")
    lines=data.replace(b"\r",b"").splitlines(); boundaries=[]
    for index,line in enumerate(lines):
        if not line.startswith(b"{"): continue
        try: record=json.loads(line.decode("ascii"))
        except (UnicodeDecodeError,ValueError):
            if b"NATIVE_ADMISSION_PUBLIC_GUEST_R4" in line: raise frozen.Stop("ADMISSION_REPORT")
            continue
        if type(record) is dict and record.get("format")==ADMISSION["format"]:
            if record!=ADMISSION: raise frozen.Stop("ADMISSION_REPORT")
            boundaries.append(index)
    if len(boundaries)!=1: raise frozen.Stop("ADMISSION_REPORT")
    start=boundaries[0]
    reserved=(b"PUBLIC_NATIVE_R4_TESTS=",b"PUBLIC_NATIVE_R4_IO=",b"PUBLIC_NATIVE_R4_ROOT=",b"PUBLIC_NATIVE_R4_EXIT=",b"PUBLIC_NATIVE_R4_STATUS=",b"PUBLIC_NATIVE_R4_CHECK_FAIL=")
    for line in lines[:start]:
        if line.startswith(reserved) or line==b"OK" or re.fullmatch(rb"Ran [0-9]+ tests in [0-9.]+s",line) or b"NATIVE_ADMISSION_PUBLIC_IO_R2" in line:
            raise frozen.Stop("RESULT_BEFORE_ADMISSION")
    # Scope unittest skip detection to the admitted public run, not kernel boot.
    # Keep every frozen report/count/order/failure/IO check on that full segment.
    frozen.parse_serial(b"\n".join(lines[start:]))
    return {"tests_passed":81,"io_checks_passed":9,"root":"ROOT_RESTORED","private_input_opened":False,"preparation_executed":False}

if __name__=="__main__": raise SystemExit("READ_ONLY_REPLAY_MODULE")
