"""R2 public installed-kernel profile: R1 guest contract with framed serial transport.

R1 is a byte-pinned, read-only source dependency.  This module changes only
fresh host output names and the bounded on-wire staging protocol; it neither
starts a process nor admits an operation on import.
"""
import base64
import hashlib
from pathlib import Path

import public_native_installed_r4_profile_r1 as r1

MODE = "PUBLIC_NATIVE_INSTALLED_R4_R2"
R1_PROFILE = "public_native_installed_r4_profile_r1.py"
BASE, KERNEL, INITRAMFS, TOOL, IMAGE_TOOL = r1.BASE, r1.KERNEL, r1.INITRAMFS, r1.TOOL, r1.IMAGE_TOOL
PACK, MANIFEST, ADMISSION_SOURCE, BOOT_RECEIPT = r1.PACK, r1.MANIFEST, r1.ADMISSION_SOURCE, r1.BOOT_RECEIPT
INPUT_PINS = r1.INPUT_PINS
PACK_BYTES, PACK_SECTORS, PACK_SHA256 = r1.PACK_BYTES, r1.PACK_SECTORS, r1.PACK_SHA256
ADMISSION_SOURCE_BYTES, ADMISSION_SOURCE_SHA256 = r1.ADMISSION_SOURCE_BYTES, r1.ADMISSION_SOURCE_SHA256
APPEND = r1.APPEND
OVERLAY = "public-native-installed-r4-r2-overlay.qcow2"
SERIAL_LOG = "public-native-installed-r4-r2-serial.log"
RESULT = "PUBLIC-NATIVE-INSTALLED-R4-R2-RESULT.json"
OUTPUT_NAMES = (OVERLAY, SERIAL_LOG, RESULT)
FRAME_LIMIT = 768
WIRE_LIMIT = 7000
PAYLOAD_PATH = "/run/public-native-r4-r2.payload"
SCRIPT_PATH = "/run/public-native-r4-r2.sh"

Stop = r1.Stop
_root = r1._root
_checked_admission_source = r1._checked_admission_source
render_guest_bootstrap = r1.render_guest_bootstrap
parse_serial = r1.parse_serial


def overlay_create_argv(root):
    root = _root(root)
    return [str(root / IMAGE_TOOL), "create", "-f", "qcow2", "-F", "qcow2", "-b",
            (root / BASE).as_posix(), (root / OVERLAY).as_posix()]


def qemu_argv(root):
    root = _root(root); p = lambda name: (root / name).as_posix()
    return [str(root / TOOL), "-machine", "pc", "-accel", "tcg,thread=single", "-cpu", "qemu64",
            "-smp", "2", "-m", "2048", "-nodefaults", "-no-user-config", "-display", "none",
            "-monitor", "none", "-serial", "stdio", "-nic", "none", "-no-reboot", "-kernel", p(KERNEL),
            "-initrd", p(INITRAMFS), "-append", APPEND,
            "-drive", f"file={p(OVERLAY)},format=qcow2,if=virtio",
            "-drive", f"file={p(PACK)},format=raw,if=virtio,readonly=on"]


def validate_argv(argv, root):
    if type(argv) is not list or argv != qemu_argv(root): raise Stop("TOPOLOGY")


def compressed_bootstrap(admission_source):
    return r1.compressed_bootstrap(admission_source)


def framed_commands(admission_source):
    """Return strictly ordered, individually echoed commands, all <=768 bytes."""
    raw = compressed_bootstrap(admission_source)
    encoded = base64.b64encode(raw).decode("ascii")
    chunk_size = 640
    chunks = tuple(encoded[offset:offset + chunk_size] for offset in range(0, len(encoded), chunk_size))
    commands = [f"umask 077; set -C; : > {PAYLOAD_PATH}"]
    commands.extend(f"printf '%s' '{chunk}' >> {PAYLOAD_PATH}" for chunk in chunks)
    payload_sha = hashlib.sha256(encoded.encode("ascii")).hexdigest()
    script_sha = hashlib.sha256(render_guest_bootstrap(admission_source)).hexdigest()
    commands.append(
        f"echo '{payload_sha}  {PAYLOAD_PATH}' | sha256sum -c - >/dev/null && "
        f"base64 -d < {PAYLOAD_PATH} | gzip -d > {SCRIPT_PATH} && "
        f"echo '{script_sha}  {SCRIPT_PATH}' | sha256sum -c - >/dev/null && sh {SCRIPT_PATH}"
    )
    result = tuple(commands)
    if (not chunks or any(type(command) is not str or not command or "\n" in command or "\r" in command
                          or len(command.encode("ascii")) > FRAME_LIMIT for command in result)
            or sum(len(command.encode("ascii")) + 1 for command in result) > WIRE_LIMIT):
        raise Stop("WIRE_BUDGET")
    return result, chunks, raw


def render_manifest(root):
    return {"mode": MODE, "operation_admission": "NOT_ADMITTED", "execution_implemented": True,
            "public_only": True, "installed_boot_acceptance": False, "restore_acceptance": False,
            "r1_profile_input": R1_PROFILE, "fresh_output_names": OUTPUT_NAMES,
            "overlay_argv": overlay_create_argv(root), "qemu_argv": qemu_argv(root),
            "frame_limit": FRAME_LIMIT, "wire_limit": WIRE_LIMIT}


if __name__ == "__main__": raise SystemExit("NOT_ADMITTED: R2 source profile only")
