"""R2 exact-plan caller. No plan is supplied or created by this source task."""
PLAN="PUBLIC-NATIVE-INSTALLED-R4-R2-OPERATION.json"
CALLER="run_public_native_installed_r4_r2.py"
PROFILE="public_native_installed_r4_profile_r2.py"
R1_PROFILE="public_native_installed_r4_profile_r1.py"
EXECUTOR="public_native_installed_r4_executor_r2.py"
HELPER="public_installed_boot_probe_executor_r2.py"
PROBE="public_installed_boot_probe_r1.py"
GUARD="public_installed_boot_image_guard_r1.py"
ACTUAL="qemu-test-tools"

def _interpreter():
    import sys
    if not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode): raise SystemExit("NOT_ADMITTED: interpreter -I -S -B")

def _plain(root,name):
    import os,stat
    if type(name) is not str or not name or any(c in name for c in "/\\:\0") or name in (".",".."): raise RuntimeError("BOUND_PATH")
    path=root/name; info=os.lstat(path)
    if getattr(info,"st_file_attributes",0)&0x400 or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1: raise RuntimeError("BOUND_FILE_IDENTITY")
    return path

def _read(root,name,digest):
    import hashlib,os,re
    if type(digest) is not str or re.fullmatch(r"[0-9a-f]{64}",digest) is None: raise RuntimeError("BOUND_HASH")
    path=_plain(root,name); before=os.stat(path); identity=(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)
    if before.st_size>16*1024*1024: raise RuntimeError("BOUND_SIZE")
    with open(path,"rb") as source:
        if (lambda x:(x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns))(os.fstat(source.fileno()))!=identity: raise RuntimeError("BOUND_IDENTITY")
        data=source.read(16*1024*1024+1)
        if len(data)!=before.st_size: raise RuntimeError("BOUND_SIZE")
    if (lambda x:(x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns))(os.stat(path))!=identity or hashlib.sha256(data).hexdigest()!=digest: raise RuntimeError("BOUND_IDENTITY")
    return data

def public_files(root,exclusions):
    """Fail closed over every non-excluded file in the fixed QEMU closure."""
    import os,stat
    from pathlib import Path
    if type(exclusions) is not tuple or any(type(name) is not str for name in exclusions): raise RuntimeError("EXCLUSION_SCHEMA")
    base=root/ACTUAL; info=os.lstat(base)
    if getattr(info,"st_file_attributes",0)&0x400 or not stat.S_ISDIR(info.st_mode): raise RuntimeError("TOOL_ROOT_NOT_PLAIN_DIRECTORY")
    def walk_error(error): raise error
    found=[]
    for directory,dirs,files in os.walk(base,followlinks=False,onerror=walk_error):
        for name in dirs:
            info=os.lstat(Path(directory)/name)
            if getattr(info,"st_file_attributes",0)&0x400 or not stat.S_ISDIR(info.st_mode): raise RuntimeError("TOOL_DIRECTORY_IDENTITY")
        for name in files:
            path=Path(directory)/name; info=os.lstat(path)
            if getattr(info,"st_file_attributes",0)&0x400 or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1: raise RuntimeError("TOOL_FILE_IDENTITY")
            relative=path.relative_to(root).as_posix()
            if relative not in exclusions: found.append(relative)
    return tuple(sorted(found))

def compare_tool_inventory(root,pins,exclusions,executor):
    if set(public_files(root,exclusions))!=set(pins)-set(exclusions): raise RuntimeError("TOOL_INVENTORY_DRIFT")
    for name,pin in pins.items():
        identity,actual=executor._digest(root.joinpath(*__import__("pathlib").PurePosixPath(name).parts))
        if identity[2]!=pin.size or identity[3]!=pin.mtime_ns or actual!=pin.sha256:
            raise RuntimeError("EXCLUDED_ROM_DRIFT" if name in exclusions else "TOOL_PIN_DRIFT")

def preserve_operation_error(operation,post_inventory):
    """Run the post-inventory proof without replacing an operation exception."""
    operation_error=None
    try: return operation()
    except BaseException as error:
        operation_error=error
        raise
    finally:
        try: post_inventory()
        except BaseException as post_error:
            if operation_error is None: raise
            print("POST_OPERATION_TOOL_CLOSURE_FAILED:"+type(post_error).__name__,file=__import__("sys").stderr)

def validate_tool_closure(root,plan,executor):
    import json
    name=plan.get("tool_closure_receipt"); digest=plan.get("tool_closure_receipt_sha256")
    closure=json.loads(_read(root,name,digest).decode("ascii"))
    if type(closure) is not dict: raise RuntimeError("TOOL_CLOSURE_SCHEMA")
    rows=closure.get("pins")
    exclusions=tuple(closure.get("not_profile_dependencies",()))
    expected_exclusions={"qemu-test-tools/share/QEMU,cgthree.bin","qemu-test-tools/share/QEMU,tcx.bin"}
    if (type(closure) is not dict or closure.get("status")!="PUBLIC_TOOL_CLOSURE_MATCHED" or type(rows) is not list or len(rows)!=3385 or set(exclusions)!=expected_exclusions): raise RuntimeError("TOOL_CLOSURE_SCHEMA")
    pins={}
    for row in rows:
        if (type(row) is not dict or set(row)!={"name","size","sha256","mtime_ns"} or row["name"] in pins
                or type(row["name"]) is not str or type(row["size"]) is not int or row["size"]<0
                or type(row["mtime_ns"]) is not int or row["mtime_ns"]<=0): raise RuntimeError("TOOL_PIN_SCHEMA")
        pin=executor.Pin(row["name"],row["size"],row["sha256"],row["mtime_ns"])
        pins[pin.name]=pin
    compare_tool_inventory(root,pins,exclusions,executor)
    return pins

def _load(root,sources):
    import sys,types
    order=(PROBE[:-3],GUARD[:-3],HELPER[:-3],R1_PROFILE[:-3],PROFILE[:-3],EXECUTOR[:-3])
    if any(name in sys.modules for name in order): raise RuntimeError("LOCAL_MODULE_PRELOADED")
    loaded=[]
    try:
        for name in order:
            module=types.ModuleType(name); module.__file__=str(root/(name+".py")); module.__package__=""; sys.modules[name]=module; loaded.append(module)
            exec(compile(sources[name+".py"],module.__file__,"exec",dont_inherit=True),module.__dict__)
        return tuple(loaded)
    except BaseException:
        for module in loaded:
            if sys.modules.get(module.__name__) is module: del sys.modules[module.__name__]
        raise

def main():
    import json,pathlib,sys
    _interpreter(); root=pathlib.Path.cwd().absolute()
    if len(sys.argv)!=2: raise SystemExit("NOT_ADMITTED: exact operation-plan SHA-256 required")
    plan=json.loads(_read(root,PLAN,sys.argv[1]).decode("ascii"))
    expected={CALLER,PROFILE,R1_PROFILE,EXECUTOR,HELPER,PROBE,GUARD}
    if (type(plan) is not dict or plan.get("operation_admission")!="OPERATION_ADMITTED_PUBLIC_ONLY" or plan.get("independent_operation_review")!="SHIP" or plan.get("public_only") is not True or plan.get("private_backup") is not False or plan.get("one_attempt_only") is not True or plan.get("root")!=str(root) or type(plan.get("files")) is not dict or set(plan["files"])!=expected): raise RuntimeError("NOT_ADMITTED")
    sources={name:_read(root,name,digest) for name,digest in plan["files"].items()}
    if pathlib.Path(__file__).absolute()!=_plain(root,CALLER): raise RuntimeError("CALLER_LOCATION")
    _,_,_,_,profile,executor=_load(root,sources)
    try:
        if plan.get("mode")!=profile.MODE or plan.get("profile_sha256")!=executor.PROFILE_SHA256 or plan.get("qemu_argv")!=profile.qemu_argv(root) or plan.get("overlay_argv")!=profile.overlay_create_argv(root) or plan.get("fresh_output_names")!=list(profile.OUTPUT_NAMES): raise RuntimeError("PROFILE_PIN")
        tool_pins=validate_tool_closure(root,plan,executor)
        pins=list(tool_pins.values())
        for name in executor.REQUIRED:
            if name in tool_pins: continue
            identity,digest=executor._digest(_plain(root,name))
            expected_size,expected_digest=profile.INPUT_PINS.get(name,(None,plan["files"].get(name)))
            if digest!=expected_digest or (expected_size is not None and identity[2]!=expected_size): raise RuntimeError("REQUIRED_INPUT_PIN")
            pins.append(executor.Pin(name,identity[2],digest))
        admission=executor.Admission(str(root),plan["files"][EXECUTOR],plan["files"][PROFILE],plan["files"][R1_PROFILE],plan["files"][HELPER],plan["profile_sha256"],tuple(pins),executor.APPROVAL,True)
        return preserve_operation_error(
            lambda: 0 if executor.execute(root,admission).get("status")=="PUBLIC_NATIVE_INSTALLED_R4_OK" else 1,
            lambda: validate_tool_closure(root,plan,executor))
    finally:
        for name in (EXECUTOR[:-3],PROFILE[:-3],R1_PROFILE[:-3],HELPER[:-3],GUARD[:-3],PROBE[:-3]): sys.modules.pop(name,None)

if __name__=="__main__": raise SystemExit(main())
