"""Machine preflight only: project approval in memory, forbid every VM child."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
from unittest import mock

ROOT = Path(r"C:\Codex\Temp\doughboss-linux-restore-20261014-9bd2e853")
PROPOSAL = "PRIVATE-NATIVE-INSTALLED-R4-R1-PROPOSAL.json"
PS = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")

def run():
    assert sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode
    assert Path.cwd() == ROOT and len(sys.argv) == 2
    sys.path.insert(0, str(ROOT))
    import run_private_native_installed_r4_r1 as caller
    original_read = caller._read
    original_load = caller._load
    original_popen = subprocess.Popen
    proposal_sha = sys.argv[1]
    raw = original_read(ROOT, PROPOSAL, proposal_sha)
    proposal = json.loads(raw.decode("ascii"))
    assert proposal["operation_admission"] == "NOT_ADMITTED"
    assert proposal["independent_operation_review"] == "PENDING"
    approved = dict(proposal)
    approved["operation_admission"] = "OPERATION_ADMITTED_PRIVATE_R4_DIAGNOSTIC_ONLY"
    approved["independent_operation_review"] = "SHIP"
    projected = json.dumps(approved, sort_keys=True).encode("ascii")
    projected_sha = hashlib.sha256(projected).hexdigest()
    counters = {"metadata_children": 0, "forbidden_child_attempts": 0, "executor_stub_calls": 0}
    proof = {}

    def guarded_popen(args, *positional, **kwargs):
        allowed = (type(args) is list and len(args) == 6 and args[0] == str(PS)
                   and args[1:5] == ["-NoLogo", "-NoProfile", "-NonInteractive", "-EncodedCommand"]
                   and kwargs.get("creationflags") == 0x08000000 and kwargs.get("shell") is False
                   and kwargs.get("stdin") == subprocess.DEVNULL
                   and kwargs.get("stdout") == subprocess.PIPE and kwargs.get("stderr") == subprocess.PIPE
                   and set(kwargs.get("env", {})) <= {"SystemRoot", "WINDIR"})
        if not allowed:
            counters["forbidden_child_attempts"] += 1
            raise RuntimeError("CHILD_FORBIDDEN")
        counters["metadata_children"] += 1
        return original_popen(args, *positional, **kwargs)

    def projected_read(root, name, digest, *args, **kwargs):
        if name == caller.PLAN:
            assert root == ROOT and digest == projected_sha
            assert original_read(ROOT, PROPOSAL, proposal_sha) == raw
            return projected
        return original_read(root, name, digest, *args, **kwargs)

    def loaded_with_stub(root, sources):
        modules = original_load(root, sources)
        executor = modules[-1]
        def no_vm(root, admission):
            counters["executor_stub_calls"] += 1
            assert counters["executor_stub_calls"] == 1
            actual_root, pins, output = executor._admit(root, admission)
            identities = executor._verify(actual_root, pins)
            assert not list(output.iterdir())
            proof.update({"admitted_input_pins_verified": len(identities), "output_still_empty": True})
            return {"status": "STOPPED_DIAGNOSTIC"}
        executor.execute = no_vm
        return modules

    original_argv = sys.argv[:]
    captured = io.StringIO()
    try:
        sys.argv = [str(ROOT / caller.CALLER), projected_sha]
        with mock.patch.object(caller, "_read", side_effect=projected_read), \
                mock.patch.object(caller, "_load", side_effect=loaded_with_stub), \
                mock.patch.object(subprocess, "Popen", side_effect=guarded_popen), \
                contextlib.redirect_stdout(captured):
            assert caller.main() == 0
    finally:
        sys.argv = original_argv
    assert json.loads(captured.getvalue()) == {"format": "PRIVATE_NATIVE_INSTALLED_R4_R1_HOST", "status": "STOPPED_DIAGNOSTIC"}
    assert counters["executor_stub_calls"] == 1 and counters["forbidden_child_attempts"] == 0
    assert original_read(ROOT, PROPOSAL, proposal_sha) == raw
    return {"format": "PRIVATE_NATIVE_R4_HOST_PREFLIGHT_R1", "status": "PREFLIGHT_PASSED_NO_VM",
            "proposal_sha256": hashlib.sha256(raw).hexdigest(), "approval_projected_in_memory_only": True,
            "persisted_operation_admitted": False, "qemu_execution_stubbed": True,
            "private_contents_read": False, "vm_started": False, "restore_acceptance": False,
            "release_acceptance": False, **counters, **proof}

if __name__ == "__main__":
    try:
        result = run()
    except BaseException:
        print(json.dumps({"format": "PRIVATE_NATIVE_R4_HOST_PREFLIGHT_R1", "status": "PREFLIGHT_FIXED_FAILURE", "vm_started": False}))
        raise SystemExit(1)
    print(json.dumps(result, sort_keys=True))
