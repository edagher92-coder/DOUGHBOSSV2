import os,stat,hashlib,tarfile,io,json,re
from pathlib import Path
S=291328
H='5c964fbae749c4ed909bbe1336d6af6ccc91fc6909f17fc4b075993e06f44a6a'
MH='0950dd5840e3df6745c9fa89ecb0d0db7295f2b4c5b5f3c89a5386b515d7179e'
MN='NATIVE-ADMISSION-PUBLIC-SOURCE-r3.json'
T=Path('/root/private-native-admission-public-r3')
assert os.geteuid()==os.getegid()==0
assert set(os.listdir('/sys/class/net'))=={'lo'}
expected={'vda','vda1','vda2','vdb','vdc'}|{'loop'+str(i) for i in range(8)}
assert set(os.listdir('/sys/class/block'))==expected
assert all(not os.path.lexists('/sys/class/block/loop'+str(i)+'/loop/backing_file') for i in range(8))
for p in (Path('/'),T.parent):
 s=os.lstat(p)
 assert stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and not s.st_mode&0o022
assert not os.path.lexists(T)
d=os.lstat('/dev/vdb')
assert stat.S_ISBLK(d.st_mode) and d.st_uid==0 and d.st_gid==6 and stat.S_IMODE(d.st_mode)==0o660
K=Path('/sys/class/block/vdb')
assert (K/'ro').read_text().strip()=='1' and (K/'size').read_text().strip()=='569'
assert (K/'dev').read_text().strip()==str(os.major(d.st_rdev))+':'+str(os.minor(d.st_rdev))
with os.fdopen(os.open('/dev/vdb',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC),'rb') as f:
 b=f.read(S+1)
 z=os.fstat(f.fileno())
 assert (z.st_dev,z.st_ino,z.st_rdev)==(d.st_dev,d.st_ino,d.st_rdev)
assert len(b)==S and hashlib.sha256(b).hexdigest()==H
with tarfile.open(fileobj=io.BytesIO(b),mode='r:') as t:
 ms=t.getmembers()
 assert len(ms)==19 and len({m.name for m in ms})==19
 assert all(m.type==tarfile.REGTYPE and m.uid==m.gid==0 and not m.pax_headers and not m.linkname and 0<m.size<=65536 and re.fullmatch(r'[A-Za-z0-9_.-]+',m.name) and not m.mode&0o7000 for m in ms)
 data={m.name:t.extractfile(m).read() for m in ms}
assert hashlib.sha256(data[MN]).hexdigest()==MH
doc=json.loads(data[MN])
assert doc['format']==1 and doc['scope']=='PUBLIC_SYNTHETIC_ONLY_NO_PRIVATE_INPUT'
es=doc['sourceFiles']
assert len(es)==18 and len({e['Path'] for e in es})==18
assert set(data)=={e['Path'] for e in es}|{MN}
for e in es:
 v=data[e['Path']]
 assert len(v)==e['Bytes'] and hashlib.sha256(v).hexdigest().upper()==e['Sha256']
os.mkdir(T,0o700)
fd=os.open(T,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
 os.fchmod(fd,0o700)
 for name,v in data.items():
  with os.fdopen(os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=fd),'wb') as f:
   os.fchmod(f.fileno(),0o600)
   assert f.write(v)==len(v)
   f.flush()
   os.fsync(f.fileno())
 os.fsync(fd)
finally:
 os.close(fd)
s=os.lstat(T)
assert stat.S_ISDIR(s.st_mode) and stat.S_IMODE(s.st_mode)==0o700 and s.st_uid==s.st_gid==0
assert set(os.listdir(T))==set(data)
for name,v in data.items():
 s=os.lstat(T/name)
 assert stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600 and (T/name).read_bytes()==v
# Private bytes are touched only after all public code and extraction pins match.
assert not os.path.lexists('/restore-native-admission-r3')
assert not os.path.lexists('/restore-native-preparation-r1')
d=os.lstat('/dev/vdc')
assert stat.S_ISBLK(d.st_mode) and d.st_uid==0 and d.st_gid==6 and stat.S_IMODE(d.st_mode)==0o660
K=Path('/sys/class/block/vdc')
assert (K/'ro').read_text().strip()=='1' and (K/'size').read_text().strip()=='870'
assert (K/'dev').read_text().strip()==str(os.major(d.st_rdev))+':'+str(os.minor(d.st_rdev))
with os.fdopen(os.open('/dev/vdc',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC),'rb') as f:
 capsule=f.read(445441)
 z=os.fstat(f.fileno())
 assert (z.st_dev,z.st_ino,z.st_rdev)==(d.st_dev,d.st_ino,d.st_rdev)
assert len(capsule)==445440 and hashlib.sha256(capsule).hexdigest()=='9bb9a033757b39462e8b265d7d6452d3cf139fbe98a65543ed52f6e11099cb52'
print(json.dumps({'format':'NATIVE_ADMISSION_PRIVATE_GUEST_R3','state':'PUBLIC_AND_READONLY_CAPSULE_ADMITTED','regular_public_files':19,'public_source_files':18,'capsule_hash_readonly_match':True,'binding_executed':False},sort_keys=True))
