"""Bind one approved native backup offline; never import, boot or prepare SQL output."""
import argparse
import builtins
import contextlib
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import types

WRAPPER_SHA = "29e16f840e93f1ee60f807b9fc3e55a1bc25d35faa8eba64a0acc78e29d417ad"
COMPRESSED_SHA = "cbb3efe50fc888856d67c8718a640cc405d4447a482efed16dde94b287ae83a7"
DECOMPRESSED_SHA = "5610af62175bb9eab0d5f3c24813aa29e1641f12f89d9b3110a1c1fc574d7b19"
CAPSULE_SHA = "9bb9a033757b39462e8b265d7d6452d3cf139fbe98a65543ed52f6e11099cb52"
COMPRESSED_BYTES, DECOMPRESSED_BYTES, CAPSULE_BYTES = 445129, 1974648, 445440
REASONS_SHA = "57c182d0b63bc6d6a2403e8158139fe135d339625e264be4b0cc4466935a7867"
STRUCTURE_SHA = "aefa623532a36e442aebe7ecf162fb8c3a2b97d1dd1cbcbb10096925c437b7c2"
ROOT = Path("/restore-native-admission-r4")
DEVICE = Path("/dev/vdc")
SOURCE_NAME, ADMISSION_NAME = "native-source.sql.gz", "admission.json"
CATEGORIES = {"ADMISSION", "ENVIRONMENT", "SOURCE", "GZIP", "PREFIX_BINDING",
              "PRIVACY", "FRESHNESS", "OUTPUT", "INTERNAL"}


PREFIX_STAGES = frozenset({"INTERFACE", "SOURCE_MARKER_OR_GUARD", "CREATE_INVENTORY",
                           "PREFIX_CANDIDATE", "CROSS_PREFIX", "NATIVE_PREFLIGHT", "METADATA_MISMATCH"})


PREFIX_REASONS = frozenset({"UNCLASSIFIED", *(f"G{number:03d}" for number in range(1, 73))})


def _closed_prefix_reason(error):
    """Read only plain exception data; never invoke a supplied reason accessor."""
    try:
        namespace = BaseException.__dict__["__dict__"].__get__(error)
        if type(namespace) is not dict or len(namespace) > 16:
            return "UNCLASSIFIED"
        reason = None
        for key, value in dict.items(namespace):
            if type(key) is not str:
                return "UNCLASSIFIED"
            if key == "reason":
                reason = value
        if type(reason) is str and reason in PREFIX_REASONS:
            return reason
    except BaseException:
        pass
    return "UNCLASSIFIED"



STRUCTURE_CONTEXTS = frozenset({"INSERT_VALUE", "CREATE_DEFAULT"})
TOKEN_KINDS = frozenset({"WORD", "IDENT", "SYMBOL"})


def _closed_prefix_structure(error):
    try:
        namespace = BaseException.__dict__["__dict__"].__get__(error)
        if type(namespace) is not dict or len(namespace) > 16:
            return ("UNCLASSIFIED", "UNCLASSIFIED")
        context, kind = None, None
        for key, value in dict.items(namespace):
            if type(key) is not str:
                return ("UNCLASSIFIED", "UNCLASSIFIED")
            if key == "structure_context":
                context = value
            elif key == "token_kind":
                kind = value
        if (type(context) is str and context in STRUCTURE_CONTEXTS
                and type(kind) is str and kind in TOKEN_KINDS):
            return (context, kind)
    except BaseException:
        pass
    return ("UNCLASSIFIED", "UNCLASSIFIED")


class BindingStop(Exception):
    def __init__(self, category):
        self.category = category if category in CATEGORIES else "INTERNAL"
        super().__init__(self.category)


def need(value, category):
    if not value:
        raise BindingStop(category)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def valid_sha(value):
    return type(value) is str and len(value) == 64 and all(c in "0123456789abcdefABCDEF" for c in value)


def split_capsule(data, compressed_bytes, compressed_sha, capsule_sha):
    """Pure seam for public fixtures; production supplies only the fixed pins above."""
    need(type(data) is bytes and 0 < len(data) <= 2 * 1024**2 and len(data) % 512 == 0, "SOURCE")
    need(type(compressed_bytes) is int and 0 < compressed_bytes <= len(data), "SOURCE")
    need(len(data) - compressed_bytes < 512 and valid_sha(compressed_sha) and valid_sha(capsule_sha), "SOURCE")
    need(sha(data) == capsule_sha.lower(), "SOURCE")
    compressed = data[:compressed_bytes]
    need(not any(data[compressed_bytes:]) and sha(compressed) == compressed_sha.lower(), "SOURCE")
    return compressed


def module_snapshot(data, name, filename):
    module = types.ModuleType(name)
    module.__file__ = str(filename)
    exec(compile(data, "<bound-public-code>", "exec"), module.__dict__)
    return module


def diagnostic_snapshot(data, name, filename, dependencies):
    """Compile only pinned diagnostic bytes with explicit pinned imports."""
    need(type(dependencies) is dict and len(dependencies) <= 2, "SOURCE")
    for key, value in dict.items(dependencies):
        need(type(key) is str
             and key in {"native_prefix_reasons_r3", "native_g056_structure_r1"}
             and type(value) is types.ModuleType, "SOURCE")
    admitted = dict(dependencies)

    def import_pinned(name, globals=None, locals=None, fromlist=(), level=0):
        need(type(name) is str and type(level) is int and level == 0, "SOURCE")
        if name in admitted:
            return admitted[name]
        need(name in {"types", "sys"}, "SOURCE")
        return builtins.__import__(name, globals, locals, fromlist, level)

    module = types.ModuleType(name)
    module.__file__ = str(filename)
    local_builtins = dict(vars(builtins))
    local_builtins["__import__"] = import_pinned
    module.__dict__["__builtins__"] = local_builtins
    exec(compile(data, "<bound-public-diagnostic>", "exec"), module.__dict__)
    return module


def bootstrap_wrapper():
    # Root separately admits the fresh public pack/ancestors before this entrypoint.
    need(os.name == "posix" and os.geteuid() == os.getegid() == 0 and sys.platform == "linux", "ENVIRONMENT")
    source = Path(__file__).absolute().with_name("native_source_preparation_r2.py")
    fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        need(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0
             and stat.S_IMODE(info.st_mode) == 0o600 and 0 < info.st_size <= 65536, "PRIVACY")
        snapshot = stream.read(65537)
        need(len(snapshot) == info.st_size and sha(snapshot) == WRAPPER_SHA, "SOURCE")
    return module_snapshot(snapshot, "bound_preparation_wrapper", source)


def block_identity(info):
    return (info.st_dev, info.st_ino, info.st_rdev, info.st_uid, info.st_gid, info.st_mode)


@contextlib.contextmanager
def readonly_block(prep, device, size):
    """vdb is only the public test seam; the production entrypoint fixes vdc."""
    need(device in {Path("/dev/vdb"), DEVICE} and type(size) is int
         and 0 < size <= 2 * 1024**2 and size % 512 == 0, "ADMISSION")
    with prep.trusted_directory(device.parent) as parent:
        fd = os.open(device.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        need(stat.S_ISBLK(info.st_mode) and info.st_uid == 0, "PRIVACY")
        kernel = Path("/sys/class/block") / device.name
        expected_dev = str(os.major(info.st_rdev)) + ":" + str(os.minor(info.st_rdev))
        need((kernel / "dev").read_text().strip() == expected_dev
             and (kernel / "ro").read_text().strip() == "1"
             and (kernel / "size").read_text().strip() == str(size // 512), "SOURCE")
        identity = block_identity(info)

        def snapshot():
            need(block_identity(os.fstat(stream.fileno())) == identity, "SOURCE")
            stream.seek(0)
            data = stream.read(size + 1)
            need(type(data) is bytes and len(data) == size, "SOURCE")
            return data

        initial = snapshot()
        yield initial, snapshot


def private_new(directory_fd, name, data):
    need(name in {SOURCE_NAME, ADMISSION_NAME} and type(data) is bytes, "OUTPUT")
    fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                 0o600, dir_fd=directory_fd)
    with os.fdopen(fd, "w+b") as stream:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0, "PRIVACY")
        os.fchmod(fd, 0o600)
        stream.write(data)
        stream.flush()
        os.fsync(fd)
        stream.seek(0)
        need(stream.read(len(data) + 1) == data and stat.S_IMODE(os.fstat(fd).st_mode) == 0o600, "OUTPUT")


def write_binding(prep, compressed, admission_bytes):
    with prep.trusted_directory(ROOT.parent) as parent:
        need(not os.path.lexists(ROOT), "FRESHNESS")
        os.mkdir(ROOT.name, 0o700, dir_fd=parent)
        fd = os.open(ROOT.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
        try:
            info = os.fstat(fd)
            need(stat.S_ISDIR(info.st_mode) and info.st_uid == info.st_gid == 0, "PRIVACY")
            os.fchmod(fd, 0o700)
            private_new(fd, SOURCE_NAME, compressed)
            private_new(fd, ADMISSION_NAME, admission_bytes)
            os.fsync(fd)
        finally:
            os.close(fd)
        os.fsync(parent)


def bind(builder_sha, prefix_sha, *, allowed=False):
    need(allowed is True and valid_sha(builder_sha) and valid_sha(prefix_sha), "ADMISSION")
    prep = bootstrap_wrapper()
    prep.safe_environment()
    need(not os.path.lexists(ROOT) and not os.path.lexists(prep.ROOT), "FRESHNESS")
    public = Path(__file__).absolute().parent
    with contextlib.ExitStack() as stack:
        pins = []
        for filename, expected in ((Path(__file__).name, builder_sha),
                ("native_source_preparation_r2.py", WRAPPER_SHA),
                ("restore_preparer_r3_indexed_r1.py", prep.BASE_SHA),
                ("restore_preparer_native_r1.py", prep.NATIVE_SHA),
                ("native_prefix_structure_r4.py", prefix_sha),
                               ("native_prefix_reasons_r3.py", REASONS_SHA),
                               ("native_g056_structure_r1.py", STRUCTURE_SHA)):
            pins.append(stack.enter_context(prep.Pinned(public / filename, expected, 65536)))
        base, native = prep.load_dependencies(pins[2].snapshot, pins[3].snapshot)
        reasons = diagnostic_snapshot(pins[5].snapshot, "bound_native_reasons",
                                      public / "native_prefix_reasons_r3.py", {})
        structure = diagnostic_snapshot(pins[6].snapshot, "bound_native_structure",
                                        public / "native_g056_structure_r1.py",
                                        {"native_prefix_reasons_r3": reasons})
        prefixer = diagnostic_snapshot(pins[4].snapshot, "bound_native_prefix",
                                       public / "native_prefix_structure_r4.py",
                                       {"native_prefix_reasons_r3": reasons,
                                        "native_g056_structure_r1": structure})
        with readonly_block(prep, DEVICE, CAPSULE_BYTES) as (capsule, reread):
            compressed = split_capsule(capsule, COMPRESSED_BYTES, COMPRESSED_SHA, CAPSULE_SHA)
            facts = {"compressed_bytes": COMPRESSED_BYTES, "compressed_sha256": COMPRESSED_SHA,
                     "max_compressed_bytes": COMPRESSED_BYTES, "decompressed_bytes": DECOMPRESSED_BYTES,
                     "decompressed_sha256": DECOMPRESSED_SHA, "max_decompressed_bytes": DECOMPRESSED_BYTES}
            original = prep.decompress_exact(compressed, facts)
            text = original.decode("utf-8", "strict")
            prefix, normalized_text, metadata = prefixer.derive_native_prefix(text, base, native)
            admission = {"format": 1, "phase": "NATIVE_SOURCE_PREPARATION_R1",
                         "preparation_allowed": True, "wrapper_sha256": WRAPPER_SHA,
                         "base_sha256": prep.BASE_SHA, "native_sha256": prep.NATIVE_SHA,
                         "source_path": str(ROOT / SOURCE_NAME), "prefix": prefix,
                         "create_count": 58, "insert_target_count": 30, **facts}
            prep.validate_admission(admission, WRAPPER_SHA)
            actual_original, normalized, receipt = prep.prepare_snapshot(compressed, admission, WRAPPER_SHA, base, native)
            need(actual_original == original and normalized == normalized_text.encode("utf-8")
                 and receipt["normalization"] == metadata, "SOURCE")
            admission_bytes = prep.canonical(admission)
            for pin in pins:
                pin.check()
            need(reread() == capsule, "SOURCE")
            prep.safe_environment()
            write_binding(prep, compressed, admission_bytes)
            for pin in pins:
                pin.check()
            need(reread() == capsule, "SOURCE")
            with prep.Pinned(ROOT / SOURCE_NAME, COMPRESSED_SHA, COMPRESSED_BYTES, COMPRESSED_BYTES) as source_pin, \
                 prep.Pinned(ROOT / ADMISSION_NAME, sha(admission_bytes), 65536, len(admission_bytes)) as admission_pin:
                source_pin.check()
                admission_pin.check()
            return {"state": "ADMISSION_BOUND", "admission_sha256": sha(admission_bytes),
                    "compressed_sha256": COMPRESSED_SHA, "compressed_bytes": COMPRESSED_BYTES,
                    "decompressed_sha256": DECOMPRESSED_SHA, "decompressed_bytes": DECOMPRESSED_BYTES,
                    "normalized_sha256": sha(normalized), "normalized_bytes": len(normalized),
                    "create_count": 58, "insert_target_count": 30}


def main(argv=None):
    result, code = {"state": "STOPPED", "category": "INTERNAL"}, 1
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--bind-native-admission-r4", action="store_true")
    parser.add_argument("--builder-sha256", required=True)
    parser.add_argument("--prefix-sha256", required=True)
    try:
        with contextlib.redirect_stderr(types.SimpleNamespace(write=lambda unused: None, flush=lambda: None)):
            args = parser.parse_args(argv)
        result = bind(args.builder_sha256, args.prefix_sha256, allowed=args.bind_native_admission_r4)
        code = 0
    except BaseException as exc:
        category = getattr(exc, "category", "INTERNAL")
        result = {"state": "STOPPED", "category": category if category in CATEGORIES else "INTERNAL"}
        stage = getattr(exc, "stage", None)
        if category == "PREFIX_BINDING" and type(stage) is str and stage in PREFIX_STAGES:
            result["stage"] = stage
            if stage == "NATIVE_PREFLIGHT":
                result["reason"] = _closed_prefix_reason(exc)
                if result["reason"] == "G056":
                    result["structure_context"], result["token_kind"] = _closed_prefix_structure(exc)
    result.update(format="NATIVE_ADMISSION_BINDING_R4", preparation_executed=False,
                  database_started=False, application_boot_allowed=False,
                  restore_acceptance=False, release_acceptance=False)
    print(json.dumps(result, sort_keys=True))
    return code


if __name__ == "__main__":
    sys.exit(main())

