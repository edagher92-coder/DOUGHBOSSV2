import ast,contextlib,hashlib,importlib,io,json,pathlib,sys,unittest
from unittest import mock
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
c=importlib.import_module("private_native_r4_contract_r1")

class ContractTests(unittest.TestCase):
    def stopped(self):
        return dict(format="NATIVE_ADMISSION_BINDING_R4",state="STOPPED",category="PREFIX_BINDING",stage="NATIVE_PREFLIGHT",reason="G056",structure_context="INSERT_VALUE",token_kind="WORD",**{k:False for k in c.FLAGS})
    def bound(self):
        return dict(format="NATIVE_ADMISSION_BINDING_R4",state="ADMISSION_BOUND",admission_sha256="a"*64,compressed_sha256=c.COMPRESSED_SHA,decompressed_sha256=c.DECOMPRESSED_SHA,normalized_sha256="b"*64,compressed_bytes=445129,decompressed_bytes=1974648,normalized_bytes=100,create_count=58,insert_target_count=30,**{k:False for k in c.FLAGS})
    def raw(self,obj): return json.dumps(obj).encode("ascii")
    def reject(self,obj,code=1):
        with self.assertRaises(c.ContractStop) as caught: c.parse_binding(self.raw(obj),code)
        self.assertEqual(str(caught.exception),"NOT_ADMITTED")
    def test_exact_stopped_and_bound(self):
        self.assertEqual(c.parse_binding(self.raw(self.stopped()),1),self.stopped())
        self.assertEqual(c.parse_binding(self.raw(self.bound()),0),self.bound())
        for category in c.CATEGORIES:
            obj=dict(format="NATIVE_ADMISSION_BINDING_R4",state="STOPPED",category=category,**{k:False for k in c.FLAGS})
            c.parse_binding(self.raw(obj),1)
    def test_flags_extra_raw_fields_and_exit_codes_reject(self):
        for flag in c.FLAGS:
            for value in (True,0,None): self.reject({**self.stopped(),flag:value})
            obj=self.stopped(); del obj[flag]; self.reject(obj)
        for key in ("sql","prefix","identifier","ordinal","traceback","error","value"): self.reject({**self.stopped(),key:"synthetic-only"})
        self.reject(self.stopped(),0); self.reject(self.bound(),1)
    def test_stage_reason_and_structure_domains(self):
        for key in ("category","stage","reason","structure_context","token_kind"):
            for value in ("unknown",[],{},None,False): self.reject({**self.stopped(),key:value})
        for key,value in (("category","SOURCE"),("stage","INTERFACE"),("reason","G055"),("structure_context","UNCLASSIFIED"),("token_kind","UNCLASSIFIED")):
            self.reject({**self.stopped(),key:value})
        obj=self.stopped(); obj.update(structure_context="UNCLASSIFIED",token_kind="UNCLASSIFIED"); c.parse_binding(self.raw(obj),1)
    def test_duplicate_json_trailing_stderr_and_bounds(self):
        good=self.raw(self.stopped())
        for bad in (good+good,b'{"state":"STOPPED","state":"STOPPED"}',b'null',b'{"x":NaN}',b'\xff',b'x'*4097):
            with self.assertRaises(c.ContractStop): c.parse_binding(bad,1)
        with self.assertRaises(c.ContractStop): c.parse_binding(good,1,b"synthetic stderr")
        with self.assertRaises(c.ContractStop): c.parse_binding(good,True)
    def test_bound_digests_counts_and_sizes(self):
        for key in ("admission_sha256","compressed_sha256","decompressed_sha256","normalized_sha256"):
            self.reject({**self.bound(),key:"A"*64},0)
        for key in ("compressed_bytes","decompressed_bytes","normalized_bytes","create_count","insert_target_count"):
            for value in (True,-1,"1",0): self.reject({**self.bound(),key:value},0)
        self.reject({**self.bound(),"normalized_bytes":c.MAX_NORMALIZED+1},0)
    def test_guest_exact_schema(self):
        c.parse_guest_admission(self.raw(c.GUEST),0)
        for key,value in c.GUEST.items():
            obj=dict(c.GUEST); del obj[key]
            with self.assertRaises(c.ContractStop): c.parse_guest_admission(self.raw(obj),0)
        with self.assertRaises(c.ContractStop): c.parse_guest_admission(self.raw({**c.GUEST,"binding_executed":0}),0)
    def test_command_pins_and_wrapper_limit_match_public_sources(self):
        root=pathlib.Path(__file__).resolve().parent
        self.assertEqual(c.binding_argv(),["python3","-B","/root/private-native-admission-public-r4/native_admission_binding_r4.py","--bind-native-admission-r4","--builder-sha256",hashlib.sha256((root/"native_admission_binding_r4.py").read_bytes()).hexdigest(),"--prefix-sha256",hashlib.sha256((root/"native_prefix_structure_r4.py").read_bytes()).hexdigest()])
        tree=ast.parse((root/"native_source_preparation_r2.py").read_bytes())
        node=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="MAX_DECOMPRESSED" for t in n.targets))
        self.assertEqual(c.MAX_NORMALIZED,eval(compile(ast.Expression(node),"<public constant>","eval"),{"__builtins__":{}}))

    def test_actual_runner_main_output_matches_contract_without_binding(self):
        runner=importlib.import_module("native_admission_binding_r4")
        stopped=runner.BindingStop("PREFIX_BINDING")
        stopped.stage="NATIVE_PREFLIGHT"; stopped.reason="G056"
        stopped.structure_context="INSERT_VALUE"; stopped.token_kind="WORD"
        for outcome,expected_code in ((stopped,1),(self.bound(),0)):
            out,err=io.StringIO(),io.StringIO()
            def fake_bind(*args,**kwargs):
                if isinstance(outcome,BaseException): raise outcome
                return dict(outcome)
            with mock.patch.object(runner,"bind",side_effect=fake_bind),contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
                code=runner.main(c.binding_argv()[3:])
            self.assertEqual(code,expected_code)
            result=c.parse_binding(out.getvalue().encode("ascii"),code,err.getvalue().encode("ascii"))
            self.assertEqual(result["state"],"STOPPED" if code else "ADMISSION_BOUND")

if __name__=="__main__": unittest.main()
