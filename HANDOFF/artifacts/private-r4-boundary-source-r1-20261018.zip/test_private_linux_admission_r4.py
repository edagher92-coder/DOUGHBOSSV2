import ast
import hashlib
import json
import tarfile
import unittest
from pathlib import Path


ROOT = Path(__file__).parent
R3 = ROOT / "private_linux_admission_r3.py"
R4 = ROOT / "private_linux_admission_r4.py"
PUBLIC_TAR = ROOT / "native-admission-public-r4.tar"
PUBLIC_MANIFEST = "NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json"
PUBLIC_TAR_SHA256 = "794ae82f5bcc44f2d058d51f096c7a286fde84ba44191e0dad6c29f0e7d0cbfd"
PUBLIC_MANIFEST_SHA256 = "e9583a98a68c9ea021f8e0a4aa991301188eb2de2837f782de25894c809b51fa"


class PrivateLinuxAdmissionR4Tests(unittest.TestCase):
    def test_ast_is_r3_with_declared_r4_substitutions(self):
        r3 = R3.read_text(encoding="utf-8")
        r4 = R4.read_text(encoding="utf-8")
        replacements = (
            ("291328", "358400"),
            ("5c964fbae749c4ed909bbe1336d6af6ccc91fc6909f17fc4b075993e06f44a6a", "794ae82f5bcc44f2d058d51f096c7a286fde84ba44191e0dad6c29f0e7d0cbfd"),
            ("0950dd5840e3df6745c9fa89ecb0d0db7295f2b4c5b5f3c89a5386b515d7179e", "e9583a98a68c9ea021f8e0a4aa991301188eb2de2837f782de25894c809b51fa"),
            ("NATIVE-ADMISSION-PUBLIC-SOURCE-r3.json", PUBLIC_MANIFEST),
            ("/root/private-native-admission-public-r3", "/root/private-native-admission-public-r4"),
            ("'569'", "'700'"),
            ("len(ms)==19", "len(ms)==25"),
            ("len({m.name for m in ms})==19", "len({m.name for m in ms})==25"),
            ("len(es)==18", "len(es)==24"),
            ("len({e['Path'] for e in es})==18", "len({e['Path'] for e in es})==24"),
            ("/restore-native-admission-r3", "/restore-native-admission-r4"),
            ("NATIVE_ADMISSION_PRIVATE_GUEST_R3", "NATIVE_ADMISSION_PRIVATE_GUEST_R4"),
            ("'regular_public_files':19", "'regular_public_files':25"),
            ("'public_source_files':18", "'public_source_files':24"),
        )
        expected = r3
        for old, new in replacements:
            expected = expected.replace(old, new)
        self.assertEqual(ast.dump(ast.parse(expected), include_attributes=False), ast.dump(ast.parse(r4), include_attributes=False))
        self.assertNotIn("os.path.lexists('/dev/vdc')", r4)

    def test_public_r4_tar_manifest_and_pins(self):
        self.assertEqual(hashlib.sha256(PUBLIC_TAR.read_bytes()).hexdigest(), PUBLIC_TAR_SHA256)
        with tarfile.open(PUBLIC_TAR, "r:") as archive:
            members = archive.getmembers()
            self.assertEqual(len(members), 25)
            self.assertEqual(len({member.name for member in members}), 25)
            data = {member.name: archive.extractfile(member).read() for member in members}
        self.assertEqual(set(data), {member.name for member in members})
        manifest = data[PUBLIC_MANIFEST]
        self.assertEqual(hashlib.sha256(manifest).hexdigest(), PUBLIC_MANIFEST_SHA256)
        document = json.loads(manifest)
        self.assertEqual(document["format"], 1)
        self.assertEqual(document["scope"], "PUBLIC_SYNTHETIC_ONLY_NO_PRIVATE_INPUT")
        entries = document["sourceFiles"]
        self.assertEqual(len(entries), 24)
        self.assertEqual(len({entry["Path"] for entry in entries}), 24)
        self.assertEqual(set(data), {entry["Path"] for entry in entries} | {PUBLIC_MANIFEST})
        for entry in entries:
            payload = data[entry["Path"]]
            self.assertEqual(len(payload), entry["Bytes"])
            self.assertEqual(hashlib.sha256(payload).hexdigest().upper(), entry["Sha256"])

    def test_receipt_schema_and_freshness_paths(self):
        source = R4.read_text(encoding="utf-8")
        tree = ast.parse(source)
        receipt = next(node for node in ast.walk(tree) if isinstance(node, ast.Dict) and any(isinstance(key, ast.Constant) and key.value == "format" for key in node.keys))
        keys = {key.value for key in receipt.keys if isinstance(key, ast.Constant)}
        self.assertTrue({"format", "state", "regular_public_files", "public_source_files", "capsule_hash_readonly_match", "binding_executed"} <= keys)
        self.assertIn("/restore-native-admission-r4", source)
        self.assertIn("/restore-native-preparation-r1", source)
        self.assertNotIn("/restore-native-admission-r3", source)


if __name__ == "__main__":
    unittest.main()
