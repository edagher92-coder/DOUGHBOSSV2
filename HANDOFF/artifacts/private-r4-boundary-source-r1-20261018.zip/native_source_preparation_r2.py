"""Pinned, offline native gzip preparation only; never import or boot anything."""
import argparse
import builtins
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import types
import zlib

BASE_SHA = "fe9ce3984a3302ef8c1cb523019b3901f4624ed1b8f52352acd6b89f073f6651"
NATIVE_SHA = "4053607725850025b4cb8e923fd365b9015243b2576aa7f64838865528e37da4"
ROOT = Path("/restore-native-preparation-r1")
MAX_COMPRESSED = 128 * 1024**2
MAX_DECOMPRESSED = 128 * 1024**2
PROFILE = "native-utf8mb4-zero-id-utc-r1"
CONTROLS = {"names": "utf8mb4", "sql_mode": "NO_AUTO_VALUE_ON_ZERO", "time_zone": "+00:00"}
DIGEST = re.compile(r"[a-fA-F0-9]{64}\Z")
IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,63}\Z")
FALSE_FLAGS = ("native_origin_proved", "producer_snapshot_fidelity_proved",
    "file_database_consistency_proved", "actual_engine_semantics_proved",
    "provider_file_account_statements_executed", "import_executed",
    "restore_acceptance", "release_acceptance")
METADATA_KEYS = {"normalization_profile", "statements", "accepted", "ignored", "tables",
    "client_sandbox_marker_removed", "table_charset_pairs", "source_controls", *FALSE_FLAGS}
ADMISSION_KEYS = {"format", "phase", "preparation_allowed", "wrapper_sha256", "base_sha256",
    "native_sha256", "source_path", "prefix", "compressed_sha256", "compressed_bytes",
    "decompressed_sha256", "decompressed_bytes", "max_compressed_bytes",
    "max_decompressed_bytes", "create_count", "insert_target_count"}
CATEGORIES = frozenset({"ADMISSION", "ENVIRONMENT", "PRIVACY", "FRESHNESS", "SOURCE",
    "GZIP", "ENCODING", "NORMALIZATION", "RECEIPT", "OUTPUT", "INTERNAL"})


class Stop(Exception):
    def __init__(self, category):
        self.category = category if category in CATEGORIES else "INTERNAL"
        super().__init__(self.category)


def require(condition, category):
    if not condition:
        raise Stop(category)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode()


def valid_digest(value):
    return type(value) is str and DIGEST.fullmatch(value) is not None


def validate_admission(value, wrapper_sha, *, production=True):
    require(type(value) is dict and set(value) == ADMISSION_KEYS, "ADMISSION")
    require(type(value["format"]) is int and value["format"] == 1
        and value["phase"] == "NATIVE_SOURCE_PREPARATION_R1"
        and value["preparation_allowed"] is True, "ADMISSION")
    require(valid_digest(wrapper_sha), "ADMISSION")
    for key in ("wrapper_sha256", "base_sha256", "native_sha256",
                "compressed_sha256", "decompressed_sha256"):
        require(valid_digest(value[key]), "ADMISSION")
    require(value["wrapper_sha256"].lower() == wrapper_sha.lower()
        and value["base_sha256"].lower() == BASE_SHA
        and value["native_sha256"].lower() == NATIVE_SHA, "ADMISSION")
    for key, ceiling in (("max_compressed_bytes", MAX_COMPRESSED),
                         ("max_decompressed_bytes", MAX_DECOMPRESSED)):
        require(type(value[key]) is int and 0 < value[key] <= ceiling, "ADMISSION")
    for key, maximum in (("compressed_bytes", "max_compressed_bytes"),
                         ("decompressed_bytes", "max_decompressed_bytes")):
        require(type(value[key]) is int and 0 < value[key] <= value[maximum], "ADMISSION")
    require(type(value["prefix"]) is str and IDENT.fullmatch(value["prefix"])
        and value["prefix"].endswith("_"), "ADMISSION")
    require(type(value["source_path"]) is str and value["source_path"].startswith("/")
        and "\\" not in value["source_path"] and "\0" not in value["source_path"], "ADMISSION")
    source = Path(value["source_path"])
    require(".." not in source.parts and source.name not in {"", ".", ".."}
        and source != ROOT and ROOT not in source.parents, "ADMISSION")
    require(type(value["create_count"]) is int and value["create_count"] > 0
        and type(value["insert_target_count"]) is int
        and 0 <= value["insert_target_count"] <= value["create_count"], "ADMISSION")
    if production:
        require(value["create_count"] == 58 and value["insert_target_count"] == 30, "ADMISSION")
    return value.copy()


def safe_environment():
    require(os.name == "posix" and os.geteuid() == 0 and os.uname().sysname == "Linux", "ENVIRONMENT")
    require({p.name for p in Path("/sys/class/net").iterdir()} == {"lo"}, "ENVIRONMENT")
    allowed = {"rootfs", "tmpfs", "proc", "sysfs", "devtmpfs", "devpts", "overlay", "ext4",
        "ext3", "ext2", "squashfs", "iso9660", "cgroup", "cgroup2", "mqueue"}
    exact = {"securityfs": "/sys/kernel/security", "debugfs": "/sys/kernel/debug",
        "tracefs": "/sys/kernel/tracing", "pstore": "/sys/fs/pstore", "bpf": "/sys/fs/bpf"}
    for line in Path("/proc/mounts").read_text().splitlines():
        fields = line.split()
        require(len(fields) >= 3 and (fields[1] == exact[fields[2]]
            if fields[2] in exact else fields[2] in allowed), "ENVIRONMENT")
    for name in ("tcp", "tcp6"):
        for line in Path("/proc/net", name).read_text().splitlines()[1:]:
            fields = line.split()
            require(len(fields) >= 4 and fields[3] != "0A", "ENVIRONMENT")
    for entry in Path("/proc").iterdir():
        if entry.name.isdecimal():
            try:
                name = (entry / "comm").read_text().strip()
            except FileNotFoundError:
                continue
            require(name not in {"mariadbd", "mysqld", "mariadb-install"}, "ENVIRONMENT")


def check_directory(info):
    require(stat.S_ISDIR(info.st_mode) and info.st_uid == 0
        and not stat.S_IMODE(info.st_mode) & 0o022, "PRIVACY")


@contextlib.contextmanager
def trusted_directory(path):
    path = Path(path)
    require(path.is_absolute() and ".." not in path.parts, "PRIVACY")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open("/", flags)
    try:
        check_directory(os.fstat(fd))
        for component in path.parts[1:]:
            child = os.open(component, flags, dir_fd=fd)
            os.close(fd)
            fd = child
            check_directory(os.fstat(fd))
        yield fd
    finally:
        os.close(fd)


def identity(info):
    return (info.st_dev, info.st_ino, info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode),
        info.st_size, info.st_mtime_ns, info.st_ctime_ns)


class Pinned:
    def __init__(self, path, sha, limit, size=None):
        require(valid_digest(sha) and type(limit) is int and limit > 0, "ADMISSION")
        self.path, self.sha, self.limit, self.size = Path(path), sha.lower(), limit, size

    def __enter__(self):
        with trusted_directory(self.path.parent) as parent:
            fd = os.open(self.path.name, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC,
                dir_fd=parent)
        self.stream = os.fdopen(fd, "rb")
        try:
            info = os.fstat(fd)
            require(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0
                and stat.S_IMODE(info.st_mode) == 0o600, "PRIVACY")
            require(0 < info.st_size <= self.limit
                and (self.size is None or info.st_size == self.size), "SOURCE")
            self.info = identity(info)
            self.snapshot = self.stream.read(self.limit + 1)
            require(len(self.snapshot) == info.st_size and digest(self.snapshot) == self.sha, "SOURCE")
            self.check()
            return self
        except BaseException:
            self.stream.close()
            raise

    def check(self):
        require(identity(os.fstat(self.stream.fileno())) == self.info, "SOURCE")
        self.stream.seek(0)
        require(digest(self.stream.read(self.limit + 1)) == self.sha, "SOURCE")
        self.stream.seek(0)

    def __exit__(self, *unused):
        self.stream.close()


def load_dependencies(base_snapshot, native_snapshot):
    """The native import sees only admitted base; sys.modules is never changed."""
    require(type(base_snapshot) is bytes and digest(base_snapshot) == BASE_SHA
        and type(native_snapshot) is bytes and digest(native_snapshot) == NATIVE_SHA, "ADMISSION")
    base = types.ModuleType("admitted_native_preparation_base")
    native = types.ModuleType("admitted_native_preparation_normalizer")
    exec(compile(base_snapshot, "<admitted-base>", "exec"), base.__dict__)
    original_import = builtins.__import__

    def admitted_import(name, globals=None, locals=None, fromlist=(), level=0):
        require(name == "restore_preparer_r3" and level == 0 and not fromlist, "ADMISSION")
        return base

    local_builtins = vars(builtins).copy()
    local_builtins["__import__"] = admitted_import
    native.__dict__["__builtins__"] = local_builtins
    exec(compile(native_snapshot, "<admitted-native>", "exec"), native.__dict__)
    require(builtins.__import__ is original_import and native._base is base, "ADMISSION")
    return base, native


def decompress_exact(compressed, admission):
    require(type(compressed) is bytes and len(compressed) == admission["compressed_bytes"]
        and len(compressed) <= admission["max_compressed_bytes"]
        and digest(compressed) == admission["compressed_sha256"].lower(), "SOURCE")
    limit = admission["max_decompressed_bytes"]
    try:
        inflater = zlib.decompressobj(16 + zlib.MAX_WBITS)
        output = inflater.decompress(compressed, limit + 1)
        require(len(output) <= limit and inflater.eof
            and not inflater.unused_data and not inflater.unconsumed_tail, "GZIP")
    except zlib.error:
        raise Stop("GZIP") from None
    require(len(output) == admission["decompressed_bytes"]
        and digest(output) == admission["decompressed_sha256"].lower(), "SOURCE")
    return output


def validate_metadata(metadata, admission):
    require(type(metadata) is dict and set(metadata) == METADATA_KEYS, "RECEIPT")
    require(metadata["normalization_profile"] == PROFILE
        and type(metadata["source_controls"]) is dict and metadata["source_controls"] == CONTROLS,
        "RECEIPT")
    require(all(metadata[key] is False for key in FALSE_FLAGS), "RECEIPT")
    for key in ("statements", "accepted", "table_charset_pairs"):
        require(type(metadata[key]) is int and metadata[key] >= 0, "RECEIPT")
    require(type(metadata["client_sandbox_marker_removed"]) is bool
        and type(metadata["ignored"]) is list, "RECEIPT")
    for ignored in metadata["ignored"]:
        require(type(ignored) is dict and set(ignored) == {"statement", "class"}
            and type(ignored["statement"]) is int and 0 < ignored["statement"] <= metadata["statements"]
            and ignored["class"] in {"SET", "DROP", "LOCK", "UNLOCK", "ALTER", "COMMIT"}, "RECEIPT")
    require(metadata["accepted"] + len(metadata["ignored"]) == metadata["statements"], "RECEIPT")
    tables = metadata["tables"]
    require(type(tables) is list and all(type(t) is str and IDENT.fullmatch(t)
        and t.startswith(admission["prefix"]) for t in tables), "RECEIPT")
    require(tables == sorted(set(tables)) and len(tables) == admission["create_count"], "RECEIPT")


def prepare_snapshot(compressed, admission, wrapper_sha, base, native, *, synthetic=False):
    """Pure snapshot seam; only tests may select explicit synthetic counts."""
    admission = validate_admission(admission, wrapper_sha, production=not synthetic)
    original = decompress_exact(compressed, admission)
    try:
        text = original.decode("utf-8", errors="strict")
    except UnicodeError:
        raise Stop("ENCODING") from None
    try:
        output, metadata = native.preflight_native_sql(text, admission["prefix"])
        validate_metadata(metadata, admission)
        require(type(output) is str, "RECEIPT")
        creates, insert_targets, accepted = set(), set(), 0
        # Count only already validated normalized statements, never regex over SQL values.
        for group in native._groups(base.lex_sql(output)):
            cursor = base.Cursor(group)
            if cursor.peek() == "CREATE":
                creates.add(base.validate_create(cursor, admission["prefix"]))
                accepted += 1
            elif cursor.peek() == "INSERT":
                insert_targets.add(base.validate_insert(cursor, admission["prefix"]))
                accepted += 1
        require(sorted(creates) == metadata["tables"]
            and len(insert_targets) == admission["insert_target_count"]
            and insert_targets <= creates and accepted == metadata["accepted"], "RECEIPT")
    except Stop:
        raise
    except Exception:
        raise Stop("NORMALIZATION") from None
    normalized = output.encode("utf-8")
    require(len(normalized) <= MAX_DECOMPRESSED, "OUTPUT")
    receipt = {"format": 1, "phase": "NATIVE_SOURCE_PREPARATION_R1",
        "snapshot_validation_verified": True, "receipt_scope": "SNAPSHOT_VALIDATION_ONLY",
        "wrapper_sha256": wrapper_sha.lower(), "base_sha256": BASE_SHA, "native_sha256": NATIVE_SHA,
        "compressed_sha256": digest(compressed), "compressed_bytes": len(compressed),
        "decompressed_sha256": digest(original), "decompressed_bytes": len(original),
        "import_sha256": digest(normalized), "import_bytes": len(normalized),
        "create_count": len(creates), "insert_target_count": len(insert_targets),
        "normalization": metadata, "application_boot_allowed": False,
        "database_started": False, "schema_fidelity_proved": False,
        "row_count_fidelity_proved": False, "value_fidelity_proved": False,
        **{key: False for key in FALSE_FLAGS}}
    return original, normalized, receipt


def write_new_file(directory_fd, name, data):
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open(name, flags, 0o600, dir_fd=directory_fd)
    with os.fdopen(fd, "w+b") as stream:
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0, "PRIVACY")
        os.fchmod(fd, 0o600)
        stream.write(data)
        stream.flush()
        os.fsync(fd)
        stream.seek(0)
        require(stream.read(len(data) + 1) == data, "OUTPUT")
        os.fchmod(fd, 0o400)
        require(stat.S_IMODE(os.fstat(fd).st_mode) == 0o400, "OUTPUT")
        os.fsync(fd)


def write_preparation(compressed, original, normalized, receipt):
    # No caller-selected output destination and no cleanup of a partial attempt.
    with trusted_directory(ROOT.parent) as parent:
        require(not os.path.lexists(ROOT), "FRESHNESS")
        os.mkdir(ROOT.name, mode=0o700, dir_fd=parent)
        fd = os.open(ROOT.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
            dir_fd=parent)
        try:
            check_directory(os.fstat(fd))
            require(os.fstat(fd).st_gid == 0, "PRIVACY")
            os.fchmod(fd, 0o700)
            for name, data in (("compressed-original.sql.gz", compressed),
                ("baseline-original.sql", original), ("approved-import.sql", normalized),
                ("NATIVE-SQL-PREFLIGHT.json", canonical(receipt))):
                write_new_file(fd, name, data)
            os.fchmod(fd, 0o500)
            os.fsync(fd)
        finally:
            os.close(fd)
        os.fsync(parent)


def decode_admission(data):
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "ADMISSION")
            result[key] = value
        return result
    try:
        return json.loads(data, object_pairs_hook=unique_pairs)
    except (ValueError, UnicodeError):
        raise Stop("ADMISSION") from None


def execute(admission_path, admission_sha, wrapper_sha, *, preparation_gate=False):
    require(preparation_gate is True, "ADMISSION")
    safe_environment()
    require(not os.path.lexists(ROOT), "FRESHNESS")
    public = Path(__file__).absolute().parent
    with contextlib.ExitStack() as stack:
        wrapper = stack.enter_context(Pinned(Path(__file__).absolute(), wrapper_sha, 2 * 1024**2))
        base_pin = stack.enter_context(Pinned(public / "restore_preparer_r3_indexed_r1.py", BASE_SHA, 2 * 1024**2))
        native_pin = stack.enter_context(Pinned(public / "restore_preparer_native_r1.py", NATIVE_SHA, 2 * 1024**2))
        base, native = load_dependencies(base_pin.snapshot, native_pin.snapshot)
        admission_pin = stack.enter_context(Pinned(admission_path, admission_sha, 65536))
        admission = validate_admission(decode_admission(admission_pin.snapshot), wrapper_sha)
        source = stack.enter_context(Pinned(admission["source_path"], admission["compressed_sha256"],
            admission["max_compressed_bytes"], admission["compressed_bytes"]))
        original, normalized, receipt = prepare_snapshot(source.snapshot, admission, wrapper_sha, base, native)
        receipt["admission_sha256"] = admission_pin.sha
        for pin in (wrapper, base_pin, native_pin, admission_pin, source):
            pin.check()
        safe_environment()
        write_preparation(source.snapshot, original, normalized, receipt)
        for pin in (wrapper, base_pin, native_pin, admission_pin, source):
            pin.check()
        # Completion binding is ephemeral: never put a self-digest in the persisted receipt.
        completed = receipt.copy()
        completed["preflight_sha256"] = digest(canonical(receipt))
        return completed


def exposed(receipt=None, category="NONE"):
    receipt = receipt if type(receipt) is dict else {}
    completed = category == "NONE" and valid_digest(receipt.get("preflight_sha256"))
    result = {"format": 1, "state": "PREPARED" if completed else "STOPPED",
        "category": "INTERNAL" if category == "NONE" and not completed else
            (category if category in CATEGORIES | {"NONE"} else "INTERNAL"),
        "application_boot_allowed": False, "database_started": False,
        "schema_fidelity_proved": False, "row_count_fidelity_proved": False,
        "value_fidelity_proved": False, **{key: False for key in FALSE_FLAGS}}
    for key in ("compressed_bytes", "decompressed_bytes", "import_bytes", "create_count", "insert_target_count"):
        value = receipt.get(key, 0)
        result[key] = value if type(value) is int and value >= 0 else 0
    for key in ("wrapper_sha256", "base_sha256", "native_sha256", "admission_sha256",
                "compressed_sha256", "decompressed_sha256", "import_sha256"):
        if valid_digest(receipt.get(key)):
            result[key] = receipt[key].lower()
    if completed:
        result["preflight_sha256"] = receipt["preflight_sha256"].lower()
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, add_help=False)
    parser.add_argument("--prepare-native-r1", action="store_true")
    parser.add_argument("--admission", required=True)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--wrapper-sha256", required=True)
    # Even parsing failures must not echo a private filename/argument.
    try:
        with contextlib.redirect_stderr(types.SimpleNamespace(write=lambda unused: None, flush=lambda: None)):
            args = parser.parse_args(argv)
        receipt = execute(args.admission, args.admission_sha256, args.wrapper_sha256,
            preparation_gate=args.prepare_native_r1)
        result = exposed(receipt)
        code = 0 if result["state"] == "PREPARED" else 1
    except Stop as exc:
        result, code = exposed(category=exc.category), 1
    except BaseException:
        result, code = exposed(category="INTERNAL"), 1
    print(json.dumps(result, sort_keys=True))
    return code


if __name__ == "__main__":
    sys.exit(main())
