"""Observe closed G056 structure while reusing accepted R3 validation unchanged.

Public/synthetic candidate. No private-operation admission is granted here.
Original dependency modules/functions are never patched. A short-lived facade
only forwards the same preflight success or failure to the accepted R3 caller.
"""

from types import FunctionType, ModuleType

import native_prefix_reasons_r3 as reasons
import native_g056_structure_r1 as structure

__all__ = ["PrefixBindingError", "derive_native_prefix"]

_UNKNOWN = ("UNCLASSIFIED", "UNCLASSIFIED")
_CONTEXTS = frozenset({"INSERT_VALUE", "CREATE_DEFAULT"})
_KINDS = frozenset({"WORD", "IDENT", "SYMBOL"})


class PrefixBindingError(reasons.PrefixBindingError):
    def __init__(self, stage="INTERFACE", reason="UNCLASSIFIED", observed=_UNKNOWN):
        stage = stage if type(stage) is str and stage in reasons.STAGES else "INTERFACE"
        reason = reason if type(reason) is str and reason in reasons.REASONS else "UNCLASSIFIED"
        super().__init__(stage, reason)
        self.structure_context, self.token_kind = _UNKNOWN
        if (self.stage == "NATIVE_PREFLIGHT" and self.reason == "G056"
                and type(observed) is tuple and len(observed) == 2
                and type(observed[0]) is str and type(observed[1]) is str
                and observed[0] in _CONTEXTS and observed[1] in _KINDS):
            self.structure_context, self.token_kind = observed


def derive_native_prefix(text, base, native):
    """Preserve the exact accepted R3 algorithm and its success tuple."""
    observed = _UNKNOWN
    forwarded = native
    try:
        namespace = structure._module_namespace(native)
        if structure._field(namespace, "_base", 4096) is base:
            original = structure._field(namespace, "preflight_native_sql", 4096)
            if type(original) is FunctionType:
                def observe(text, prefix):
                    nonlocal observed
                    try:
                        return original(text, prefix)
                    except Exception as error:
                        observed = structure.classify_g056(error, base, native)
                        raise

                forwarded = ModuleType("closed_native_observer")
                forwarded.__dict__.update(namespace)
                forwarded.preflight_native_sql = observe
    except Exception:
        # Invalid interfaces retain the accepted R3 fail-closed path.
        forwarded = native
    stage, reason = "INTERFACE", "UNCLASSIFIED"
    try:
        return reasons.derive_native_prefix(text, base, forwarded)
    except reasons.PrefixBindingError as error:
        stage, reason = error.stage, error.reason
    # Do not retain the caught source/validator exception as context or cause.
    raise PrefixBindingError(stage, reason, observed) from None
