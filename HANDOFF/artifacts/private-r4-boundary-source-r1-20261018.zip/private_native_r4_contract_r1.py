"""Closed private-R4 receipt/command contract. No execution or private reads."""
import json
import re

GUEST_ROOT="/root/private-native-admission-public-r4"
BUILDER_SHA="64ebe950d0695165911c47b1def0306570b3f42998ffbf7dfad9d7d3df679cb5"
PREFIX_SHA="f93a59c62c75c92470f4a7873def61561df896750b8ce01348744d2065f775b1"
COMPRESSED_SHA="cbb3efe50fc888856d67c8718a640cc405d4447a482efed16dde94b287ae83a7"
DECOMPRESSED_SHA="5610af62175bb9eab0d5f3c24813aa29e1641f12f89d9b3110a1c1fc574d7b19"
MAX_NORMALIZED=128*1024**2  # Existing native_source_preparation_r2.MAX_DECOMPRESSED.
CATEGORIES=frozenset({"ADMISSION","ENVIRONMENT","SOURCE","GZIP","PREFIX_BINDING","PRIVACY","FRESHNESS","OUTPUT","INTERNAL"})
STAGES=frozenset({"INTERFACE","SOURCE_MARKER_OR_GUARD","CREATE_INVENTORY","PREFIX_CANDIDATE","CROSS_PREFIX","NATIVE_PREFLIGHT","METADATA_MISMATCH"})
REASONS=frozenset({"UNCLASSIFIED",*(f"G{i:03d}" for i in range(1,73))})
FLAGS=frozenset({"preparation_executed","database_started","application_boot_allowed","restore_acceptance","release_acceptance"})
COMMON=FLAGS|{"format","state"}
GUEST={"format":"NATIVE_ADMISSION_PRIVATE_GUEST_R4","state":"PUBLIC_AND_READONLY_CAPSULE_ADMITTED","regular_public_files":25,"public_source_files":24,"capsule_hash_readonly_match":True,"binding_executed":False}

class ContractStop(ValueError): pass

def _need(condition):
    if condition is not True: raise ContractStop("NOT_ADMITTED")

def _pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise ValueError()
        result[key]=value
    return result

def _constant(unused): raise ValueError()

def _object(raw):
    _need(type(raw) is bytes and 0<len(raw)<=4096)
    result=None
    try: result=json.loads(raw.decode("ascii"),object_pairs_hook=_pairs,parse_constant=_constant)
    except (ValueError,UnicodeError,RecursionError): pass
    _need(type(result) is dict)
    return result

def binding_argv():
    return ["python3","-B",GUEST_ROOT+"/native_admission_binding_r4.py","--bind-native-admission-r4","--builder-sha256",BUILDER_SHA,"--prefix-sha256",PREFIX_SHA]

def parse_guest_admission(raw,exit_code,stderr=b""):
    _need(type(exit_code) is int and exit_code==0 and type(stderr) is bytes and not stderr)
    result=_object(raw)
    _need(set(result)==set(GUEST) and all(type(result[k]) is type(v) and result[k]==v for k,v in GUEST.items()))
    return result

def parse_binding(raw,exit_code,stderr=b""):
    _need(type(exit_code) is int and exit_code in (0,1) and type(stderr) is bytes and not stderr)
    result=_object(raw)
    _need(result.get("format")=="NATIVE_ADMISSION_BINDING_R4" and all(result.get(k) is False for k in FLAGS))
    if result.get("state")=="STOPPED":
        _need(exit_code==1 and type(result.get("category")) is str and result["category"] in CATEGORIES)
        expected=COMMON|{"category"}
        if result["category"]=="PREFIX_BINDING" and "stage" in result:
            _need(type(result["stage"]) is str and result["stage"] in STAGES); expected|={"stage"}
            if result["stage"]=="NATIVE_PREFLIGHT":
                _need(type(result.get("reason")) is str and result["reason"] in REASONS); expected|={"reason"}
                if result["reason"]=="G056":
                    context,kind=result.get("structure_context"),result.get("token_kind")
                    _need(type(context) is str and type(kind) is str and ((context in {"INSERT_VALUE","CREATE_DEFAULT"} and kind in {"WORD","IDENT","SYMBOL"}) or (context,kind)==("UNCLASSIFIED","UNCLASSIFIED")))
                    expected|={"structure_context","token_kind"}
        _need(set(result)==expected)
        return result
    _need(result.get("state")=="ADMISSION_BOUND" and exit_code==0)
    digests={"admission_sha256","compressed_sha256","decompressed_sha256","normalized_sha256"}
    expected=COMMON|digests|{"compressed_bytes","decompressed_bytes","normalized_bytes","create_count","insert_target_count"}
    _need(set(result)==expected)
    _need(all(type(result[k]) is str and re.fullmatch(r"[0-9a-f]{64}",result[k]) is not None for k in digests))
    for key,value in {"compressed_bytes":445129,"decompressed_bytes":1974648,"create_count":58,"insert_target_count":30}.items():
        _need(type(result[key]) is int and result[key]==value)
    _need(result["compressed_sha256"]==COMPRESSED_SHA and result["decompressed_sha256"]==DECOMPRESSED_SHA)
    _need(type(result["normalized_bytes"]) is int and 0<result["normalized_bytes"]<=MAX_NORMALIZED)
    return result

if __name__=="__main__": raise SystemExit("NOT_ADMITTED: contract only")
