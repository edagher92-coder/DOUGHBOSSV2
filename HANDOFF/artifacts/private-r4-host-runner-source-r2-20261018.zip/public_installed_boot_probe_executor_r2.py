"""Hash-bound public installed-kernel probe executor.

Import and CLI entry never launch. ``execute`` is the sole operation seam and
still requires a separately reviewed exact Admission. This public-only probe
does not read a private backup, run WordPress, or establish release acceptance.
"""

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import threading
import time

import public_installed_boot_probe_r1 as probe
import public_installed_boot_image_guard_r1 as guard

MIB = 1024 * 1024
EXECUTOR = "public_installed_boot_probe_executor_r2.py"
PROFILE_MODULE = "public_installed_boot_probe_r1.py"
GUARD_MODULE = "public_installed_boot_image_guard_r1.py"
PROFILE = {
    "mode": probe.MODE,
    "public_only": True,
    "restore_acceptance": False,
    "private_backup_attached": False,
    "seconds": 600,
    "image_seconds": 120,
    "log_bytes": 4 * MIB,
    "image_output_bytes": 4 * MIB,
    "write_bytes": 4,
    "write_interval": 0.2,
    "cleanup_seconds": 3,
    "support_closure": "ROOT_REVIEWED_PUBLIC_TOOL_CLOSURE",
}


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


PROFILE_SHA256 = _sha256(json.dumps(PROFILE, sort_keys=True).encode("ascii"))
REQUIRED = (
    EXECUTOR,
    PROFILE_MODULE,
    GUARD_MODULE,
    probe.BASE,
    probe.KERNEL,
    probe.INITRAMFS,
    probe.TOOL,
    probe.IMAGE_TOOL,
    probe.R8_RECEIPT,
)
APPROVAL = "ROOT_APPROVED_PUBLIC_INSTALLED_BOOT_PROBE_ONLY"
TERMINAL_HANDSHAKE = b"exec /bin/sh -c 'while IFS= read -r l; do eval \"$l\"; done'\n"
READY_MARKER = b"PUBLIC_BOOT_R1_READY"
READY_COMMAND = b"printf 'PUBLIC_BOOT_R1_READY\\n'\n"


@dataclass(frozen=True)
class Pin:
    name: str
    size: int
    sha256: str
    mtime_ns: int | None = None


@dataclass(frozen=True)
class Admission:
    """Explicit root authority; never reconstructed from disk or guest data."""

    root: str
    executor_sha256: str
    profile_module_sha256: str
    guard_module_sha256: str
    profile_sha256: str
    pins: tuple[Pin, ...]
    approval: str
    public_tool_closure_reviewed: bool


def _is_reparse(info):
    return bool(getattr(info, "st_file_attributes", 0) & 0x400)


def _identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)


def _safe_path(root, name, *, exists=True):
    if type(name) is not str or not name or "\\" in name or "\0" in name or ":" in name:
        raise probe.Stop("PATH")
    parts = PurePosixPath(name).parts
    if not parts or any(part in ("", ".", "..") for part in parts):
        raise probe.Stop("PATH")
    root = probe._root(root)
    path = root.joinpath(*parts)
    if path.parent != root and root not in path.parents:
        raise probe.Stop("PATH")
    if exists and not os.path.lexists(path):
        raise probe.Stop("PATH")
    return path


def _plain_file_info(path):
    info = os.lstat(path)
    if _is_reparse(info) or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise probe.Stop("FILE_IDENTITY")
    return info


def _digest(path):
    before = _plain_file_info(path)
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        if _identity(os.fstat(source.fileno())) != _identity(before):
            raise probe.Stop("INPUT_IDENTITY")
        for block in iter(lambda: source.read(MIB), b""):
            digest.update(block)
        if _identity(os.fstat(source.fileno())) != _identity(before):
            raise probe.Stop("INPUT_IDENTITY")
    if _identity(_plain_file_info(path)) != _identity(before):
        raise probe.Stop("INPUT_IDENTITY")
    return _identity(before), digest.hexdigest()


def _admit(root, admission):
    root = probe._root(root)
    if (
        type(admission) is not Admission
        or admission.root != str(root)
        or admission.approval != APPROVAL
        or admission.profile_sha256 != PROFILE_SHA256
        or admission.public_tool_closure_reviewed is not True
        or type(admission.pins) is not tuple
    ):
        raise probe.Stop("NOT_ADMITTED")
    pins = {}
    for pin in admission.pins:
        if (
            type(pin) is not Pin
            or pin.name in pins
            or type(pin.size) is not int
            or pin.size < 0
            or type(pin.sha256) is not str
            or re.fullmatch(r"[0-9a-f]{64}", pin.sha256) is None
            or (
                pin.mtime_ns is not None
                and (type(pin.mtime_ns) is not int or pin.mtime_ns <= 0)
            )
        ):
            raise probe.Stop("ADMISSION_PIN_SCHEMA")
        _safe_path(root, pin.name)
        if pin.name not in REQUIRED and not pin.name.startswith("qemu-test-tools/"):
            raise probe.Stop("ADMISSION_PIN_SCOPE")
        pins[pin.name] = pin
    if not set(REQUIRED).issubset(pins):
        raise probe.Stop("ADMISSION_PINS_MISSING")
    if (
        pins[EXECUTOR].sha256 != admission.executor_sha256
        or pins[PROFILE_MODULE].sha256 != admission.profile_module_sha256
        or pins[GUARD_MODULE].sha256 != admission.guard_module_sha256
    ):
        raise probe.Stop("ADMISSION_CODE_BINDING")
    if (
        Path(__file__).absolute() != _safe_path(root, EXECUTOR)
        or Path(probe.__file__).absolute() != _safe_path(root, PROFILE_MODULE)
        or Path(guard.__file__).absolute() != _safe_path(root, GUARD_MODULE)
    ):
        raise probe.Stop("ADMISSION_MODULE_LOCATION")
    for name, (expected_size, expected_hash) in probe.INPUT_PINS.items():
        pin = pins.get(name)
        if pin is None or pin.sha256 != expected_hash:
            raise probe.Stop("PROFILE_INPUT_PIN:" + name)
        if expected_size is not None and pin.size != expected_size:
            raise probe.Stop("PROFILE_INPUT_PIN:" + name)
    if pins[probe.R8_RECEIPT].sha256 != probe.R8_RECEIPT_SHA:
        raise probe.Stop("R8_RECEIPT_PIN")
    for name in probe.OUTPUT_NAMES:
        if os.path.lexists(_safe_path(root, name, exists=False)):
            raise probe.Stop("STALE_OUTPUT")
    return root, pins


def _verify_inputs(root, pins, previous=None):
    snapshots = {}
    for name, pin in pins.items():
        identity, digest = _digest(_safe_path(root, name))
        if (
            identity[2] != pin.size
            or digest != pin.sha256
            or (pin.mtime_ns is not None and identity[3] != pin.mtime_ns)
        ):
            raise probe.Stop("INPUT_PIN:" + name)
        if previous is not None and previous.get(name) != identity:
            raise probe.Stop("INPUT_IDENTITY:" + name)
        snapshots[name] = identity
    return snapshots


def _exclusive(root, name):
    path = _safe_path(root, name, exists=False)
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0)
    descriptor = os.open(path, flags, 0o600)
    return os.fdopen(descriptor, "r+b", buffering=0)


def _artifact_identity(root, name, identity, size=None):
    path = _safe_path(root, name)
    info = _plain_file_info(path)
    if (info.st_dev, info.st_ino) != identity[:2]:
        raise probe.Stop("ARTIFACT_IDENTITY:" + name)
    if size is not None and info.st_size != size:
        raise probe.Stop("ARTIFACT_IDENTITY:" + name)
    return path


def _minimal_env():
    return {key: os.environ[key] for key in ("SystemRoot", "WINDIR") if key in os.environ}


def _owned_process(argv, timeout, output_limit):
    if (
        type(argv) is not list
        or not argv
        or any(type(part) is not str or not part or "\0" in part for part in argv)
        or type(timeout) not in (int, float)
        or timeout <= 0
        or type(output_limit) is not int
        or output_limit <= 0
    ):
        raise probe.Stop("IMAGE_TOOL_ARGV")
    child = subprocess.Popen(
        argv,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False,
        env=_minimal_env(),
        bufsize=0,
    )
    owner_pid, owner_args = child.pid, tuple(child.args)
    output = {"stdout": bytearray(), "stderr": bytearray()}
    output_bytes = {"total": 0}
    output_lock = threading.Lock()
    overflow = threading.Event()
    reader_errors = []

    def drain(name, stream):
        try:
            while not overflow.is_set():
                chunk = stream.read(64 * 1024)
                if chunk == b"":
                    return
                if type(chunk) is not bytes:
                    reader_errors.append(name)
                    overflow.set()
                    return
                with output_lock:
                    if output_bytes["total"] + len(chunk) > output_limit:
                        overflow.set()
                        return
                    output_bytes["total"] += len(chunk)
                    output[name].extend(chunk)
        except Exception:
            reader_errors.append(name)
            overflow.set()

    readers = [
        threading.Thread(target=drain, args=("stdout", child.stdout), daemon=True),
        threading.Thread(target=drain, args=("stderr", child.stderr), daemon=True),
    ]

    def stop_owned():
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=PROFILE["cleanup_seconds"])
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=PROFILE["cleanup_seconds"])

    stop_reason = ""
    try:
        for reader in readers:
            reader.start()
        deadline = time.monotonic() + timeout
        while child.poll() is None:
            if overflow.is_set():
                stop_reason = "IMAGE_TOOL_OUTPUT"
                break
            if time.monotonic() >= deadline:
                stop_reason = "IMAGE_TOOL_TIMEOUT"
                break
            time.sleep(0.01)
        if stop_reason:
            stop_owned()
        else:
            try:
                child.wait(timeout=PROFILE["cleanup_seconds"])
            except subprocess.TimeoutExpired:
                stop_reason = "IMAGE_TOOL_TIMEOUT"
                stop_owned()
        for reader in readers:
            reader.join(timeout=PROFILE["cleanup_seconds"])
        if any(reader.is_alive() for reader in readers):
            if not stop_reason:
                stop_reason = "IMAGE_TOOL_OUTPUT"
            stop_owned()
    finally:
        stop_owned()
        for stream in (child.stdout, child.stderr):
            try:
                stream.close()
            except Exception:
                reader_errors.append("close")
        for reader in readers:
            reader.join(timeout=PROFILE["cleanup_seconds"])
    if child.poll() is None:
        raise probe.Stop("IMAGE_TOOL_IDENTITY")
    if child.pid != owner_pid or tuple(child.args) != owner_args:
        raise probe.Stop("IMAGE_TOOL_IDENTITY")
    if stop_reason:
        raise probe.Stop(stop_reason)
    if overflow.is_set() or reader_errors:
        raise probe.Stop("IMAGE_TOOL_OUTPUT")
    if child.returncode != 0:
        raise probe.Stop("IMAGE_TOOL_EXIT")
    return bytes(output["stdout"])


def _create_script_disk(root):
    data = probe.render_script_disk()
    if type(data) is not bytes or len(data) != probe.SCRIPT_BYTES:
        raise probe.Stop("SCRIPT_BYTES")
    with _exclusive(root, probe.SCRIPT_DISK) as script:
        if script.write(data) != len(data):
            raise probe.Stop("SCRIPT_WRITE")
        script.flush()
        os.fsync(script.fileno())
        identity = _identity(os.fstat(script.fileno()))
    _artifact_identity(root, probe.SCRIPT_DISK, identity, probe.SCRIPT_BYTES)
    return identity


def _create_overlay(root):
    argv = probe.overlay_create_argv(root)
    # Reserve the final path atomically, then close the Python handle before the
    # owned Windows qemu-img process opens it.  Holding the handle across the
    # child launch prevents qemu-img from reopening/truncating the file on
    # Windows.  The inode/device check below binds the populated image back to
    # the exact reservation and fails closed if the path was replaced.
    with _exclusive(root, probe.OVERLAY) as overlay:
        before = _identity(os.fstat(overlay.fileno()))
        if before[2] != 0:
            raise probe.Stop("OVERLAY_RESERVATION")
        overlay.flush()
        os.fsync(overlay.fileno())
    _owned_process(argv, PROFILE["image_seconds"], PROFILE["image_output_bytes"])
    after = _identity(_plain_file_info(_safe_path(root, probe.OVERLAY)))
    if after[:2] != before[:2] or after[2] <= 0:
        raise probe.Stop("OVERLAY_RESERVATION")
    _artifact_identity(root, probe.OVERLAY, after)
    return after


def _image_info_argv(root):
    return [
        str(_safe_path(root, probe.IMAGE_TOOL)),
        "info",
        "--output=json",
        "--backing-chain",
        str(_safe_path(root, probe.OVERLAY)),
    ]


def _inspect_chain(root, overlay_identity):
    overlay = _artifact_identity(root, probe.OVERLAY, overlay_identity)
    before = _identity(_plain_file_info(overlay))
    raw = _owned_process(
        _image_info_argv(root),
        PROFILE["image_seconds"],
        PROFILE["image_output_bytes"],
    )
    if _identity(_plain_file_info(overlay)) != before:
        raise probe.Stop("IMAGE_CHAIN_IDENTITY")
    try:
        decoded = json.loads(raw.decode("ascii"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise probe.Stop("IMAGE_CHAIN_JSON")
    try:
        guard.validate_backing_chain(
            decoded, str(overlay), str(_safe_path(root, probe.BASE))
        )
    except guard.Stop:
        raise probe.Stop("IMAGE_CHAIN")
    return before


def _validate_serial(serial):
    probe.parse_serial(serial)


def _run(root, log):
    """One owned child, bounded nonblocking reads, no process-name cleanup."""
    argv = probe.qemu_argv(root)
    probe.validate_argv(argv, root)
    env = {key: os.environ[key] for key in ("SystemRoot", "WINDIR") if key in os.environ}
    child = subprocess.Popen(argv, cwd=root, env=env, stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             bufsize=0, shell=False, close_fds=True)
    owner_pid, owner_args = child.pid, tuple(child.args)
    serial = bytearray()
    deadline = time.monotonic() + PROFILE["seconds"]
    eof = False
    last_write = None

    def owned():
        if child.pid != owner_pid or tuple(child.args) != owner_args:
            raise probe.Stop("PROCESS_IDENTITY")

    def pump():
        nonlocal eof
        owned()
        if time.monotonic() >= deadline:
            raise probe.Stop("TIMEOUT")
        try:
            block = os.read(child.stdout.fileno(), 4096)
        except BlockingIOError:
            block = None
        if block == b"":
            eof = True
        if block:
            if len(serial) + len(block) > PROFILE["log_bytes"]:
                raise probe.Stop("LOG_OVERFLOW")
            serial.extend(block)
            if log.write(block) != len(block):
                raise probe.Stop("LOG_WRITE")
            log.flush()
        return bool(block)

    def send(command, before_first_write=None):
        nonlocal last_write
        owned()
        if child.poll() is not None:
            raise probe.Stop("PROCESS_EARLY_EXIT")
        for offset in range(0, len(command), 4):
            while last_write is not None and time.monotonic() - last_write < 0.2:
                pump()
                time.sleep(0.02)
            pump()
            if child.poll() is not None:
                raise probe.Stop("PROCESS_EARLY_EXIT")
            if offset == 0 and before_first_write is not None:
                if before_first_write() is not True:
                    raise probe.Stop("TERMINAL_HANDSHAKE")
            block = command[offset:offset + 4]
            if child.stdin.write(block) != len(block):
                raise probe.Stop("SERIAL_WRITE")
            child.stdin.flush()
            last_write = time.monotonic()

    def wait_for(predicate, allow_exit=False):
        while not predicate():
            pump()
            if not allow_exit and child.poll() is not None and not predicate():
                raise probe.Stop("PROCESS_EARLY_EXIT")
            if eof and not predicate() and not allow_exit:
                raise probe.Stop("SERIAL_EOF")
            time.sleep(0.02)

    def exact_echo(command, start):
        expected = command.replace(b"\r", b"")
        wait_for(lambda: b"\n" in bytes(serial[start:]).replace(b"\r", b""))
        actual = bytes(serial[start:]).replace(b"\r", b"").split(b"\n", 1)[0] + b"\n"
        if actual != expected:
            raise probe.Stop("SERIAL_ECHO")

    def prompt():
        # The observed Alpine initial prompt appends exactly one DSR request.
        # Do not strip general ANSI/control sequences or accept other suffixes.
        suffix = rb"(?:\x1b\[6n)?"
        return re.search(rb"(?:^|\n)[^\r\n\x1b]*[~/:]# " + suffix + rb"$",
                         bytes(serial)) is not None

    try:
        os.set_blocking(child.stdout.fileno(), False)
        wait_for(lambda: bytes(serial).endswith(b"login: "))
        start = len(serial)
        send(b"root\n")
        exact_echo(b"root\n", start)
        wait_for(prompt)
        # Leave the interactive line editor using only a short exact command.
        # No prompt, DSR, error or other suffix is permitted after this echo.
        start = len(serial)
        send(TERMINAL_HANDSHAKE)
        exact_echo(TERMINAL_HANDSHAKE, start)
        exec_end = start + bytes(serial[start:]).index(b"\n") + 1

        def after_exec():
            if bytes(serial[exec_end:]):
                raise probe.Stop("TERMINAL_HANDSHAKE")
            return True

        after_exec()
        start = len(serial)
        send(READY_COMMAND, before_first_write=after_exec)
        exact_echo(READY_COMMAND, start)
        ready_start = start + bytes(serial[start:]).index(b"\n") + 1
        expected_ready = READY_MARKER + b"\n"

        def ready_barrier():
            # Retain only the existing CRLF normalization, never ANSI stripping.
            # Exactly one fixed READY line and no suffix is the roundtrip proof.
            tail = bytes(serial[ready_start:]).replace(b"\r", b"")
            if not expected_ready.startswith(tail):
                raise probe.Stop("TERMINAL_HANDSHAKE")
            return tail == expected_ready

        wait_for(ready_barrier)
        start = len(serial)
        command = probe.serial_command().encode("ascii") + b"\n"
        # Recheck after send()'s pre-write read and before its first long byte.
        send(command, before_first_write=ready_barrier)
        exact_echo(command, start)
        # The fixed guest script owns sync, unmount, markers and poweroff -f.
        # A process may exit while pipe bytes remain, or EOF may precede exit.
        # Drain through BOTH conditions before accepting its exact markers.
        wait_for(lambda: child.poll() is not None and eof, allow_exit=True)
        code = child.wait(timeout=PROFILE["cleanup_seconds"])
        if type(code) is not int or code != 0:
            raise probe.Stop("QEMU_EXIT")
        _validate_serial(bytes(serial))
        return bytes(serial), code
    finally:
        # Popen methods target its owned OS process handle; never kill by name/PID lookup.
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=PROFILE["cleanup_seconds"])
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=PROFILE["cleanup_seconds"])
        child.stdin.close()
        child.stdout.close()
        if child.poll() is None:
            raise probe.Stop("PROCESS_NOT_CLOSED")


def execute(root, admission=None):
    """Run one admitted public probe; preserve diagnostics and never retry."""
    root, pins = _admit(root, admission)
    pre = _verify_inputs(root, pins)
    report = {
        "mode": probe.MODE,
        "public_only": True,
        "restore_acceptance": False,
        "private_backup_attached": False,
        "installed_boot_acceptance": False,
        "status": "FAILED",
        "profile_sha256": PROFILE_SHA256,
        "pins": {pin.name: pin.sha256 for pin in pins.values()},
        "clean_closeout": False,
        "post_pins_verified": False,
        "pre_chain_verified": False,
        "post_chain_verified": False,
    }
    result_path = _safe_path(root, probe.RESULT, exists=False)
    with _exclusive(root, probe.RESULT) as result:
        result_identity = _identity(os.fstat(result.fileno()))
        try:
            with _exclusive(root, probe.SERIAL_LOG) as log:
                script_identity = _create_script_disk(root)
                overlay_identity = _create_overlay(root)
                _inspect_chain(root, overlay_identity)
                report["pre_chain_verified"] = True
                _verify_inputs(root, pins, pre)
                script_path = _artifact_identity(
                    root, probe.SCRIPT_DISK, script_identity, probe.SCRIPT_BYTES
                )
                if _digest(script_path)[1] != _sha256(probe.render_script_disk()):
                    raise probe.Stop("SCRIPT_PIN")
                serial, exit_code = _run(root, log)
                if exit_code != 0:
                    raise probe.Stop("QEMU_EXIT")
                probe.parse_serial(serial)
                report["clean_closeout"] = True
                _verify_inputs(root, pins, pre)
                _artifact_identity(
                    root, probe.SCRIPT_DISK, script_identity, probe.SCRIPT_BYTES
                )
                if _digest(script_path)[1] != _sha256(probe.render_script_disk()):
                    raise probe.Stop("SCRIPT_POST_PIN")
                overlay_post = _identity(_plain_file_info(_safe_path(root, probe.OVERLAY)))
                if overlay_post[:2] != overlay_identity[:2]:
                    raise probe.Stop("OVERLAY_IDENTITY")
                _inspect_chain(root, overlay_post)
                report["post_chain_verified"] = True
                _verify_inputs(root, pins, pre)
                report["post_pins_verified"] = True
                report.update(
                    status="PUBLIC_INSTALLED_BOOT_ONLY_OK",
                    installed_boot_acceptance=True,
                )
        except Exception as error:
            report["error"] = (
                str(error) if isinstance(error, probe.Stop) else type(error).__name__
            )
        finally:
            if not report["post_pins_verified"]:
                try:
                    _verify_inputs(root, pins, pre)
                    report["post_pins_verified"] = True
                except Exception as post_error:
                    report["post_pin_error"] = (
                        str(post_error)
                        if isinstance(post_error, probe.Stop)
                        else type(post_error).__name__
                    )
        payload = json.dumps(report, indent=2, sort_keys=True).encode("ascii")
        if result.write(payload) != len(payload):
            raise probe.Stop("RESULT_WRITE")
        result.flush()
        os.fsync(result.fileno())
        if _identity(os.fstat(result.fileno()))[:2] != result_identity[:2]:
            raise probe.Stop("RESULT_IDENTITY")
    _artifact_identity(root, probe.RESULT, result_identity)
    return report


if __name__ == "__main__":
    raise SystemExit(
        "NOT_ADMITTED: CLI cannot execute; root-owned hash-bound Admission required"
    )
