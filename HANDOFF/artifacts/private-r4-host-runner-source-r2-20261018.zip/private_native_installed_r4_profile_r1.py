"""Inert private R4 diagnostic profile; execution stays in its reviewed executor."""
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path

import public_native_installed_r4_profile_r1 as public_r1
import private_native_r4_contract_r1 as contract

MODE = "PRIVATE_NATIVE_INSTALLED_R4_R1"
BASE, KERNEL, INITRAMFS = public_r1.BASE, public_r1.KERNEL, public_r1.INITRAMFS
TOOL, IMAGE_TOOL, PACK = public_r1.TOOL, public_r1.IMAGE_TOOL, public_r1.PACK
KERNEL_VERSION, ROOT_UUID = public_r1.KERNEL_VERSION, public_r1.ROOT_UUID
PACK_BYTES, PACK_SECTORS, PACK_SHA256 = public_r1.PACK_BYTES, public_r1.PACK_SECTORS, public_r1.PACK_SHA256
APPEND = public_r1.APPEND
PRIVATE_ADMISSION = "private_linux_admission_r4.py"
CAPSULE = "native-admission-private-r1/private-capsule-r1.raw"
CAPSULE_BYTES = 445440
CAPSULE_SECTORS = 870
CAPSULE_SHA256 = "9bb9a033757b39462e8b265d7d6452d3cf139fbe98a65543ed52f6e11099cb52"
OUTPUT_DIR = "native-admission-private-r4-installed-r1"
OVERLAY = "overlay.qcow2"
SERIAL_LOG = "serial.log"
RESULT = "result.json"
OUTPUT_NAMES = (OVERLAY, SERIAL_LOG, RESULT)
FRAME_LIMIT = 768
WIRE_LIMIT = 7000
RAW_PHASE_LIMIT = 4096
BOOT_SERIAL_LIMIT = 4 * 1024 * 1024
PAYLOAD_PATH = "/run/p"
SCRIPT_PATH = "/run/a.py"
POST_PATH = "/run/v.py"
BOUND_PATH = "/run/b.py"


class Stop(ValueError):
    """Fixed, non-sensitive diagnostic rejection."""


def _root(root):
    root = Path(root)
    if not root.is_absolute() or ".." in root.parts or any(c in str(root) for c in ",=\r\n\0"):
        raise Stop("ROOT_PATH")
    return root


def output_directory(root):
    return _root(root) / OUTPUT_DIR


def overlay_create_argv(root, output):
    root = _root(root)
    if Path(output) != output_directory(root):
        raise Stop("OUTPUT_PATH")
    return [str(root / IMAGE_TOOL), "create", "-f", "qcow2", "-F", "qcow2", "-b",
            (root / BASE).as_posix(), (Path(output) / OVERLAY).as_posix()]


def qemu_argv(root, output):
    root = _root(root)
    output = Path(output)
    if output != output_directory(root):
        raise Stop("OUTPUT_PATH")
    p = lambda name: (root / name).as_posix()
    return [str(root / TOOL), "-machine", "pc", "-accel", "tcg,thread=single", "-cpu", "qemu64",
            "-smp", "2", "-m", "2048", "-nodefaults", "-no-user-config", "-display", "none",
            "-monitor", "none", "-serial", "stdio", "-nic", "none", "-no-reboot", "-kernel", p(KERNEL),
            "-initrd", p(INITRAMFS), "-append", APPEND,
            "-drive", f"file={(output / OVERLAY).as_posix()},format=qcow2,if=virtio",
            "-drive", f"file={p(PACK)},format=raw,if=virtio,readonly=on",
            "-drive", f"file={p(CAPSULE)},format=raw,if=virtio,readonly=on"]


def validate_argv(argv, root, output):
    if type(argv) is not list or argv != qemu_argv(root, output):
        raise Stop("TOPOLOGY")


POST_VERIFY = b'''import os,hashlib,json,stat,sys
from pathlib import Path
assert sys.flags.optimize == 0
assert set(os.listdir('/sys/class/net')) == {'lo'}
assert set(os.listdir('/sys/class/block')) == {'vda','vda1','vda2','vdb','vdc'}|{'loop'+str(i) for i in range(8)}
assert (Path('/sys/class/block/vdb/ro').read_text().strip(), Path('/sys/class/block/vdb/size').read_text().strip()) == ('1', '700')
assert (Path('/sys/class/block/vdc/ro').read_text().strip(), Path('/sys/class/block/vdc/size').read_text().strip()) == ('1', '870')
assert hashlib.sha256(Path('/dev/vdb').read_bytes()).hexdigest() == '794ae82f5bcc44f2d058d51f096c7a286fde84ba44191e0dad6c29f0e7d0cbfd'
assert hashlib.sha256(Path('/dev/vdc').read_bytes()).hexdigest() == '9bb9a033757b39462e8b265d7d6452d3cf139fbe98a65543ed52f6e11099cb52'
T=Path('/root/private-native-admission-public-r4'); m=json.loads((T/'NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json').read_text()); e={x['Path']:x for x in m['sourceFiles']}; e['NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json']={'Bytes':len((T/'NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json').read_bytes()),'Sha256':'e9583a98a68c9ea021f8e0a4aa991301188eb2de2837f782de25894c809b51fa'}
assert len(e)==25 and set(os.listdir(T))==set(e) and all((lambda s,x:stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1 and s.st_size==x['Bytes'] and hashlib.sha256((T/n).read_bytes()).hexdigest()==x['Sha256'].lower())(os.lstat(T/n),x) for n,x in e.items())
assert not any(Path(p).exists() for p in ('/restore-native-admission-r4', '/restore-native-preparation-r1'))
assert not any(Path(p, 'comm').read_text().strip() in {'mariadbd','mysqld','mysql'} for p in Path('/proc').glob('[0-9]*') if (Path(p) / 'comm').is_file())
assert not any(line.split()[3]=='0A' for p in ('/proc/net/tcp','/proc/net/tcp6') for line in Path(p).read_text().splitlines()[1:])
print('PRIVATE_R4_POST_STOPPED_OK')
'''

BOUND_VERIFY = b'''import hashlib,json,os,stat,sys
from pathlib import Path
assert sys.flags.optimize == 0
assert set(os.listdir('/sys/class/net')) == {'lo'}
assert set(os.listdir('/sys/class/block')) == {'vda','vda1','vda2','vdb','vdc'}|{'loop'+str(i) for i in range(8)}
assert (Path('/sys/class/block/vdb/ro').read_text().strip(), Path('/sys/class/block/vdb/size').read_text().strip()) == ('1', '700')
assert (Path('/sys/class/block/vdc/ro').read_text().strip(), Path('/sys/class/block/vdc/size').read_text().strip()) == ('1', '870')
assert hashlib.sha256(Path('/dev/vdb').read_bytes()).hexdigest() == '794ae82f5bcc44f2d058d51f096c7a286fde84ba44191e0dad6c29f0e7d0cbfd'
assert hashlib.sha256(Path('/dev/vdc').read_bytes()).hexdigest() == '9bb9a033757b39462e8b265d7d6452d3cf139fbe98a65543ed52f6e11099cb52'
T=Path('/root/private-native-admission-public-r4'); m=json.loads((T/'NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json').read_text()); e={x['Path']:x for x in m['sourceFiles']}; e['NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json']={'Bytes':len((T/'NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json').read_bytes()),'Sha256':'e9583a98a68c9ea021f8e0a4aa991301188eb2de2837f782de25894c809b51fa'}
assert len(e)==25 and set(os.listdir(T))==set(e) and all((lambda s,x:stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1 and s.st_size==x['Bytes'] and hashlib.sha256((T/n).read_bytes()).hexdigest()==x['Sha256'].lower())(os.lstat(T/n),x) for n,x in e.items())
assert not any(Path(p, 'comm').read_text().strip() in {'mariadbd','mysqld','mysql'} for p in Path('/proc').glob('[0-9]*') if (Path(p) / 'comm').is_file())
assert not any(line.split()[3]=='0A' for p in ('/proc/net/tcp','/proc/net/tcp6') for line in Path(p).read_text().splitlines()[1:])
R=Path('/restore-native-admission-r4'); assert stat.S_ISDIR(os.lstat(R).st_mode) and stat.S_IMODE(os.lstat(R).st_mode)==0o700 and set(os.listdir(R))=={'native-source.sql.gz','admission.json'}
for n in ('native-source.sql.gz','admission.json'):
 s=os.lstat(R/n); assert stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1 and s.st_size>0
data=(R/'admission.json').read_bytes(); assert len(data)<=4096; a=json.loads(data); assert type(a) is dict
print(json.dumps({'format':'PRIVATE_R4_POST_BOUND','admission_sha256':hashlib.sha256(data).hexdigest(),'compressed_sha256':hashlib.sha256((R/'native-source.sql.gz').read_bytes()).hexdigest()},sort_keys=True))
print('PRIVATE_R4_POST_BOUND_OK')
'''


def _source(source):
    if type(source) is not bytes or not source or len(source) > 65536:
        raise Stop("ADMISSION_SOURCE")
    return source


def framed_commands(source):
    """Exact bounded public staging, then one private helper and one frozen binder."""
    source = _source(source)
    encoded = base64.b64encode(gzip.compress(source, mtime=0)).decode("ascii")
    post = base64.b64encode(gzip.compress(POST_VERIFY, mtime=0)).decode("ascii")
    bound = base64.b64encode(gzip.compress(BOUND_VERIFY, mtime=0)).decode("ascii")
    chunks = tuple(encoded[offset:offset + 640] for offset in range(0, len(encoded), 640))
    commands = [f"umask 077; set -C; : > {PAYLOAD_PATH}"]
    commands.extend(f"printf '%s' '{chunk}' >> {PAYLOAD_PATH}" for chunk in chunks)
    post_chunks = tuple(post[offset:offset + 640] for offset in range(0, len(post), 640))
    commands.append(f": > {POST_PATH}.b64")
    commands.extend(f"printf '%s' '{chunk}' >> {POST_PATH}.b64" for chunk in post_chunks)
    bound_chunks = tuple(bound[offset:offset + 640] for offset in range(0, len(bound), 640))
    commands.append(f": > {BOUND_PATH}.b64")
    commands.extend(f"printf '%s' '{chunk}' >> {BOUND_PATH}.b64" for chunk in bound_chunks)
    commands.extend((
        f"base64 -d < {POST_PATH}.b64 | gzip -d > {POST_PATH}",
        f"base64 -d < {BOUND_PATH}.b64 | gzip -d > {BOUND_PATH}",
        f"echo '{hashlib.sha256(encoded.encode('ascii')).hexdigest()}  {PAYLOAD_PATH}' | sha256sum -c - >/dev/null && "
        f"base64 -d < {PAYLOAD_PATH} | gzip -d > {SCRIPT_PATH} && "
        f"echo '{hashlib.sha256(source).hexdigest()}  {SCRIPT_PATH}' | sha256sum -c - >/dev/null && "
        f"python3 -I -S -B {SCRIPT_PATH} && env -i PATH=/usr/sbin:/usr/bin:/sbin:/bin "
        + " ".join(contract.binding_argv()) +
        f"; code=$?; if [ \"$code\" = 1 ]; then python3 -I -S -B {POST_PATH}; elif [ \"$code\" = 0 ]; then python3 -I -S -B {BOUND_PATH}; fi; poweroff -f",
    ))
    result = tuple(commands)
    if (not chunks or any(type(command) is not str or not command or "\n" in command or "\r" in command
                          or len(command.encode("ascii")) > FRAME_LIMIT for command in result)
            or sum(len(command.encode("ascii")) + 1 for command in result) > WIRE_LIMIT):
        raise Stop("WIRE_BUDGET")
    return result


def parse_phase(raw):
    """Expose only a pinned STOPPED result after both guest receipts validate."""
    if type(raw) is not bytes or not raw or len(raw) > RAW_PHASE_LIMIT:
        raise Stop("PHASE_BOUND")
    lines = raw.replace(b"\r", b"").splitlines()
    if len(lines) in (4, 5) and __import__('re').fullmatch(rb"\[ *[0-9]+\.[0-9]+\] reboot: Power down", lines[-1]):
        lines = lines[:-1]
    if len(lines) not in (3, 4):
        raise Stop("PHASE_OUTPUT")
    contract.parse_guest_admission(lines[0], 0, b"")
    code = 1 if lines[2] == b"PRIVATE_R4_POST_STOPPED_OK" else 0
    binding = contract.parse_binding(lines[1], code, b"")
    if binding.get("state") == "STOPPED":
        if lines != [lines[0], lines[1], b"PRIVATE_R4_POST_STOPPED_OK"]:
            raise Stop("PHASE_OUTPUT")
    elif binding.get("state") == "ADMISSION_BOUND":
        if len(lines) != 4 or lines[3] != b"PRIVATE_R4_POST_BOUND_OK":
            raise Stop("PHASE_OUTPUT")
        try:
            post = json.loads(lines[2].decode("ascii"))
        except (UnicodeDecodeError, ValueError):
            raise Stop("PHASE_OUTPUT")
        if (type(post) is not dict or set(post) != {"format", "admission_sha256", "compressed_sha256"}
                or post["format"] != "PRIVATE_R4_POST_BOUND"
                or post["admission_sha256"] != binding["admission_sha256"]
                or post["compressed_sha256"] != binding["compressed_sha256"]):
            raise Stop("PHASE_OUTPUT")
    else:
        raise Stop("PHASE_OUTPUT")
    return binding


def render_manifest(root):
    output = output_directory(root)
    return {"mode": MODE, "operation_admission": "NOT_ADMITTED", "restore_acceptance": False,
            "private_diagnostic_only": True, "fresh_output_directory": OUTPUT_DIR,
            "output_names": OUTPUT_NAMES, "overlay_argv": overlay_create_argv(root, output),
            "qemu_argv": qemu_argv(root, output), "frame_limit": FRAME_LIMIT,
            "wire_limit": WIRE_LIMIT, "raw_phase_limit": RAW_PHASE_LIMIT,
            "capsule": {"path": CAPSULE, "bytes": CAPSULE_BYTES, "sha256": CAPSULE_SHA256}}


if __name__ == "__main__":
    raise SystemExit("NOT_ADMITTED: private diagnostic profile only")
