"""Inert, public-only installed-kernel profile for the frozen R4 gate.

This module only renders the exact guest bootstrap and QEMU topology.  Importing
it or invoking it as a script cannot start a VM; ``execute`` lives behind a
separately reviewed operation plan in the companion executor.
"""

import base64
import gzip
import hashlib
import json
from pathlib import Path
import re

MODE = "PUBLIC_NATIVE_INSTALLED_R4"
BASE = "restore-guest.qcow2"
KERNEL = "public-installed-boot-stage-r8-vmlinuz-virt"
INITRAMFS = "public-installed-boot-stage-r8-initramfs-virt"
TOOL = "qemu-test-tools/qemu-system-x86_64.exe"
IMAGE_TOOL = "qemu-test-tools/qemu-img.exe"
PACK = "native-admission-public-r4.tar"
MANIFEST = "NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json"
ADMISSION_SOURCE = "public_linux_admission_r4.py"
BOOT_RECEIPT = "PUBLIC-INSTALLED-BOOT-PROBE-R1-RESULT.json"
BOOT_RECEIPT_SHA = "bcd0f10d8c60b1890118df635138b0f1daf0401597574119bb42acdc8fc34bf6"
KERNEL_VERSION = "6.18.56-0-virt"
ROOT_UUID = "27ef448f-e239-45d8-8401-78b6d8a9cc46"
PACK_BYTES = 358400
PACK_SECTORS = 700
PACK_SHA256 = "794ae82f5bcc44f2d058d51f096c7a286fde84ba44191e0dad6c29f0e7d0cbfd"
MANIFEST_SHA256 = "e9583a98a68c9ea021f8e0a4aa991301188eb2de2837f782de25894c809b51fa"
ADMISSION_SOURCE_BYTES = 3067
ADMISSION_SOURCE_SHA256 = "b4bcce25a456b80bfbe164b52482414ba798c6dd5b7605662f3a95a5c7842e02"
OVERLAY = "public-native-installed-r4-r1-overlay.qcow2"
SERIAL_LOG = "public-native-installed-r4-r1-serial.log"
RESULT = "PUBLIC-NATIVE-INSTALLED-R4-R1-RESULT.json"
OUTPUT_NAMES = (OVERLAY, SERIAL_LOG, RESULT)
APPEND = (f"root=UUID={ROOT_UUID} modules=virtio_pci,virtio_blk,ext4 "
          "rootfstype=ext4 console=ttyS0,115200 rw")
INPUT_PINS = {
    BASE: (1357119488, "4cf670261ec9adbe667df23a76b2be667970b862f427b0f7cf1f2657eb14dc9b"),
    KERNEL: (12637184, "dc99c86bb8e58cb4eda5f01eac44c4d972105945a46dfe76a9e86e8529915c72"),
    INITRAMFS: (8997605, "41f0cd2431f13258f9f0317ad503f51db3aa4e1410787bd2a86dec085d27d064"),
    TOOL: (None, "47d57a6072e0bb3bd98f87926eb129eb1736dfe818c67b3b81ef7ce4edd0b3cd"),
    IMAGE_TOOL: (None, "9d930582d0d574bb106d89982c547688e10b8f356192d302cc3d0ae4e8674534"),
    PACK: (PACK_BYTES, PACK_SHA256),
    MANIFEST: (None, MANIFEST_SHA256),
    ADMISSION_SOURCE: (ADMISSION_SOURCE_BYTES, ADMISSION_SOURCE_SHA256),
    BOOT_RECEIPT: (None, BOOT_RECEIPT_SHA),
}


class Stop(ValueError):
    """A bounded source/profile rejection."""


def _root(root):
    root = Path(root)
    if not root.is_absolute() or ".." in root.parts or any(c in str(root) for c in ",=\r\n\0"):
        raise Stop("ROOT_PATH")
    return root


def overlay_create_argv(root):
    root = _root(root)
    return [str(root / IMAGE_TOOL), "create", "-f", "qcow2", "-F", "qcow2", "-b",
            (root / BASE).as_posix(), (root / OVERLAY).as_posix()]


def qemu_argv(root):
    root = _root(root)
    p = lambda name: (root / name).as_posix()
    return [str(root / TOOL), "-machine", "pc", "-accel", "tcg,thread=single", "-cpu", "qemu64",
            "-smp", "2", "-m", "2048", "-nodefaults", "-no-user-config", "-display", "none",
            "-monitor", "none", "-serial", "stdio", "-nic", "none", "-no-reboot", "-kernel",
            p(KERNEL), "-initrd", p(INITRAMFS), "-append", APPEND,
            "-drive", f"file={p(OVERLAY)},format=qcow2,if=virtio",
            "-drive", f"file={p(PACK)},format=raw,if=virtio,readonly=on"]


def validate_argv(argv, root):
    if type(argv) is not list or argv != qemu_argv(root):
        raise Stop("TOPOLOGY")


def _checked_admission_source(admission_source):
    if (type(admission_source) is not bytes or len(admission_source) != ADMISSION_SOURCE_BYTES
            or hashlib.sha256(admission_source).hexdigest() != ADMISSION_SOURCE_SHA256):
        raise Stop("ADMISSION_SOURCE_PIN")
    return admission_source


def render_guest_bootstrap(admission_source):
    """Public guest program. It has no private paths or external services."""
    # The first command executes the exact frozen source before the subsequent
    # test commands.  The manifest-driven extraction is the frozen admission's
    # responsibility; this wrapper only verifies its wire and runtime boundary.
    source64 = base64.b64encode(_checked_admission_source(admission_source)).decode("ascii")
    return f'''#!/bin/sh
set -eu
fail() {{ echo PUBLIC_NATIVE_R4_CHECK_FAIL="$1"; echo PUBLIC_NATIVE_R4_STATUS=FAIL; poweroff -f; exit 1; }}
trap 'fail cleanup' HUP INT TERM
[ "$(id -u)" = 0 ] || fail uid
[ "$(uname -r)" = "{KERNEL_VERSION}" ] || fail kernel
[ "$(cat /proc/cmdline)" = "{APPEND}" ] || fail cmdline
[ "$(cat /sys/block/vda/ro)" = 0 ] || fail vda_rw
[ "$(cat /sys/block/vdb/ro)" = 1 ] || fail vdb_ro
[ "$(cat /sys/block/vdb/size)" = {PACK_SECTORS} ] || fail vdb_size
[ "$(ls /sys/class/net)" = lo ] || fail network
[ -z "$(ip route)" ] || fail route
[ -z "$(ip -6 route show default)" ] || fail route6
for d in /sys/block/*; do case "${{d##*/}}" in vda|vdb|loop[0-7]) ;; *) fail block;; esac; done
[ ! -e /dev/vdc ] || fail vdc
sha256sum /dev/vdb | grep -qx '{PACK_SHA256}  /dev/vdb' || fail pack_hash
mkdir /run/public-native-r4
printf '%s' '{source64}' | base64 -d > /run/public-native-r4/{ADMISSION_SOURCE}
sha256sum /run/public-native-r4/{ADMISSION_SOURCE} | grep -qx '{ADMISSION_SOURCE_SHA256}  /run/public-native-r4/{ADMISSION_SOURCE}' || fail source_wire
[ "$(sha256sum /run/public-native-r4/{ADMISSION_SOURCE} | awk '{{print $1}}')" = "{ADMISSION_SOURCE_SHA256}" ] || fail source_hash
[ "$(wc -c < /run/public-native-r4/{ADMISSION_SOURCE})" = {ADMISSION_SOURCE_BYTES} ] || fail source_bytes
python3 -I -S -B /run/public-native-r4/{ADMISSION_SOURCE} || fail admission
cd /root/public-native-admission-source-r4
python3 -B -m unittest -q test_native_prefix_structure_r4 test_native_admission_binding_r4 test_native_g056_structure_r1 test_native_admission_binding_r3 test_native_prefix_reasons_r3 test_native_admission_binding_r2 test_native_prefix_diagnostics_r2 test_indexed_lexer_equivalence_r1 > /run/public-native-r4/tests.out 2>&1 || {{ cat /run/public-native-r4/tests.out; fail tests; }}
cat /run/public-native-r4/tests.out
tests=$(sed -n 's/^Ran \\([0-9][0-9]*\\) tests.*/\\1/p' /run/public-native-r4/tests.out)
[ "$tests" = 81 ] || fail tests_count
grep -q '^Ran 81 tests in ' /run/public-native-r4/tests.out || fail tests_report
grep -qx 'OK' /run/public-native-r4/tests.out || fail tests_status
! grep -q 'skipped' /run/public-native-r4/tests.out || fail tests_skipped
python3 -B test_native_admission_binding_r2.py --linux-io {PACK_BYTES} {PACK_SHA256} > /run/public-native-r4/io.out 2>&1 || {{ cat /run/public-native-r4/io.out; fail io; }}
cat /run/public-native-r4/io.out
io=$(sed -n 's/.*"checks_passed": \\([0-9][0-9]*\\).*/\\1/p' /run/public-native-r4/io.out)
[ "$io" = 9 ] || fail io_count
io_rows=$(grep -c '"format": "NATIVE_ADMISSION_PUBLIC_IO_R2"' /run/public-native-r4/io.out)
[ "$io_rows" = 1 ] || fail io_report
grep -q '"pass": true' /run/public-native-r4/io.out || fail io_pass
grep -q '"last_check": "ROOT_RESTORED"' /run/public-native-r4/io.out || fail root_restored
python3 -I -S -B -c 'import hashlib,json,os,stat; from pathlib import Path; r=Path("/root/public-native-admission-source-r4"); m=json.loads((r/"{MANIFEST}").read_text()); e={{x["Path"]:x for x in m["sourceFiles"]}}; e["{MANIFEST}"]={{"Bytes":len((r/"{MANIFEST}").read_bytes()),"Sha256":"{MANIFEST_SHA256}"}}; assert len(e)==25 and {{p.name for p in r.iterdir()}}==set(e); assert all((lambda s,x:stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1 and s.st_size==x["Bytes"] and hashlib.sha256((r/n).read_bytes()).hexdigest()==x["Sha256"].lower())(os.lstat(r/n),x) for n,x in e.items())' || fail post_inventory
[ "$(cat /sys/block/vdb/ro)" = 1 ] && [ "$(cat /sys/block/vdb/size)" = {PACK_SECTORS} ] || fail post_vdb
sha256sum /dev/vdb | grep -qx '{PACK_SHA256}  /dev/vdb' || fail post_pack_hash
[ "$(ls /sys/class/net)" = lo ] && [ -z "$(ip route)" ] && [ -z "$(ip -6 route show default)" ] || fail post_network
python3 -I -S -B -c 'from pathlib import Path; assert not any(line.split()[3]=="0A" for p in ("/proc/net/tcp","/proc/net/tcp6") for line in Path(p).read_text().splitlines()[1:]); assert not any(Path(p,"comm").read_text().strip() in {{"mariadbd","mysqld","mysql"}} for p in Path("/proc").glob("[0-9]*") if (p/"comm").is_file())' || fail post_process
echo PUBLIC_NATIVE_R4_TESTS=$tests
echo PUBLIC_NATIVE_R4_IO=$io
echo PUBLIC_NATIVE_R4_ROOT=ROOT_RESTORED
echo PUBLIC_NATIVE_R4_EXIT=0
echo PUBLIC_NATIVE_R4_STATUS=OK
sync
poweroff -f
'''.encode("ascii")


def compressed_bootstrap(admission_source):
    raw = render_guest_bootstrap(admission_source)
    return gzip.compress(raw, mtime=0)


def wire_command(admission_source):
    compressed = compressed_bootstrap(admission_source)
    encoded = base64.b64encode(compressed).decode("ascii")
    digest = hashlib.sha256(render_guest_bootstrap(admission_source)).hexdigest()
    command = ("printf '%s' '" + encoded + "' | base64 -d | gzip -d > /run/public-native-r4.sh"
               + " && echo '" + digest + "  /run/public-native-r4.sh' | sha256sum -c -"
               + " && sh /run/public-native-r4.sh")
    if len(command.encode("ascii")) > 7000:
        raise Stop("WIRE_BUDGET")
    return command


def parse_serial(data):
    if type(data) is not bytes or len(data) > 4 * 1024 * 1024:
        raise Stop("SERIAL_BOUND")
    lines = data.replace(b"\r", b"").splitlines()
    required = (b"PUBLIC_NATIVE_R4_TESTS=81", b"PUBLIC_NATIVE_R4_IO=9",
                b"PUBLIC_NATIVE_R4_ROOT=ROOT_RESTORED", b"PUBLIC_NATIVE_R4_EXIT=0",
                b"PUBLIC_NATIVE_R4_STATUS=OK")
    if any(line.startswith(b"PUBLIC_NATIVE_R4_CHECK_FAIL=") for line in lines):
        raise Stop("SERIAL_CHECK_FAIL")
    if any(line == b"PUBLIC_NATIVE_R4_STATUS=FAIL" for line in lines):
        raise Stop("SERIAL_STATUS")
    ran = [line for line in lines if re.fullmatch(rb"Ran 81 tests in [0-9.]+s", line)]
    if len(ran) != 1 or lines.count(b"OK") != 1 or any(b"skipped" in line.lower() for line in lines):
        raise Stop("SERIAL_TEST_REPORT")
    reports = []
    for line in lines:
        if not line.startswith(b"{"):
            continue
        try:
            decoded = json.loads(line.decode("ascii"))
        except (UnicodeDecodeError, ValueError):
            continue
        if type(decoded) is dict and decoded.get("format") == "NATIVE_ADMISSION_PUBLIC_IO_R2":
            reports.append(decoded)
    if len(reports) != 1 or reports[0] != {
        "format": "NATIVE_ADMISSION_PUBLIC_IO_R2", "pass": True, "checks_passed": 9,
        "last_check": "ROOT_RESTORED", "private_input_opened": False,
        "admission_bound": False, "preparation_executed": False,
    }:
        raise Stop("SERIAL_IO_REPORT")
    prefixes = (b"PUBLIC_NATIVE_R4_TESTS=", b"PUBLIC_NATIVE_R4_IO=",
                b"PUBLIC_NATIVE_R4_ROOT=", b"PUBLIC_NATIVE_R4_EXIT=", b"PUBLIC_NATIVE_R4_STATUS=")
    if any(line.startswith(prefix) and line not in required for line in lines for prefix in prefixes):
        raise Stop("SERIAL_STATUS")
    for marker in required:
        if lines.count(marker) != 1:
            raise Stop("SERIAL_STATUS")
    if [lines.index(marker) for marker in required] != sorted(lines.index(marker) for marker in required):
        raise Stop("SERIAL_STATUS_ORDER")


def render_manifest(root):
    return {"mode": MODE, "operation_admission": "NOT_ADMITTED", "execution_implemented": True,
            "public_only": True, "installed_boot_acceptance": False, "restore_acceptance": False,
            "private_backup_attached": False, "installed_boot_input_receipt": BOOT_RECEIPT,
            "qemu_argv": qemu_argv(root),
            "overlay_argv": overlay_create_argv(root), "wire_limit": 7000,
            "fresh_output_names": OUTPUT_NAMES}


if __name__ == "__main__":
    raise SystemExit("NOT_ADMITTED: public source profile only")
