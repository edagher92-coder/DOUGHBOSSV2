"""Preparation-only direct installed-kernel boot profile; import/CLI never launch.

No private backup, WordPress code or provider configuration is referenced.
An executor, full tool closure and separate operation admission remain required.
"""
import hashlib
from pathlib import Path
import re

MODE = "PUBLIC_INSTALLED_BOOT_PROBE_R1"
KERNEL_VERSION = "6.18.56-0-virt"
ROOT_UUID = "27ef448f-e239-45d8-8401-78b6d8a9cc46"
BASE = "restore-guest.qcow2"
KERNEL = "public-installed-boot-stage-r8-vmlinuz-virt"
INITRAMFS = "public-installed-boot-stage-r8-initramfs-virt"
TOOL = "qemu-test-tools/qemu-system-x86_64.exe"
IMAGE_TOOL = "qemu-test-tools/qemu-img.exe"
R8_RECEIPT = "PUBLIC-INSTALLED-BOOT-STAGE-R8-RESULT.json"
R8_RECEIPT_SHA = "93d6c472d85c6173a765e76c48fb6231317b490bc67dec85422f1175ac928f8c"
INPUT_PINS = {
    BASE: (1357119488, "4cf670261ec9adbe667df23a76b2be667970b862f427b0f7cf1f2657eb14dc9b"),
    KERNEL: (12637184, "dc99c86bb8e58cb4eda5f01eac44c4d972105945a46dfe76a9e86e8529915c72"),
    INITRAMFS: (8997605, "41f0cd2431f13258f9f0317ad503f51db3aa4e1410787bd2a86dec085d27d064"),
    TOOL: (None, "47d57a6072e0bb3bd98f87926eb129eb1736dfe818c67b3b81ef7ce4edd0b3cd"),
    IMAGE_TOOL: (None, "9d930582d0d574bb106d89982c547688e10b8f356192d302cc3d0ae4e8674534"),
}
OVERLAY = "public-installed-boot-probe-r1-overlay.qcow2"
SCRIPT_DISK = "public-installed-boot-probe-r1-script.raw"
SERIAL_LOG = "public-installed-boot-probe-r1-serial.log"
RESULT = "PUBLIC-INSTALLED-BOOT-PROBE-R1-RESULT.json"
OUTPUT_NAMES = (OVERLAY, SCRIPT_DISK, SERIAL_LOG, RESULT)
APPEND = (f"root=UUID={ROOT_UUID} modules=virtio_pci,virtio_blk,ext4 "
          "rootfstype=ext4 console=ttyS0,115200 rw")
SCRIPT_BYTES = 4096
MARKERS = (
    (b"PUBLIC_BOOT_R1_KERNEL=", b"PUBLIC_BOOT_R1_KERNEL=6.18.56-0-virt"),
    (b"PUBLIC_BOOT_R1_ROOT=", b"PUBLIC_BOOT_R1_ROOT=27ef448f-e239-45d8-8401-78b6d8a9cc46"),
    (b"PUBLIC_BOOT_R1_RUNTIME=", b"PUBLIC_BOOT_R1_RUNTIME=PHP84_PY3_MARIADB_PRESENT"),
    (b"PUBLIC_BOOT_R1_STATUS=", b"PUBLIC_BOOT_R1_STATUS=OK"),
    (b"PUBLIC_BOOT_R1_EXIT=", b"PUBLIC_BOOT_R1_EXIT=0"),
)


class Stop(ValueError):
    """Bounded public preparation/result rejection."""


def _root(root):
    root = Path(root)
    if not root.is_absolute() or ".." in root.parts or any(c in str(root) for c in ",=\r\n\0"):
        raise Stop("ROOT_PATH")
    return root


def overlay_create_argv(root):
    """Render only; executor must exclusively reserve the fresh destination."""
    root = _root(root)
    return [str(root / IMAGE_TOOL), "create", "-f", "qcow2", "-F", "qcow2",
            "-b", (root / BASE).as_posix(), (root / OVERLAY).as_posix()]


def qemu_argv(root):
    root = _root(root)
    p = lambda name: (root / name).as_posix()
    return [str(root / TOOL), "-machine", "pc", "-accel", "tcg,thread=single",
            "-cpu", "qemu64", "-smp", "2", "-m", "2048", "-nodefaults",
            "-no-user-config", "-display", "none", "-monitor", "none",
            "-serial", "stdio", "-nic", "none", "-no-reboot",
            "-kernel", p(KERNEL), "-initrd", p(INITRAMFS), "-append", APPEND,
            "-drive", f"file={p(OVERLAY)},format=qcow2,if=virtio",
            "-drive", f"file={p(SCRIPT_DISK)},format=raw,if=virtio,readonly=on"]


def validate_argv(argv, root):
    if type(argv) is not list or argv != qemu_argv(root):
        raise Stop("TOPOLOGY")


def render_guest_script():
    """Fixed public checks only. Does not start a database or execute WP code."""
    script = f'''#!/bin/sh
set -eu
check=SCRIPT_START
finish() {{
 e=$?
 trap - EXIT
 sync || {{ if [ "$e" = 0 ]; then check=CLEANUP_SYNC; fi; e=1; }}
 if [ "$e" = 0 ]; then echo PUBLIC_BOOT_R1_STATUS=OK; else echo PUBLIC_BOOT_R1_CHECK_FAIL=$check; echo PUBLIC_BOOT_R1_STATUS=FAIL; fi
 echo PUBLIC_BOOT_R1_EXIT=$e
 poweroff -f
 exit "$e"
}}
trap finish EXIT
check=ROOT_UID
[ "$(id -u)" = 0 ]
check=INSTALLED_KERNEL
[ "$(uname -r)" = "{KERNEL_VERSION}" ]
echo PUBLIC_BOOT_R1_KERNEL={KERNEL_VERSION}
check=CMDLINE
[ "$(cat /proc/cmdline)" = "{APPEND}" ]
check=ROOT_MOUNT_COUNT
[ "$(awk '$2 == "/" {{ n++ }} END {{ print n+0 }}' /proc/mounts)" = 1 ]
check=ROOT_MOUNT_DEVICE
[ "$(awk '$2 == "/" {{ print $1, $3 }}' /proc/mounts)" = '/dev/vda2 ext4' ]
check=ROOT_MOUNT_READ_WRITE
[ "$(awk '$2 == "/" {{ n=split($4,a,","); for(i=1;i<=n;i++) {{ if(a[i]=="rw") w++; if(a[i]=="ro") r++ }} }} END {{ print w+0,r+0 }}' /proc/mounts)" = '1 0' ]
check=ROOT_UUID
blkid /dev/vda2 | grep -q ' UUID="{ROOT_UUID}"'
echo PUBLIC_BOOT_R1_ROOT={ROOT_UUID}
check=VDA_SIZE
[ "$(cat /sys/block/vda/size)" = 12582912 ]
check=VDA_READ_WRITE
[ "$(cat /sys/block/vda/ro)" = 0 ]
check=VDB_SIZE
[ "$(cat /sys/block/vdb/size)" = 8 ]
check=VDB_READ_ONLY
[ "$(cat /sys/block/vdb/ro)" = 1 ]
check=NETWORK_INTERFACE_SET
[ "$(ls /sys/class/net)" = lo ]
check=IPV4_ROUTE_SET
r=$(ip route); [ -z "$r" ]
check=IPV6_DEFAULT_ROUTE
r=$(ip -6 route show default); [ -z "$r" ]
for d in /sys/block/*; do
 check=BLOCK_DEVICE_SET
 case "${{d##*/}}" in
 vda|vdb) ;;
 loop[0-7])
 check=INACTIVE_LOOP_SIZE; [ "$(cat "$d/size")" = 0 ]
 check=INACTIVE_LOOP_RO; [ "$(cat "$d/ro")" = 0 ]
 check=INACTIVE_LOOP_BACKING
 [ ! -e "$d/loop/backing_file" ]
 [ ! -L "$d/loop/backing_file" ] ;;
 *) exit 1 ;;
 esac
done
for d in /sys/class/block/*; do
 check=CLASS_BLOCK_SET
 case "${{d##*/}}" in vda|vda1|vda2|vdb|loop[0-7]) ;; *) exit 1 ;; esac
done
check=INSTALLED_MODULE_METADATA
[ -s /lib/modules/{KERNEL_VERSION}/modules.dep ]
[ -s /lib/modules/{KERNEL_VERSION}/modules.builtin ]
check=INSTALLED_MODULE_VERMAGIC
python3 -I -S -B -c 'import gzip; from pathlib import Path; r=Path("/lib/modules/{KERNEL_VERSION}"); names=("kernel/fs/ext4/ext4.ko.gz","kernel/drivers/block/virtio_blk.ko.gz"); dep=(r/"modules.dep").read_bytes(); v=b"vermagic={KERNEL_VERSION} "; data=[gzip.open(r/n,"rb").read(16777217) for n in names]; assert all(n.encode()+b":" in dep for n in names); assert all(len(b)<=16777216 and b.startswith(b"\\x7fELF") and v in b for b in data)'
check=PHP84_RUNTIME
[ "$(php84 -n -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')" = 8.4 ]
check=PYTHON3_RUNTIME
python3 -I -S -B -c 'import sys; assert sys.version_info.major == 3'
check=MARIADB_BINARY
mariadbd --no-defaults --version
echo PUBLIC_BOOT_R1_RUNTIME=PHP84_PY3_MARIADB_PRESENT
'''.encode("ascii")
    if len(script) > SCRIPT_BYTES:
        raise Stop("SCRIPT_TOO_LARGE")
    return script


def render_script_disk():
    return render_guest_script().ljust(SCRIPT_BYTES, b"\0")


def serial_command():
    script = render_guest_script()
    digest = hashlib.sha256(script).hexdigest()
    return (f"dd if=/dev/vdb of=/run/public-installed-boot-probe-r1.sh bs=1 count={len(script)}"
            f" && echo '{digest}  /run/public-installed-boot-probe-r1.sh' | sha256sum -c -"
            " && sh /run/public-installed-boot-probe-r1.sh")


def parse_serial(data: bytes, Stop=Stop) -> None:
    if type(data) is not bytes:
        raise Stop("SERIAL_BOUND")
    if len(data) > 4194304:
        raise Stop("SERIAL_BOUND")

    lines = data.splitlines()

    check_fail_lines = []
    for line in lines:
        if line.startswith(b"PUBLIC_BOOT_R1_CHECK_FAIL="):
            check_fail_lines.append(line)

    if check_fail_lines:
        valid_labels = []
        for line in check_fail_lines:
            payload = line[len(b"PUBLIC_BOOT_R1_CHECK_FAIL="):]
            if re.fullmatch(rb"[A-Z][A-Z0-9_]{0,63}", payload):
                valid_labels.append(payload)
        if len(valid_labels) == 1 and len(check_fail_lines) == 1:
            raise Stop("SERIAL_CHECK_FAIL:" + valid_labels[0].decode("ascii"))
        else:
            raise Stop("SERIAL_CHECK_FAIL")

    expected_prefixes = [
        b"PUBLIC_BOOT_R1_KERNEL=",
        b"PUBLIC_BOOT_R1_ROOT=",
        b"PUBLIC_BOOT_R1_RUNTIME=",
        b"PUBLIC_BOOT_R1_STATUS=",
        b"PUBLIC_BOOT_R1_EXIT=",
    ]

    collected = {}
    for line in lines:
        for prefix in expected_prefixes:
            if line.startswith(prefix):
                value = line[len(prefix):]
                if prefix in collected:
                    if collected[prefix] != value:
                        raise Stop("SERIAL_STATUS")
                    else:
                        raise Stop("SERIAL_STATUS")
                else:
                    collected[prefix] = value

    for prefix in expected_prefixes:
        if prefix not in collected:
            raise Stop("SERIAL_STATUS")

    required_values = {
        b"PUBLIC_BOOT_R1_KERNEL=": b"6.18.56-0-virt",
        b"PUBLIC_BOOT_R1_ROOT=": b"27ef448f-e239-45d8-8401-78b6d8a9cc46",
        b"PUBLIC_BOOT_R1_RUNTIME=": b"PHP84_PY3_MARIADB_PRESENT",
        b"PUBLIC_BOOT_R1_STATUS=": b"OK",
        b"PUBLIC_BOOT_R1_EXIT=": b"0",
    }

    for prefix, expected_value in required_values.items():
        if collected[prefix] != expected_value:
            raise Stop("SERIAL_STATUS")

    line_indices = {}
    for i, line in enumerate(lines):
        for prefix in expected_prefixes:
            if line.startswith(prefix):
                if prefix not in line_indices:
                    line_indices[prefix] = i
                else:
                    raise Stop("SERIAL_STATUS")

    indices = [line_indices[p] for p in expected_prefixes]
    if indices != sorted(indices):
        raise Stop("SERIAL_STATUS_ORDER")

    return None



def render_manifest(root):
    script = render_guest_script()
    return {"mode": MODE, "operation_admission": "NOT_ADMITTED", "execution_implemented": False,
            "public_only": True, "installed_boot_acceptance": False, "restore_acceptance": False,
            "private_backup_attached": False, "argv": qemu_argv(root),
            "overlay_create_argv": overlay_create_argv(root), "input_pins": INPUT_PINS,
            "r8_receipt": R8_RECEIPT, "r8_receipt_sha256": R8_RECEIPT_SHA,
            "script_bytes": len(script), "script_sha256": hashlib.sha256(script).hexdigest(),
            "script_disk_sha256": hashlib.sha256(render_script_disk()).hexdigest(),
            "fresh_output_names": OUTPUT_NAMES,
            "pending": ["reviewed source-byte-only executor/caller and exact runtime profile",
                        "fresh pre/post public source/image/tool/closure identities",
                        "exclusive fresh overlay with exact immutable backing chain",
                        "owned bounded serial transport and clean process/pipe closeout",
                        "image checks and readback before runtime acceptance",
                        "separate exact operation review and root admission"]}


if __name__ == "__main__":
    raise SystemExit("NOT_ADMITTED: preparation only; no execution implemented")
