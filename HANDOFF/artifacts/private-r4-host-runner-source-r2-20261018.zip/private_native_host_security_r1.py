"""Read-only Windows ACL/identity checks for the isolated private diagnostic."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

POWERSHELL=Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
SYSTEM="S-1-5-18"
FULL_CONTROL=2032127

class SecurityStop(ValueError): pass

def _need(value):
    if value is not True: raise SecurityStop("PRIVATE_SECURITY_NOT_ADMITTED")

def _sid(value):
    _need(type(value) is str and re.fullmatch(r"S-1-5-21-[0-9]+-[0-9]+-[0-9]+-[0-9]+",value) is not None)
    return value

def _ps(script):
    _need(os.name=="nt")
    script="$ProgressPreference='SilentlyContinue'; "+script
    argv=[str(POWERSHELL),"-NoLogo","-NoProfile","-NonInteractive","-EncodedCommand",base64.b64encode(script.encode("utf-16le")).decode("ascii")]
    child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False,close_fds=True,creationflags=0x08000000,env={k:os.environ[k] for k in ("SystemRoot","WINDIR") if k in os.environ})
    failed=False; out=err=b""
    try:
        try: out,err=child.communicate(timeout=15)
        except subprocess.TimeoutExpired: failed=True
        if not failed: failed=child.returncode!=0 or bool(err) or len(out)>16384
    finally:
        if child.poll() is None:
            child.terminate()
            try: child.communicate(timeout=3)
            except subprocess.TimeoutExpired: child.kill(); child.communicate(timeout=3)
        if child.stdout is not None: child.stdout.close()
        if child.stderr is not None: child.stderr.close()
    _need(not failed and child.poll() is not None)
    result=None
    try: result=json.loads(out.decode("utf-8-sig"))
    except (ValueError,UnicodeError,RecursionError): pass
    _need(type(result) is dict)
    return result

def current_sid():
    result=_ps("$ErrorActionPreference='Stop'; [pscustomobject]@{sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value} | ConvertTo-Json -Compress")
    _need(set(result)=={"sid"})
    return _sid(result["sid"])

def _acl(path):
    encoded=base64.b64encode(str(path).encode("utf-16le")).decode("ascii")
    script="""$ErrorActionPreference='Stop';
$p=[Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PATH64'));
$a=Get-Acl -LiteralPath $p;
$r=@($a.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));
if($r.Count -gt 8){throw 'PRIVATE_ACL_BOUND'};
$rows=@($r | ForEach-Object {[pscustomobject]@{sid=$_.IdentityReference.Value;kind=[string]$_.AccessControlType;rights=[long]$_.FileSystemRights;inherited=[bool]$_.IsInherited;inheritance=[int]$_.InheritanceFlags;propagation=[int]$_.PropagationFlags}});
[pscustomobject]@{owner=$a.GetOwner([Security.Principal.SecurityIdentifier]).Value;protected=[bool]$a.AreAccessRulesProtected;rules=$rows;sddl=[string]$a.Sddl} | ConvertTo-Json -Depth 5 -Compress
""".replace("PATH64",encoded)
    return _ps(script)

def _identity(info):
    return (info.st_dev,info.st_ino,info.st_mode,info.st_nlink,info.st_size,info.st_mtime_ns)

def verify_powershell(expected_sha):
    """Pin the fixed Windows binary; its two OS hardlinks are not private files."""
    _need(type(expected_sha) is str and re.fullmatch(r"[0-9a-f]{64}",expected_sha) is not None)
    path=POWERSHELL
    _need(path.is_absolute() and not str(path).startswith("\\\\") and ".." not in path.parts)
    for item in (path,*path.parents):
        info=os.lstat(item)
        _need(not bool(getattr(info,"st_file_attributes",0)&0x400))
        if item!=path: _need(stat.S_ISDIR(info.st_mode))
    before=os.lstat(path)
    _need(stat.S_ISREG(before.st_mode) and before.st_nlink==2)
    # Windows pathname stat infers executable permission from .exe; fstat does not.
    # Compare the real file type and every identity/content attribute on the handle.
    def opened_identity(info):
        return (info.st_dev,info.st_ino,stat.S_IFMT(info.st_mode),info.st_nlink,info.st_size,info.st_mtime_ns)
    digest=hashlib.sha256()
    with path.open("rb") as stream:
        _need(opened_identity(os.fstat(stream.fileno()))==opened_identity(before))
        for block in iter(lambda:stream.read(1024*1024),b""): digest.update(block)
        _need(opened_identity(os.fstat(stream.fileno()))==opened_identity(before))
    _need(_identity(os.lstat(path))==_identity(before) and digest.hexdigest()==expected_sha)
    return True

def _plain(path,directory):
    path=Path(path)
    _need(path.is_absolute() and not str(path).startswith("\\\\") and ".." not in path.parts)
    for item in (path,*path.parents):
        info=os.lstat(item)
        _need(not bool(getattr(info,"st_file_attributes",0)&0x400))
        if item!=path: _need(stat.S_ISDIR(info.st_mode))
    info=os.lstat(path)
    _need(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode) and info.st_nlink==1)
    return path,info

def _check_acl(record,owner_sid,directory):
    _sid(owner_sid)
    _need(type(record) is dict and set(record)=={"owner","protected","rules","sddl"})
    _need(record["owner"]==owner_sid and type(record["protected"]) is bool)
    _need(not directory or record["protected"] is True)
    rows=record["rules"]
    _need(type(rows) is list and len(rows)==2 and type(record["sddl"]) is str and 0<len(record["sddl"])<=8192)
    seen=set()
    for row in rows:
        _need(type(row) is dict and set(row)=={"sid","kind","rights","inherited","inheritance","propagation"})
        _need(type(row["sid"]) is str and row["sid"] in {owner_sid,SYSTEM} and row["sid"] not in seen)
        _need(row["kind"]=="Allow" and type(row["rights"]) is int and row["rights"]==FULL_CONTROL)
        _need(type(row["inherited"]) is bool and type(row["inheritance"]) is int and type(row["propagation"]) is int and row["propagation"]==0)
        _need((row["inheritance"]==3 and row["inherited"] is False) if directory else row["inheritance"]==0)
        seen.add(row["sid"])
    _need(seen=={owner_sid,SYSTEM})
    return hashlib.sha256(record["sddl"].encode("utf-8")).hexdigest()

def verify_private_directory(path,owner_sid):
    path,before=_plain(path,True)
    digest=_check_acl(_acl(path),owner_sid,True)
    _need(_identity(os.lstat(path))==_identity(before))
    return {"file_id":[str(before.st_dev),str(before.st_ino)],"acl_sha256":digest}

def verify_private_file(path,owner_sid):
    path,before=_plain(path,False)
    verify_private_directory(path.parent,owner_sid)
    digest=_check_acl(_acl(path),owner_sid,False)
    _need(_identity(os.lstat(path))==_identity(before))
    return {"file_id":[str(before.st_dev),str(before.st_ino)],"acl_sha256":digest}

if __name__=="__main__": raise SystemExit("NOT_ADMITTED: read-only security helper")
