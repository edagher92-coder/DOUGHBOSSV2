import importlib,io,os,pathlib,subprocess,sys,tempfile,types,unittest
from unittest import mock
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
s=importlib.import_module("private_native_host_security_r1")
OWNER="S-1-5-21-1-2-3-1001"

class SecurityTests(unittest.TestCase):
    def record(self,directory):
        return {"owner":OWNER,"protected":directory,"sddl":"synthetic-sddl","rules":[{"sid":sid,"kind":"Allow","rights":s.FULL_CONTROL,"inherited":not directory,"inheritance":3 if directory else 0,"propagation":0} for sid in (OWNER,s.SYSTEM)]}
    def test_exact_directory_and_inherited_file_policy(self):
        for directory in (True,False): self.assertEqual(len(s._check_acl(self.record(directory),OWNER,directory)),64)
    def test_unknown_owner_principal_deny_rights_and_inheritance_reject(self):
        mutations=(("sid","S-1-1-0"),("kind","Deny"),("rights",True),("rights",0),("inheritance",2),("propagation",1),("inherited",True))
        for key,value in mutations:
            record=self.record(True); record["rules"][0][key]=value
            with self.subTest(key=key,value=value),self.assertRaises(s.SecurityStop): s._check_acl(record,OWNER,True)
        for key,value in (("owner",s.SYSTEM),("protected",False),("rules",[]),("sddl","")):
            record=self.record(True); record[key]=value
            with self.subTest(key=key),self.assertRaises(s.SecurityStop): s._check_acl(record,OWNER,True)
    def test_duplicate_sid_extra_fields_and_malformed_values_reject(self):
        record=self.record(True); record["rules"][1]["sid"]=OWNER
        with self.assertRaises(s.SecurityStop): s._check_acl(record,OWNER,True)
        for value in (None,[],{"extra":True},"raw"):
            with self.assertRaises(s.SecurityStop): s._check_acl(value,OWNER,True)
        record=self.record(True); record["rules"][0]["extra"]=True
        with self.assertRaises(s.SecurityStop): s._check_acl(record,OWNER,True)
    def test_real_fixture_identity_and_readonly_checks(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw); file=root/"synthetic.log"; file.write_bytes(b"synthetic")
            with mock.patch.object(s,"_acl",side_effect=lambda path:self.record(path.is_dir())):
                token=s.verify_private_file(file,OWNER)
                self.assertEqual(len(token["acl_sha256"]),64)
                self.assertTrue(all(type(value) is str and value.isdecimal() for value in token["file_id"]))
                before=file.read_bytes()
                s.verify_private_directory(root,OWNER)
                self.assertEqual(file.read_bytes(),before)
    def test_acl_time_file_identity_change_rejects(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw); file=root/"synthetic.log"; file.write_bytes(b"a")
            def changed(path):
                if path==file: file.write_bytes(b"changed")
                return self.record(path.is_dir())
            with mock.patch.object(s,"_acl",side_effect=changed),self.assertRaises(s.SecurityStop): s.verify_private_file(file,OWNER)
    def test_plain_paths_and_hardlinks_reject(self):
        with self.assertRaises(s.SecurityStop): s._plain(pathlib.Path("relative"),True)
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw); file=root/"synthetic.log"; file.write_bytes(b"a")
            with self.assertRaises(s.SecurityStop): s._plain(root,False)
            with self.assertRaises(s.SecurityStop): s._plain(file,True)
            os.link(file,root/"synthetic-link.log")
            with self.assertRaises(s.SecurityStop): s._plain(file,False)
    def test_reparse_path_rejects_before_acl(self):
        with tempfile.TemporaryDirectory() as raw:
            path=pathlib.Path(raw); original=os.lstat
            fake=types.SimpleNamespace(st_file_attributes=0x400)
            with mock.patch.object(s.os,"lstat",side_effect=lambda item:fake if pathlib.Path(item)==path else original(item)),self.assertRaises(s.SecurityStop): s._plain(path,True)
    def test_metadata_process_is_hidden_bounded_and_closed(self):
        children=[]
        class Child:
            def __init__(self,*args,**kwargs):
                self.returncode=0; self.stdout=io.BytesIO(); self.stderr=io.BytesIO(); self.args=args; self.kwargs=kwargs; children.append(self)
            def communicate(self,timeout): self.timeout=timeout; return b'{"sid":"S-1-5-21-1-2-3-1001"}',b''
            def poll(self): return self.returncode
        with mock.patch.object(s.subprocess,"Popen",side_effect=Child): self.assertEqual(s.current_sid(),OWNER)
        self.assertEqual(children[0].kwargs["creationflags"],0x08000000)
        self.assertFalse(children[0].kwargs["shell"])
        self.assertEqual(children[0].timeout,15)
        self.assertTrue(children[0].stdout.closed and children[0].stderr.closed)
    def test_metadata_timeout_terminates_owned_child_and_rejects(self):
        children=[]
        class Child:
            def __init__(self,*args,**kwargs):
                self.returncode=None; self.stdout=io.BytesIO(); self.stderr=io.BytesIO(); self.calls=0; self.terminated=False; children.append(self)
            def communicate(self,timeout):
                self.calls+=1
                if self.calls==1: raise subprocess.TimeoutExpired("synthetic",timeout)
                return b'{}',b''
            def poll(self): return self.returncode
            def terminate(self): self.terminated=True; self.returncode=0
            def kill(self): self.returncode=-1
        with mock.patch.object(s.subprocess,"Popen",side_effect=Child),self.assertRaises(s.SecurityStop): s.current_sid()
        self.assertTrue(children[0].terminated)
        self.assertTrue(children[0].stdout.closed and children[0].stderr.closed)
    def test_fixed_os_binary_requires_two_links_and_exact_hash(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw); binary=root/"synthetic.exe"; binary.write_bytes(b"synthetic-os-binary")
            digest=s.hashlib.sha256(binary.read_bytes()).hexdigest()
            with mock.patch.object(s,"POWERSHELL",binary):
                with self.assertRaises(s.SecurityStop): s.verify_powershell(digest)
                os.link(binary,root/"os-link.exe")
                self.assertIs(s.verify_powershell(digest),True)
                for bad in ("0"*64,digest.upper(),False,[],"short"):
                    with self.assertRaises(s.SecurityStop): s.verify_powershell(bad)
                with self.assertRaises(s.SecurityStop): s._plain(binary,False)
    def test_fixed_os_binary_identity_drift_and_reparse_reject(self):
        with tempfile.TemporaryDirectory() as raw:
            root=pathlib.Path(raw); binary=root/"synthetic.exe"; binary.write_bytes(b"synthetic-os-binary")
            os.link(binary,root/"os-link.exe")
            digest=s.hashlib.sha256(binary.read_bytes()).hexdigest()
            original=os.fstat
            def changed(fd):
                info=original(fd)
                return types.SimpleNamespace(st_dev=info.st_dev,st_ino=info.st_ino+1,st_mode=info.st_mode,st_nlink=info.st_nlink,st_size=info.st_size,st_mtime_ns=info.st_mtime_ns)
            with mock.patch.object(s,"POWERSHELL",binary),mock.patch.object(s.os,"fstat",side_effect=changed),self.assertRaises(s.SecurityStop): s.verify_powershell(digest)
            lstat=os.lstat
            with mock.patch.object(s,"POWERSHELL",binary),mock.patch.object(s.os,"lstat",side_effect=lambda p:types.SimpleNamespace(st_file_attributes=0x400) if pathlib.Path(p)==binary else lstat(p)),self.assertRaises(s.SecurityStop): s.verify_powershell(digest)
    def test_sid_requires_named_local_owner(self):
        for bad in (s.SYSTEM,"S-1-1-0",None,False,[],"S-1-5-21-x-2-3-4"):
            with self.assertRaises(s.SecurityStop): s._sid(bad)

if __name__=="__main__": unittest.main()
