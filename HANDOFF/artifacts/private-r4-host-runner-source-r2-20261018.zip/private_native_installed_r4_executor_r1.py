"""Private R4 diagnostic executor.  Import and CLI never admit an operation."""
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import time

import private_native_installed_r4_profile_r1 as profile
import private_native_r4_contract_r1 as contract
import private_native_host_security_r1 as security
import public_installed_boot_probe_executor_r2 as frozen
import public_native_installed_r4_profile_r1 as public_r1

MIB = 1024 * 1024
EXECUTOR = "private_native_installed_r4_executor_r1.py"
PROFILE_MODULE = "private_native_installed_r4_profile_r1.py"
PUBLIC_PROFILE = "public_native_installed_r4_profile_r1.py"
FROZEN_HELPER = "public_installed_boot_probe_executor_r2.py"
FROZEN_PROBE = "public_installed_boot_probe_r1.py"
FROZEN_GUARD = "public_installed_boot_image_guard_r1.py"
CONTRACT = "private_native_r4_contract_r1.py"
SECURITY = "private_native_host_security_r1.py"
PROFILE = {"mode": profile.MODE, "private_diagnostic_only": True, "seconds": 600,
           "log_bytes": profile.BOOT_SERIAL_LIMIT, "phase_bytes": profile.RAW_PHASE_LIMIT,
           "write_bytes": 4, "write_interval": .2, "cleanup_seconds": 3}
PROFILE_SHA256 = hashlib.sha256(json.dumps(PROFILE, sort_keys=True).encode("ascii")).hexdigest()
REQUIRED = (EXECUTOR, PROFILE_MODULE, PUBLIC_PROFILE, FROZEN_HELPER, FROZEN_PROBE,
            FROZEN_GUARD, CONTRACT, SECURITY, profile.PRIVATE_ADMISSION, profile.BASE,
            profile.KERNEL, profile.INITRAMFS, profile.TOOL, profile.IMAGE_TOOL, profile.PACK,
            public_r1.MANIFEST, public_r1.BOOT_RECEIPT)
APPROVAL = "ROOT_APPROVED_PRIVATE_NATIVE_R4_DIAGNOSTIC_ONLY"
TERMINAL_HANDSHAKE = b"exec /bin/sh -c 'while IFS= read -r l; do eval \"$l\"; done'\n"
READY_COMMAND = b"printf 'PRIVATE_NATIVE_R4_READY\\n'\n"
READY_MARKER = b"PRIVATE_NATIVE_R4_READY\n"
Pin = frozen.Pin


@dataclass(frozen=True)
class Admission:
    root: str
    profile_sha256: str
    pins: tuple
    approval: str
    owner_sid: str
    output_file_id: tuple
    output_acl_sha256: str
    capsule_file_id: tuple
    capsule_acl_sha256: str


def _safe(root, name, exists=True):
    if (type(name) is not str or not name or "\\" in name or "\0" in name or ":" in name
            or ".." in PurePosixPath(name).parts):
        raise profile.Stop("PATH")
    path = profile._root(root).joinpath(*PurePosixPath(name).parts)
    if exists and not os.path.lexists(path):
        raise profile.Stop("PATH")
    return path


_digest = frozen._digest
_plain_file_info = frozen._plain_file_info
_identity = frozen._identity
_owned_process = frozen._owned_process


def _security_record(value):
    if (type(value) is not dict or set(value) != {"file_id", "acl_sha256"}
            or type(value["file_id"]) is not list or len(value["file_id"]) != 2
            or any(type(item) is not str or re.fullmatch(r"(?:0|[1-9][0-9]*)", item) is None for item in value["file_id"])
            or type(value["acl_sha256"]) is not str
            or re.fullmatch(r"[0-9a-f]{64}", value["acl_sha256"]) is None):
        raise profile.Stop("PRIVATE_SECURITY")
    return tuple(value["file_id"]), value["acl_sha256"]


def _verify_security(root, admission, *, require_empty):
    output = profile.output_directory(root)
    directory_id, directory_acl = _security_record(security.verify_private_directory(output, admission.owner_sid))
    if directory_id != admission.output_file_id or directory_acl != admission.output_acl_sha256:
        raise profile.Stop("PRIVATE_OUTPUT_SECURITY")
    capsule_id, capsule_acl = _security_record(security.verify_private_file(_safe(root, profile.CAPSULE), admission.owner_sid))
    if capsule_id != admission.capsule_file_id or capsule_acl != admission.capsule_acl_sha256:
        raise profile.Stop("PRIVATE_CAPSULE_SECURITY")
    if require_empty and os.listdir(output):
        raise profile.Stop("PRIVATE_OUTPUT_NOT_EMPTY")
    return output


def _admit(root, admission):
    root = profile._root(root)
    if (type(admission) is not Admission or admission.root != str(root)
            or admission.approval != APPROVAL or admission.profile_sha256 != PROFILE_SHA256
            or type(admission.pins) is not tuple or type(admission.owner_sid) is not str):
        raise profile.Stop("NOT_ADMITTED")
    if security.current_sid() != admission.owner_sid:
        raise profile.Stop("PRIVATE_OWNER_SID")
    pins = {}
    for pin in admission.pins:
        if (type(pin) is not Pin or pin.name in pins or type(pin.size) is not int or pin.size < 0
                or type(pin.sha256) is not str or re.fullmatch(r"[0-9a-f]{64}", pin.sha256) is None):
            raise profile.Stop("ADMISSION_PIN_SCHEMA")
        _safe(root, pin.name)
        pins[pin.name] = pin
    if not set(REQUIRED).issubset(pins):
        raise profile.Stop("ADMISSION_PINS_MISSING")
    for name, (size, digest) in public_input_pins().items():
        pin = pins.get(name)
        if pin is None or pin.sha256 != digest or (size is not None and pin.size != size):
            raise profile.Stop("PROFILE_INPUT_PIN")
    for name in (EXECUTOR, PROFILE_MODULE, PUBLIC_PROFILE, FROZEN_HELPER, FROZEN_PROBE, FROZEN_GUARD, CONTRACT, SECURITY):
        if pins[name].sha256 != _digest(_safe(root, name))[1]:
            raise profile.Stop("CODE_BINDING")
    if Path(__file__).absolute() != _safe(root, EXECUTOR):
        raise profile.Stop("MODULE_LOCATION")
    output = _verify_security(root, admission, require_empty=True)
    return root, pins, output


def public_input_pins():
    """Public source/image pins only; the sealed capsule is guest-hashed, never host-read."""
    return {name: value for name, value in public_r1_inputs().items() if name != public_admission_name()}


def public_r1_inputs():
    return dict(public_r1.INPUT_PINS)


def public_admission_name():
    return public_r1.ADMISSION_SOURCE


def _verify(root, pins, previous=None):
    found = {}
    for name, pin in pins.items():
        identity, digest = _digest(_safe(root, name))
        if identity[2] != pin.size or digest != pin.sha256 or (pin.mtime_ns is not None and identity[3] != pin.mtime_ns):
            raise profile.Stop("INPUT_PIN")
        if previous is not None and previous.get(name) != identity:
            raise profile.Stop("INPUT_IDENTITY")
        found[name] = identity
    return found


def _exclusive_output(output, name):
    if type(name) is not str or name not in profile.OUTPUT_NAMES:
        raise profile.Stop("OUTPUT_PATH")
    path = Path(output) / name
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0)
    return os.fdopen(os.open(path, flags, 0o600), "r+b", buffering=0)


def _write_result(output, payload):
    try:
        with _exclusive_output(output, profile.RESULT) as out:
            data = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("ascii")
            if out.write(data) != len(data):
                raise profile.Stop("RESULT_WRITE")
            out.flush()
            os.fsync(out.fileno())
    except FileExistsError:
        raise profile.Stop("RESULT_ALREADY_EXISTS") from None
    return True


def _create_overlay(root, output):
    with _exclusive_output(output, profile.OVERLAY) as out:
        before = _identity(os.fstat(out.fileno()))
        if before[2] != 0:
            raise profile.Stop("OVERLAY_RESERVATION")
        out.flush()
        os.fsync(out.fileno())
    _owned_process(profile.overlay_create_argv(root, output), 120, profile.BOOT_SERIAL_LIMIT)
    after = _identity(_plain_file_info(Path(output) / profile.OVERLAY))
    if after[:2] != before[:2] or after[2] <= 0:
        raise profile.Stop("OVERLAY_RESERVATION")
    return after


def _image_check(root, path, identity=None):
    before = _identity(_plain_file_info(path))
    if identity is not None and before[:2] != identity[:2]:
        raise profile.Stop("IMAGE_CHECK_IDENTITY")
    raw = _owned_process([str(profile._root(root) / profile.IMAGE_TOOL), "check", "--output=json", str(path)], 120, profile.BOOT_SERIAL_LIMIT)
    if _identity(_plain_file_info(path)) != before:
        raise profile.Stop("IMAGE_CHECK_IDENTITY")
    try:
        report = json.loads(raw.decode("ascii"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise profile.Stop("IMAGE_CHECK_JSON")
    if type(report) is not dict or report.get("check-errors") != 0 or report.get("corruptions", 0) != 0:
        raise profile.Stop("IMAGE_CHECK")


def _bounded_phase_append(phase, part):
    """Check before retaining or protected-log writing any binder-phase byte."""
    if type(phase) is not bytearray or type(part) is not bytes or len(phase) + len(part) > PROFILE["phase_bytes"]:
        raise profile.Stop("PHASE_OVERFLOW")
    phase.extend(part)


def _run(root, output, log, admission_source):
    """Bound private phase before every protected log write; no follow-up writes occur."""
    argv = profile.qemu_argv(root, output)
    profile.validate_argv(argv, root, output)
    env = {key: os.environ[key] for key in ("SystemRoot", "WINDIR") if key in os.environ}
    child = subprocess.Popen(argv, cwd=root, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, bufsize=0, shell=False, close_fds=True)
    owner = (child.pid, tuple(child.args))
    serial, phase = bytearray(), bytearray()
    deadline = time.monotonic() + PROFILE["seconds"]
    eof = False
    last = None
    phase_line_start = None
    phase_active = False
    framed_transport = False

    def pump():
        nonlocal eof, phase_active
        if (child.pid, tuple(child.args)) != owner:
            raise profile.Stop("PROCESS_IDENTITY")
        if time.monotonic() >= deadline:
            raise profile.Stop("TIMEOUT")
        try:
            block = os.read(child.stdout.fileno(), 4096)
        except BlockingIOError:
            block = None
        if block == b"":
            eof = True
            return
        if not block:
            return
        if (any(value in (0x11, 0x13) for value in block)
                or framed_transport and any(value not in (10, 13) and not 32 <= value <= 126 for value in block)):
            raise profile.Stop("SERIAL_CONTROL")
        if len(serial) + len(block) > PROFILE["log_bytes"]:
            raise profile.Stop("LOG_OVERFLOW")
        phase_part = b""
        if phase_active:
            phase_part = block
        elif phase_line_start is not None:
            pending = bytes(serial[phase_line_start:]) + block
            if b"\n" in pending:
                phase_part = pending.split(b"\n", 1)[1]
                phase_active = True
        if phase_part:
            _bounded_phase_append(phase, phase_part)
        serial.extend(block)
        if log.write(block) != len(block):
            raise profile.Stop("LOG_WRITE")
        log.flush()

    def wait(predicate, terminal=False):
        while not predicate():
            pump()
            if not terminal and (eof or child.poll() is not None):
                raise profile.Stop("PROCESS_EARLY_EXIT")
            time.sleep(.02)

    def send(command, barrier=None):
        nonlocal last
        for offset in range(0, len(command), PROFILE["write_bytes"]):
            while last is not None and time.monotonic() - last < PROFILE["write_interval"]:
                pump()
                time.sleep(.02)
            pump()
            if offset == 0 and barrier is not None and barrier() is not True:
                raise profile.Stop("FRAME_BARRIER")
            if child.poll() is not None:
                raise profile.Stop("PROCESS_EARLY_EXIT")
            part = command[offset:offset + PROFILE["write_bytes"]]
            if child.stdin.write(part) != len(part):
                raise profile.Stop("SERIAL_WRITE")
            child.stdin.flush()
            last = time.monotonic()

    def echo(command, start):
        wait(lambda: b"\n" in bytes(serial[start:]).replace(b"\r", b""))
        actual = bytes(serial[start:]).replace(b"\r", b"").split(b"\n", 1)[0] + b"\n"
        if actual != command:
            raise profile.Stop("SERIAL_ECHO")

    try:
        os.set_blocking(child.stdout.fileno(), False)
        wait(lambda: bytes(serial).endswith(b"login: "))
        start = len(serial); send(b"root\n"); echo(b"root\n", start)
        wait(lambda: re.search(rb"(?:^|\n)[^\r\n\x1b]*[~/:]# (?:\x1b\[6n)?$", bytes(serial)) is not None)
        start = len(serial); send(TERMINAL_HANDSHAKE); echo(TERMINAL_HANDSHAKE, start)
        start = len(serial); send(READY_COMMAND); echo(READY_COMMAND, start)
        wait(lambda: bytes(serial).replace(b"\r", b"").endswith(READY_MARKER))
        framed_transport = True
        commands = profile.framed_commands(admission_source)
        for command in commands[:-1]:
            raw = command.encode("ascii") + b"\n"
            start = len(serial); send(raw, barrier=lambda: len(serial) == start); echo(raw, start)
            quiet_until = time.monotonic() + PROFILE["write_interval"]
            while time.monotonic() < quiet_until:
                pump()
                time.sleep(.02)
            if bytes(serial[start:]).replace(b"\r", b"").count(b"\n") != 1:
                raise profile.Stop("FRAME_SUFFIX")
        raw = commands[-1].encode("ascii") + b"\n"
        start = len(serial)
        phase_line_start = start
        send(raw, barrier=lambda: len(serial) == start)
        echo(raw, start)
        wait(lambda: child.poll() is not None and eof, terminal=True)
        if child.wait(timeout=PROFILE["cleanup_seconds"]) != 0:
            raise profile.Stop("QEMU_EXIT")
        return profile.parse_phase(bytes(phase))
    finally:
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=PROFILE["cleanup_seconds"])
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=PROFILE["cleanup_seconds"])
        child.stdin.close()
        child.stdout.close()
        if child.poll() is None:
            raise profile.Stop("PROCESS_NOT_CLOSED")


def execute(root, admission=None):
    root, pins, output = _admit(root, admission)
    pre = _verify(root, pins)
    phase = None
    overlay = None
    try:
        source = _safe(root, profile.PRIVATE_ADMISSION).read_bytes()
        if hashlib.sha256(source).hexdigest() != pins[profile.PRIVATE_ADMISSION].sha256:
            raise profile.Stop("PRIVATE_SOURCE_PIN")
        overlay = _create_overlay(root, output)
        with _exclusive_output(output, profile.SERIAL_LOG) as log:
            phase = _run(root, output, log, source)
            log.flush()
            os.fsync(log.fileno())
        _image_check(root, _safe(root, profile.BASE))
        _image_check(root, Path(output) / profile.OVERLAY, overlay)
        post = _verify(root, pins, pre)
        _verify_security(root, admission, require_empty=False)
        state = phase["state"]
        result = {"format": "PRIVATE_NATIVE_INSTALLED_R4_R1_RESULT", "status": state + "_DIAGNOSTIC",
                  "restore_acceptance": False, "release_acceptance": False,
                  "post_pins_verified": bool(post), "binding": phase}
        _write_result(output, result)
        return result
    except BaseException:
        # Do not disclose exception strings, guest bytes, or private path/detail.
        post_ok = False
        base_image_ok = False
        overlay_image_ok = False
        security_ok = False
        try:
            _verify(root, pins, pre)
            post_ok = True
        except BaseException:
            pass
        try:
            _image_check(root, _safe(root, profile.BASE))
            base_image_ok = True
        except BaseException:
            pass
        if overlay is not None:
            try:
                _image_check(root, Path(output) / profile.OVERLAY, overlay)
                overlay_image_ok = True
            except BaseException:
                pass
        try:
            _verify_security(root, admission, require_empty=False)
            security_ok = True
        except BaseException:
            pass
        failure = {"format": "PRIVATE_NATIVE_INSTALLED_R4_R1_RESULT", "status": "FIXED_FAILURE",
                   "restore_acceptance": False, "release_acceptance": False,
                   "post_pins_verified": post_ok, "base_image_checked": base_image_ok,
                   "overlay_image_checked": overlay_image_ok, "private_security_checked": security_ok}
        _write_result(output, failure)
        try:
            _verify_security(root, admission, require_empty=False)
        except BaseException:
            pass
        raise profile.Stop("PRIVATE_R4_FIXED_FAILURE") from None


if __name__ == "__main__":
    raise SystemExit("NOT_ADMITTED: executor import only")
