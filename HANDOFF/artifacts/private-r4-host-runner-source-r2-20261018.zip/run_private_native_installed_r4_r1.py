"""Exact-plan caller for the private R4 diagnostic.  It never creates a plan."""
PLAN = "PRIVATE-NATIVE-INSTALLED-R4-R1-OPERATION.json"
CALLER = "run_private_native_installed_r4_r1.py"
PROFILE = "private_native_installed_r4_profile_r1.py"
PUBLIC_PROFILE = "public_native_installed_r4_profile_r1.py"
EXECUTOR = "private_native_installed_r4_executor_r1.py"
HELPER = "public_installed_boot_probe_executor_r2.py"
PROBE = "public_installed_boot_probe_r1.py"
GUARD = "public_installed_boot_image_guard_r1.py"
CONTRACT = "private_native_r4_contract_r1.py"
SECURITY = "private_native_host_security_r1.py"
PRIVATE_ADMISSION = "private_linux_admission_r4.py"
ACTUAL = "qemu-test-tools"


def _interpreter():
    import sys
    if not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode):
        raise RuntimeError("INTERPRETER")


def _plain(root, name):
    import os
    import stat
    if type(name) is not str or not name or any(char in name for char in "/\\:\0") or name in (".", ".."):
        raise RuntimeError("PATH")
    path = root / name
    info = os.lstat(path)
    if getattr(info, "st_file_attributes", 0) & 0x400 or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise RuntimeError("FILE_IDENTITY")
    return path


def _read(root, name, digest, maximum=32 * 1024 * 1024):
    """Stream every digest; source bytes are retained only after a bounded read."""
    import hashlib
    import os
    import re
    if type(digest) is not str or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise RuntimeError("HASH")
    path = _plain(root, name)
    before = os.stat(path)
    identity = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
    if before.st_size < 0 or before.st_size > maximum:
        raise RuntimeError("SIZE")
    chunks, actual = [], hashlib.sha256()
    with open(path, "rb") as source:
        if (lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns))(os.fstat(source.fileno())) != identity:
            raise RuntimeError("IDENTITY")
        while True:
            block = source.read(1024 * 1024)
            if not block:
                break
            actual.update(block)
            chunks.append(block)
        if (lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns))(os.fstat(source.fileno())) != identity:
            raise RuntimeError("IDENTITY")
    if (lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns))(os.stat(path)) != identity or actual.hexdigest() != digest:
        raise RuntimeError("IDENTITY")
    return b"".join(chunks)


def public_files(root, exclusions):
    import os
    import stat
    from pathlib import Path
    if type(exclusions) is not tuple or any(type(name) is not str for name in exclusions):
        raise RuntimeError("EXCLUSION_SCHEMA")
    base = root / ACTUAL
    info = os.lstat(base)
    if getattr(info, "st_file_attributes", 0) & 0x400 or not stat.S_ISDIR(info.st_mode):
        raise RuntimeError("TOOL_ROOT")
    found = []
    for directory, dirs, files in os.walk(base, followlinks=False):
        for name in dirs:
            info = os.lstat(Path(directory) / name)
            if getattr(info, "st_file_attributes", 0) & 0x400 or not stat.S_ISDIR(info.st_mode):
                raise RuntimeError("TOOL_DIRECTORY")
        for name in files:
            path = Path(directory) / name
            info = os.lstat(path)
            if getattr(info, "st_file_attributes", 0) & 0x400 or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise RuntimeError("TOOL_FILE")
            relative = path.relative_to(root).as_posix()
            if relative not in exclusions:
                found.append(relative)
    return tuple(sorted(found))


def compare_tool_inventory(root, pins, exclusions, executor):
    if set(public_files(root, exclusions)) != set(pins) - set(exclusions):
        raise RuntimeError("TOOL_INVENTORY_DRIFT")
    for name, pin in pins.items():
        identity, actual = executor._digest(root.joinpath(*__import__("pathlib").PurePosixPath(name).parts))
        if identity[2] != pin.size or identity[3] != pin.mtime_ns or actual != pin.sha256:
            raise RuntimeError("EXCLUDED_ROM_DRIFT" if name in exclusions else "TOOL_PIN_DRIFT")


def validate_tool_closure(root, plan, executor):
    import json
    name = plan.get("tool_closure_receipt")
    digest = plan.get("tool_closure_receipt_sha256")
    if type(name) is not str or name not in plan["files"] or plan["files"][name] != digest:
        raise RuntimeError("TOOL_CLOSURE_BINDING")
    closure = json.loads(_read(root, name, digest).decode("ascii"))
    rows = closure.get("pins") if type(closure) is dict else None
    exclusions = tuple(closure.get("not_profile_dependencies", ())) if type(closure) is dict else ()
    expected_exclusions = {"qemu-test-tools/share/QEMU,cgthree.bin", "qemu-test-tools/share/QEMU,tcx.bin"}
    if (type(rows) is not list or len(rows) != 3385 or set(exclusions) != expected_exclusions):
        raise RuntimeError("TOOL_CLOSURE_SCHEMA")
    pins = {}
    for row in rows:
        if (type(row) is not dict or set(row) != {"name", "size", "sha256", "mtime_ns"}
                or row.get("name") in pins or type(row.get("name")) is not str
                or type(row.get("size")) is not int or row["size"] < 0
                or type(row.get("mtime_ns")) is not int or row["mtime_ns"] <= 0):
            raise RuntimeError("TOOL_PIN_SCHEMA")
        pin = executor.Pin(row["name"], row["size"], row["sha256"], row["mtime_ns"])
        pins[pin.name] = pin
    compare_tool_inventory(root, pins, exclusions, executor)
    return pins, exclusions


def _load(root, sources):
    import sys
    import types
    order = (PUBLIC_PROFILE[:-3], PROBE[:-3], GUARD[:-3], HELPER[:-3], CONTRACT[:-3], SECURITY[:-3], PROFILE[:-3], EXECUTOR[:-3])
    if any(name in sys.modules for name in order):
        raise RuntimeError("LOCAL_MODULE_PRELOADED")
    loaded = []
    try:
        for name in order:
            module = types.ModuleType(name)
            module.__file__ = str(root / (name + ".py"))
            module.__package__ = ""
            sys.modules[name] = module
            loaded.append(module)
            exec(compile(sources[name + ".py"], module.__file__, "exec", dont_inherit=True), module.__dict__)
        return tuple(loaded)
    except BaseException:
        for module in loaded:
            if sys.modules.get(module.__name__) is module:
                del sys.modules[module.__name__]
        raise


def _tokens(plan):
    import re
    values = (plan.get("output_file_id"), plan.get("capsule_file_id"))
    if any(type(value) is not list or len(value) != 2 or any(type(part) is not str or re.fullmatch(r"(?:0|[1-9][0-9]*)", part) is None for part in value) for value in values):
        raise RuntimeError("SECURITY_TOKEN")
    for name in ("output_acl_sha256", "capsule_acl_sha256"):
        if type(plan.get(name)) is not str or re.fullmatch(r"[0-9a-f]{64}", plan[name]) is None:
            raise RuntimeError("SECURITY_TOKEN")
    return tuple(values[0]), plan["output_acl_sha256"], tuple(values[1]), plan["capsule_acl_sha256"]


def _fixed(status):
    import json
    print(json.dumps({"format": "PRIVATE_NATIVE_INSTALLED_R4_R1_HOST", "status": status}, sort_keys=True))


def main():
    import json
    import pathlib
    import sys
    _interpreter()
    if len(sys.argv) != 2:
        raise RuntimeError("PLAN_SHA")
    root = pathlib.Path.cwd().absolute()
    plan = json.loads(_read(root, PLAN, sys.argv[1]).decode("ascii"))
    fixed = {CALLER, PROFILE, PUBLIC_PROFILE, EXECUTOR, HELPER, PROBE, GUARD, CONTRACT, SECURITY, PRIVATE_ADMISSION}
    if (type(plan) is not dict or plan.get("operation_admission") != "OPERATION_ADMITTED_PRIVATE_R4_DIAGNOSTIC_ONLY"
            or plan.get("independent_operation_review") != "SHIP" or plan.get("private_diagnostic_only") is not True
            or plan.get("restore_acceptance") is not False or plan.get("release_acceptance") is not False
            or plan.get("one_attempt_only") is not True or plan.get("root") != str(root)
            or plan.get("output_directory") != "native-admission-private-r4-installed-r1"
            or type(plan.get("files")) is not dict or not fixed.issubset(plan["files"])):
        raise RuntimeError("NOT_ADMITTED")
    _read(root, CALLER, plan["files"][CALLER])
    sources = {name: _read(root, name, digest) for name, digest in plan["files"].items() if name in fixed}
    if pathlib.Path(__file__).absolute() != _plain(root, CALLER):
        raise RuntimeError("CALLER_LOCATION")
    loaded = _load(root, sources)
    try:
        _, _, _, helper, contract, security, profile, executor = loaded
        output_id, output_acl, capsule_id, capsule_acl = _tokens(plan)
        if (plan.get("mode") != profile.MODE or plan.get("profile_sha256") != executor.PROFILE_SHA256
                or plan.get("fresh_output_names") != list(profile.OUTPUT_NAMES)
                or plan.get("qemu_argv") != profile.qemu_argv(root, profile.output_directory(root))
                or plan.get("overlay_argv") != profile.overlay_create_argv(root, profile.output_directory(root))):
            raise RuntimeError("PROFILE_PIN")
        if security.verify_powershell(plan.get("powershell_sha256")) is not True:
            raise RuntimeError("SECURITY_BINARY_PIN")
        owner_sid = security.current_sid()
        if plan.get("owner_sid") != owner_sid:
            raise RuntimeError("OWNER_SID")
        actual_output = security.verify_private_directory(profile.output_directory(root), owner_sid)
        actual_capsule = security.verify_private_file(root / profile.CAPSULE, owner_sid)
        if (tuple(actual_output["file_id"]), actual_output["acl_sha256"], tuple(actual_capsule["file_id"]), actual_capsule["acl_sha256"]) != (output_id, output_acl, capsule_id, capsule_acl):
            raise RuntimeError("SECURITY_DRIFT")
        tool_pins, exclusions = validate_tool_closure(root, plan, executor)
        pins = list(tool_pins.values())
        for name in executor.REQUIRED:
            if name in tool_pins:
                continue
            identity, digest = executor._digest(_plain(root, name))
            expected = plan["files"].get(name)
            if expected is not None and digest != expected:
                raise RuntimeError("REQUIRED_PIN")
            pins.append(executor.Pin(name, identity[2], digest, identity[3]))
        admission = executor.Admission(str(root), plan["profile_sha256"], tuple(pins), executor.APPROVAL, owner_sid,
                                      output_id, output_acl, capsule_id, capsule_acl)
        try:
            result = executor.execute(root, admission)
        finally:
            compare_tool_inventory(root, tool_pins, exclusions, executor)
        if result.get("status") not in {"STOPPED_DIAGNOSTIC", "ADMISSION_BOUND_DIAGNOSTIC"}:
            raise RuntimeError("CLOSED_RESULT")
        _fixed(result["status"])
        return 0
    finally:
        for module in loaded:
            sys.modules.pop(module.__name__, None)


if __name__ == "__main__":
    try:
        exit_code = main()
    except BaseException:
        _fixed("FIXED_FAILURE")
        exit_code = 1
    raise SystemExit(exit_code)
