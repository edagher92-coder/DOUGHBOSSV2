import contextlib
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import private_native_installed_r4_profile_r1 as profile
import private_native_installed_r4_executor_r1 as executor
import run_private_native_installed_r4_r1 as runner


def stopped():
    return {"format": "NATIVE_ADMISSION_BINDING_R4", "state": "STOPPED", "category": "PREFIX_BINDING",
            "stage": "NATIVE_PREFLIGHT", "reason": "G056", "structure_context": "INSERT_VALUE",
            "token_kind": "WORD", "preparation_executed": False, "database_started": False,
            "application_boot_allowed": False, "restore_acceptance": False, "release_acceptance": False}


class ProfileTests(unittest.TestCase):
    def test_three_disk_wire_budget_and_no_network(self):
        commands = profile.framed_commands((ROOT / "private_linux_admission_r4.py").read_bytes())
        self.assertTrue(all(len(command.encode("ascii")) <= 768 for command in commands))
        self.assertLessEqual(sum(len(command.encode("ascii")) + 1 for command in commands), 7000)
        argv = profile.qemu_argv(ROOT, profile.output_directory(ROOT))
        self.assertEqual(sum(item == "-drive" for item in argv), 3)
        self.assertIn("-nic", argv); self.assertEqual(argv[argv.index("-nic") + 1], "none")
        self.assertNotIn("-netdev", argv); self.assertNotIn("-qmp", argv)

    def test_stopped_closed_phase_and_unknown_output_stay_private(self):
        guest = {"format": "NATIVE_ADMISSION_PRIVATE_GUEST_R4", "state": "PUBLIC_AND_READONLY_CAPSULE_ADMITTED",
                 "regular_public_files": 25, "public_source_files": 24, "capsule_hash_readonly_match": True,
                 "binding_executed": False}
        raw = b"\n".join((json.dumps(guest, sort_keys=True).encode(), json.dumps(stopped(), sort_keys=True).encode(), b"PRIVATE_R4_POST_STOPPED_OK"))
        self.assertEqual(profile.parse_phase(raw)["reason"], "G056")
        self.assertEqual(profile.parse_phase(raw + b"\n[ 12.345] reboot: Power down")["reason"], "G056")
        for tail in (b"unknown", b"[ 12.345] reboot: Power down extra", b"[ 12.345] reboot: Power down\nunknown"):
            with self.assertRaises(profile.Stop): profile.parse_phase(raw + b"\n" + tail)
        with self.assertRaises(profile.Stop):
            profile.parse_phase(raw + b"\nprivate bytes must not be relayed")

    def test_admission_bound_requires_matching_closed_post_receipt(self):
        guest = {"format": "NATIVE_ADMISSION_PRIVATE_GUEST_R4", "state": "PUBLIC_AND_READONLY_CAPSULE_ADMITTED",
                 "regular_public_files": 25, "public_source_files": 24, "capsule_hash_readonly_match": True,
                 "binding_executed": False}
        bound = {"format": "NATIVE_ADMISSION_BINDING_R4", "state": "ADMISSION_BOUND", "preparation_executed": False,
                 "database_started": False, "application_boot_allowed": False, "restore_acceptance": False, "release_acceptance": False,
                 "admission_sha256": "a" * 64, "compressed_sha256": "cbb3efe50fc888856d67c8718a640cc405d4447a482efed16dde94b287ae83a7",
                 "decompressed_sha256": "5610af62175bb9eab0d5f3c24813aa29e1641f12f89d9b3110a1c1fc574d7b19",
                 "normalized_sha256": "b" * 64, "compressed_bytes": 445129, "decompressed_bytes": 1974648,
                 "normalized_bytes": 1, "create_count": 58, "insert_target_count": 30}
        post = {"format": "PRIVATE_R4_POST_BOUND", "admission_sha256": bound["admission_sha256"], "compressed_sha256": bound["compressed_sha256"]}
        raw = b"\n".join((json.dumps(guest, sort_keys=True).encode(), json.dumps(bound, sort_keys=True).encode(), json.dumps(post, sort_keys=True).encode(), b"PRIVATE_R4_POST_BOUND_OK"))
        self.assertEqual(profile.parse_phase(raw)["state"], "ADMISSION_BOUND")
        self.assertEqual(profile.parse_phase(raw + b"\n[ 12.345] reboot: Power down")["state"], "ADMISSION_BOUND")
        with self.assertRaises(profile.Stop): profile.parse_phase(raw + b"\n[ 12.345] reboot: Power down extra")

    def test_phase_boundary_is_checked_before_log_storage(self):
        phase = bytearray(b"x" * (profile.RAW_PHASE_LIMIT - 1))
        with self.assertRaises(profile.Stop):
            executor._bounded_phase_append(phase, b"yz")
        self.assertEqual(len(phase), profile.RAW_PHASE_LIMIT - 1)


class CleanupTests(unittest.TestCase):
    def test_early_eof_terminates_owned_child(self):
        read_fd, write_fd = os.pipe(); os.close(write_fd)
        class Child:
            pid = 71; args = ["qemu"]
            def __init__(self): self.stdout = os.fdopen(read_fd, "rb", buffering=0); self.stdin = io.BytesIO(); self.code = None; self.terminated = False
            def poll(self): return self.code
            def terminate(self): self.terminated = True; self.code = -15
            def kill(self): self.code = -9
            def wait(self, timeout=None): return self.code
        child = Child()
        with mock.patch.object(executor.subprocess, "Popen", return_value=child):
            with self.assertRaises(profile.Stop):
                executor._run(ROOT, profile.output_directory(ROOT), io.BytesIO(), b"x")
        self.assertTrue(child.terminated)


class CallerTests(unittest.TestCase):
    def test_actual_caller_to_executor_path_forbids_popen(self):
        fixed = {runner.CALLER, runner.PROFILE, runner.PUBLIC_PROFILE, runner.EXECUTOR, runner.HELPER,
                 runner.PROBE, runner.GUARD, runner.CONTRACT, runner.SECURITY, runner.PRIVATE_ADMISSION}
        plan = {"operation_admission": "OPERATION_ADMITTED_PRIVATE_R4_DIAGNOSTIC_ONLY", "independent_operation_review": "SHIP",
                "private_diagnostic_only": True, "restore_acceptance": False, "release_acceptance": False,
                "one_attempt_only": True, "root": str(ROOT), "output_directory": profile.OUTPUT_DIR,
                "files": {name: "0" * 64 for name in fixed}, "tool_closure_receipt": "tool.json",
                "tool_closure_receipt_sha256": "0" * 64, "mode": profile.MODE,
                "profile_sha256": "profile", "fresh_output_names": list(profile.OUTPUT_NAMES),
                "qemu_argv": profile.qemu_argv(ROOT, profile.output_directory(ROOT)),
                "overlay_argv": profile.overlay_create_argv(ROOT, profile.output_directory(ROOT)), "owner_sid": "S-1-5-21-1-2-3-4",
                "powershell_sha256": "3" * 64,
                "output_file_id": ["1", "2"], "output_acl_sha256": "1" * 64,
                "capsule_file_id": ["3", "4"], "capsule_acl_sha256": "2" * 64}
        class Security:
            POWERSHELL = "C:/synthetic/powershell.exe"
            @staticmethod
            def verify_powershell(value): return value == "3" * 64
            @staticmethod
            def current_sid(): return plan["owner_sid"]
            @staticmethod
            def verify_private_directory(*args): return {"file_id": ["1", "2"], "acl_sha256": "1" * 64}
            @staticmethod
            def verify_private_file(*args): return {"file_id": ["3", "4"], "acl_sha256": "2" * 64}
        class Execution:
            REQUIRED = ()
            APPROVAL = "approval"
            PROFILE_SHA256 = "profile"
            Pin = executor.Pin
            Admission = executor.Admission
            def __init__(self): self.called = False
            def execute(self, root, admission): self.called = True; return {"status": "STOPPED_DIAGNOSTIC"}
        execution = Execution()
        loaded = tuple(types.SimpleNamespace(__name__="test_loaded_" + str(index)) for index in range(5)) + (Security, profile, execution)
        Security.__name__ = "test_security"
        execution.__name__ = "test_executor"
        old_argv, old_cwd = sys.argv[:], Path.cwd()
        sys.argv = [runner.__file__, "0" * 64]; os.chdir(ROOT)
        try:
            with mock.patch.object(runner, "_interpreter"), mock.patch.object(runner, "_read", return_value=json.dumps(plan).encode()), \
                 mock.patch.object(runner, "_load", return_value=loaded), mock.patch.object(runner, "validate_tool_closure", return_value=({}, ())), \
                 mock.patch.object(runner, "compare_tool_inventory"), mock.patch.object(subprocess, "Popen", side_effect=AssertionError("forbidden")), \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(runner.main(), 0)
        finally:
            os.chdir(old_cwd); sys.argv = old_argv
        self.assertTrue(execution.called)


class RegressionTests(unittest.TestCase):
    def test_actual_main_wrapper_preserves_zero_and_suppresses_failure_detail(self):
        wrapper = ast.parse(Path(runner.__file__).read_bytes()).body[-1]
        self.assertIsInstance(wrapper, ast.If)
        code = compile(ast.Module(body=[wrapper], type_ignores=[]), runner.__file__, "exec")
        for failure in (False, True):
            def main():
                if failure: raise RuntimeError("SYNTHETIC_PRIVATE_DETAIL")
                return 0
            output = io.StringIO()
            with contextlib.redirect_stdout(output), mock.patch.object(subprocess, "Popen", side_effect=AssertionError("forbidden")), self.assertRaises(SystemExit) as caught:
                exec(code, {"__name__": "__main__", "main": main, "_fixed": runner._fixed})
            self.assertEqual(caught.exception.code, 1 if failure else 0)
            if failure: self.assertEqual(json.loads(output.getvalue())["status"], "FIXED_FAILURE")
            else: self.assertEqual(output.getvalue(), "")
            self.assertNotIn("SYNTHETIC_PRIVATE_DETAIL", output.getvalue())

    def transport(self, mode):
        pending = [b"login: "]
        writes = []
        completed = []
        injected = []
        clock = [0.0]
        class Input(io.BytesIO):
            def write(self, part):
                writes.append(part)
                result = super().write(part)
                data = self.getvalue()
                if data.endswith(b"\n"):
                    command = data.splitlines(keepends=True)[-1]
                    completed.append(command)
                    pending.append(command)
                    if command == b"root\n": pending.append(b"~# ")
                    elif command == executor.READY_COMMAND: pending.append(executor.READY_MARKER)
                    elif command == b"final\n":
                        if mode == "overflow": pending.extend((b"a" * 4096, b"b"))
                        elif mode == "success": pending.append(b"CLOSED_SYNTHETIC_PHASE")
                return result
        class Output(io.BytesIO):
            def fileno(self): return 777
        class Child:
            pid = 82
            args = ["qemu"]
            def __init__(self): self.stdin = Input(); self.stdout = Output(); self.code = None; self.terminated = False
            def poll(self): return self.code
            def terminate(self): self.terminated = True; self.code = -15
            def kill(self): self.code = -9
            def wait(self, timeout=None): return self.code
        child = Child()
        def read(fd, size):
            if pending:
                value = pending.pop(0)
                if value == executor.READY_MARKER and mode in ("xoff", "suffix"):
                    injected.append("armed")
                return value
            if injected == ["armed"]:
                injected.append("sent")
                return b"\x13" if mode == "xoff" else b"unexpected"
            if mode == "success" and completed and completed[-1] == b"final\n":
                child.code = 0
                return b""
            raise BlockingIOError()
        def now(): clock[0] += .05; return clock[0]
        log = io.BytesIO()
        with mock.patch.object(executor.subprocess, "Popen", return_value=child), \
                mock.patch.object(executor.os, "read", side_effect=read), mock.patch.object(executor.os, "set_blocking"), \
                mock.patch.object(executor.time, "monotonic", side_effect=now), mock.patch.object(executor.time, "sleep"), \
                mock.patch.object(profile, "framed_commands", return_value=("x", "final")), \
                mock.patch.object(profile, "parse_phase", return_value={"state": "SYNTHETIC"}) as parser:
            if mode == "success":
                self.assertEqual(executor._run(ROOT, profile.output_directory(ROOT), log, b"public"), {"state": "SYNTHETIC"})
                parser.assert_called_once_with(b"CLOSED_SYNTHETIC_PHASE")
            else:
                with self.assertRaises(profile.Stop) as caught: executor._run(ROOT, profile.output_directory(ROOT), log, b"public")
                self.assertEqual(str(caught.exception), {"xoff": "SERIAL_CONTROL", "suffix": "FRAME_BARRIER", "overflow": "PHASE_OVERFLOW"}[mode])
                parser.assert_not_called()
                self.assertTrue(child.terminated)
        self.assertTrue(child.stdin.closed and child.stdout.closed)
        return completed, log.getvalue()

    def test_actual_transport_positive_control(self):
        commands, log = self.transport("success")
        self.assertEqual(commands[-2:], [b"x\n", b"final\n"])
        self.assertIn(b"CLOSED_SYNTHETIC_PHASE", log)

    def test_actual_transport_late_xoff_stops_before_next_write(self):
        commands, log = self.transport("xoff")
        self.assertEqual(commands[-1], executor.READY_COMMAND)
        self.assertNotIn(b"\x13", log)

    def test_actual_transport_late_suffix_stops_before_next_write(self):
        commands, log = self.transport("suffix")
        self.assertEqual(commands[-1], executor.READY_COMMAND)

    def test_actual_transport_phase_overflow_rejects_before_storage(self):
        commands, log = self.transport("overflow")
        self.assertEqual(commands[-1], b"final\n")
        self.assertTrue(log.endswith(b"a" * 4096))
        self.assertFalse(log.endswith(b"b"))

    def test_result_commit_has_no_fallible_security_work_after_it(self):
        with tempfile.TemporaryDirectory() as raw:
            output = Path(raw)
            source = output / "public-source.py"
            source.write_bytes(b"public synthetic source")
            pin = types.SimpleNamespace(sha256=hashlib.sha256(source.read_bytes()).hexdigest())
            pins = {profile.PRIVATE_ADMISSION: pin}
            events = []
            original_write = executor._write_result
            def security(*args, **kwargs):
                events.append("security")
                if (output / profile.RESULT).exists(): raise RuntimeError("SYNTHETIC_PRIVATE_DETAIL")
            def commit(path, payload):
                result = original_write(path, payload)
                events.append("commit")
                return result
            with mock.patch.object(executor, "_admit", return_value=(ROOT, pins, output)), \
                    mock.patch.object(executor, "_verify", return_value={"synthetic": True}), \
                    mock.patch.object(executor, "_safe", side_effect=lambda root, name: source if name == profile.PRIVATE_ADMISSION else output / name), \
                    mock.patch.object(executor, "_create_overlay", return_value=(1, 2, 3, 4)), \
                    mock.patch.object(executor, "_run", return_value=stopped()), \
                    mock.patch.object(executor, "_image_check"), \
                    mock.patch.object(executor, "_verify_security", side_effect=security), \
                    mock.patch.object(executor, "_write_result", side_effect=commit), \
                    mock.patch.object(subprocess, "Popen", side_effect=AssertionError("forbidden")):
                result = executor.execute(ROOT, object())
            self.assertEqual(events, ["security", "commit"])
            self.assertEqual(result["status"], "STOPPED_DIAGNOSTIC")
            self.assertEqual(json.loads((output / profile.RESULT).read_bytes()), result)

    def test_final_precommit_security_failure_has_closed_failure_receipt(self):
        with tempfile.TemporaryDirectory() as raw:
            output = Path(raw)
            source = output / "public-source.py"
            source.write_bytes(b"public synthetic source")
            pins = {profile.PRIVATE_ADMISSION: types.SimpleNamespace(sha256=hashlib.sha256(source.read_bytes()).hexdigest())}
            security_observations = []
            def final_security(*args, **kwargs):
                security_observations.append((output / profile.RESULT).exists())
                raise RuntimeError("SYNTHETIC_PRIVATE_DETAIL")
            with mock.patch.object(executor, "_admit", return_value=(ROOT, pins, output)), \
                    mock.patch.object(executor, "_verify", return_value={"synthetic": True}), \
                    mock.patch.object(executor, "_safe", side_effect=lambda root, name: source if name == profile.PRIVATE_ADMISSION else output / name), \
                    mock.patch.object(executor, "_create_overlay", return_value=(1, 2, 3, 4)), \
                    mock.patch.object(executor, "_run", return_value=stopped()), \
                    mock.patch.object(executor, "_image_check"), \
                    mock.patch.object(executor, "_verify_security", side_effect=final_security), \
                    mock.patch.object(subprocess, "Popen", side_effect=AssertionError("forbidden")):
                with self.assertRaisesRegex(profile.Stop, "^PRIVATE_R4_FIXED_FAILURE$"): executor.execute(ROOT, object())
            result = (output / profile.RESULT).read_bytes()
            self.assertEqual(security_observations, [False, False, True])
            self.assertEqual(json.loads(result)["status"], "FIXED_FAILURE")
            self.assertNotIn(b"SYNTHETIC_PRIVATE_DETAIL", result)

    def test_existing_result_is_rejected_and_never_overwritten(self):
        with tempfile.TemporaryDirectory() as raw:
            output = Path(raw)
            original = b"SYNTHETIC_EXISTING_RECORD"
            (output / profile.RESULT).write_bytes(original)
            with self.assertRaises(profile.Stop): executor._write_result(output, {"status": "FIXED_FAILURE"})
            self.assertEqual((output / profile.RESULT).read_bytes(), original)

    def test_execute_retains_durable_closed_failure_and_post_checks(self):
        with tempfile.TemporaryDirectory() as raw:
            output = Path(raw)
            source = output / "public-source.py"
            source.write_bytes(b"public synthetic source")
            pin = types.SimpleNamespace(sha256=hashlib.sha256(source.read_bytes()).hexdigest())
            pins = {profile.PRIVATE_ADMISSION: pin}
            with mock.patch.object(executor, "_admit", return_value=(ROOT, pins, output)), \
                    mock.patch.object(executor, "_verify", return_value={"synthetic": True}) as verify, \
                    mock.patch.object(executor, "_safe", side_effect=lambda root, name: source if name == profile.PRIVATE_ADMISSION else output / name), \
                    mock.patch.object(executor, "_create_overlay", return_value=(1, 2, 3, 4)), \
                    mock.patch.object(executor, "_run", side_effect=RuntimeError("SYNTHETIC_PRIVATE_DETAIL")), \
                    mock.patch.object(executor, "_image_check") as image, \
                    mock.patch.object(executor, "_verify_security") as security, \
                    mock.patch.object(subprocess, "Popen", side_effect=AssertionError("forbidden")):
                with self.assertRaisesRegex(profile.Stop, "^PRIVATE_R4_FIXED_FAILURE$"):
                    executor.execute(ROOT, object())
            result = json.loads((output / profile.RESULT).read_bytes())
            self.assertEqual(result["status"], "FIXED_FAILURE")
            for key in ("post_pins_verified", "base_image_checked", "overlay_image_checked", "private_security_checked"):
                self.assertIs(result[key], True)
            self.assertEqual(verify.call_count, 2)
            self.assertEqual(image.call_count, 2)
            self.assertEqual(security.call_count, 2)
            self.assertNotIn("SYNTHETIC_PRIVATE_DETAIL", json.dumps(result))
            self.assertFalse(result["restore_acceptance"] or result["release_acceptance"])

if __name__ == "__main__":
    unittest.main()
