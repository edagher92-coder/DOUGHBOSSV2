"""Pure image-info checks for the pending public installed-boot executor.

No IO, process creation, operation admission, or restore acceptance.
Qwen supplied the initial validation draft; integration checks raw paths before
normalization and uses exact scalar types at the JSON boundary.
"""
import ntpath

VIRTUAL_SIZE = 6442450944


class Stop(ValueError):
    pass


def _path(value, relative_to=None):
    if type(value) is not str or not value or "\0" in value:
        raise Stop("IMAGE_CHAIN")
    if ".." in value.replace("/", "\\").split("\\"):
        raise Stop("IMAGE_CHAIN")
    drive, tail = ntpath.splitdrive(value)
    if drive:
        if (len(drive) != 2 or drive[0] not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
                or drive[1] != ":" or not tail.startswith(("/", "\\"))):
            raise Stop("IMAGE_CHAIN")
    else:
        if relative_to is None or tail.startswith(("/", "\\")):
            raise Stop("IMAGE_CHAIN")
        value = ntpath.join(ntpath.dirname(relative_to), value)
    if ":" in tail:
        raise Stop("IMAGE_CHAIN")
    return ntpath.normcase(ntpath.normpath(value))


def validate_backing_chain(data, overlay_path, base_path):
    """Accept the exact two-image qcow2 chain described by already-decoded JSON.

    Paths are compared lexically. The caller must separately bind and hash the
    files and reject reparse points, hardlinks and concurrent modifications.
    """
    overlay, base = _path(overlay_path), _path(base_path)
    if overlay == base or type(data) is not list or len(data) != 2:
        raise Stop("IMAGE_CHAIN")
    for entry, expected in zip(data, (overlay, base)):
        if type(entry) is not dict or _path(entry.get("filename")) != expected:
            raise Stop("IMAGE_CHAIN")
        if type(entry.get("format")) is not str or entry["format"] != "qcow2":
            raise Stop("IMAGE_CHAIN")
        if type(entry.get("virtual-size")) is not int or entry["virtual-size"] != VIRTUAL_SIZE:
            raise Stop("IMAGE_CHAIN")
        if "dirty-flag" in entry and entry["dirty-flag"] is not False:
            raise Stop("IMAGE_CHAIN")
        specific = entry.get("format-specific")
        if type(specific) is not dict or specific.get("type") != "qcow2":
            raise Stop("IMAGE_CHAIN")
        metadata = specific.get("data")
        if type(metadata) is not dict or metadata.get("corrupt") is not False:
            raise Stop("IMAGE_CHAIN")
        if "data-file" in metadata or "data-file-raw" in metadata:
            raise Stop("IMAGE_CHAIN")
    top, bottom = data
    if (type(top.get("backing-filename-format")) is not str
            or top["backing-filename-format"] != "qcow2"):
        raise Stop("IMAGE_CHAIN")
    if _path(top.get("backing-filename"), relative_to=overlay) != base:
        raise Stop("IMAGE_CHAIN")
    if _path(top.get("full-backing-filename")) != base:
        raise Stop("IMAGE_CHAIN")
    if any(key in bottom for key in
           ("backing-filename", "full-backing-filename", "backing-filename-format")):
        raise Stop("IMAGE_CHAIN")


if __name__ == "__main__":
    raise SystemExit("NOT_ADMITTED: pure image-info validation only")
