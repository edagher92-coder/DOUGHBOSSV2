[CmdletBinding(DefaultParameterSetName='Freeze')]
param(
    [Parameter(Mandatory=$true,ParameterSetName='Freeze')][switch]$PrepareFreeze,
    [Parameter(Mandatory=$true,ParameterSetName='Run')][switch]$ApprovedFrozenSource,
    [Parameter(Mandatory=$true,ParameterSetName='Run')][string]$FreezeManifestPath,
    [Parameter(Mandatory=$true,ParameterSetName='Run')][ValidatePattern('^[A-Fa-f0-9]{64}$')][string]$FreezeManifestSha256,
    [ValidatePattern('^[a-z0-9][a-z0-9-]{0,59}$')][string]$RunName='runtime-r18-loyalty-opt-in'
)
$ErrorActionPreference='Stop'
$root='C:\Codex\Temp\doughboss-local-first-runtime-20261017'
$repo='C:\Codex\Workspaces\doughboss-251-handoff-20261016'
$baseline='C:\Codex\Temp\doughboss-disposable-wp-20261012-73a8d40f'
$php='C:\Codex\Temp\doughboss-portable-php-20261012-c1d4232b\php82\php.exe'
$bin='C:\Codex\Temp\doughboss-restore-mariadb-20261012\extracted\mariadb-11.4.13-winx64\bin'
$expectedHead='9f37ccf77670b0175049e02c9896f28912f7488c'
$port=33119

function Assert-UnderRoot([string]$Path,[string]$Parent) {
    $full=[IO.Path]::GetFullPath($Path)
    $boundary=[IO.Path]::GetFullPath($Parent).TrimEnd('\')+'\'
    if (-not $full.StartsWith($boundary,[StringComparison]::OrdinalIgnoreCase)) { throw 'Path escaped approved boundary.' }
    return $full
}
function Get-FrozenFiles {
    $paths=@('doughboss.php','uninstall.php','readme.txt','THIRD_PARTY_NOTICES.md','scripts\test-wordpress-integration.ps1')
    foreach ($directory in @('includes','admin','public','languages','themes','tests\integration','tests\fixtures')) {
        $source=Join-Path $repo $directory
        if (Test-Path -LiteralPath $source -PathType Container) {
            $items=@(Get-ChildItem -LiteralPath $source -Recurse -Force)
            if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Frozen source includes a reparse point.' }
            $paths+=@($items | Where-Object { -not $_.PSIsContainer } | ForEach-Object { $_.FullName.Substring($repo.Length+1) })
        }
    }
    foreach ($relative in ($paths | Sort-Object -Unique)) {
        $file=Assert-UnderRoot (Join-Path $repo $relative) $repo
        if ((Get-Item -LiteralPath $file).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Frozen source file is a reparse point.' }
        [pscustomobject]@{Path=$relative;Sha256=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash;Runtime=($relative -notlike 'tests\*' -and $relative -notlike 'scripts\*' -and $relative -notlike 'themes\*')}
    }
}
function Assert-Freeze($Freeze) {
    if ($Freeze.Repository -ne $repo -or $Freeze.Head -ne $expectedHead -or $Freeze.Branch -ne 'codex/2.51-handoff-20261016') { throw 'Freeze repository identity mismatch.' }
    if ((git -C $repo rev-parse HEAD) -ne $expectedHead -or (git -C $repo branch --show-current) -ne 'codex/2.51-handoff-20261016') { throw 'Current source identity changed.' }
    $actual=@(Get-FrozenFiles)
    $expected=@($Freeze.Files)
    if ($actual.Count -ne $expected.Count) { throw 'Frozen file count changed.' }
    for ($index=0;$index -lt $actual.Count;$index++) {
        if ($actual[$index].Path -cne $expected[$index].Path -or $actual[$index].Sha256 -ne $expected[$index].Sha256 -or $actual[$index].Runtime -ne $expected[$index].Runtime) { throw "Frozen source changed: $($actual[$index].Path)" }
    }
    foreach ($helper in @('run-runtime-20261018-loyalty-r1-gate.ps1','synthetic-safety.php')) {
        $entry=@($Freeze.HarnessFiles | Where-Object { $_.Path -eq $helper })
        if ($entry.Count -ne 1 -or (Get-FileHash -LiteralPath (Join-Path $root $helper) -Algorithm SHA256).Hash -ne $entry[0].Sha256) { throw 'Frozen harness helper changed.' }
    }
}
if ([IO.Path]::GetFullPath($PSScriptRoot) -ne $root) { throw 'Runner must remain in its approved temporary root.' }
if ($PSCmdlet.ParameterSetName -eq 'Freeze') {
    $freezePath=Join-Path $root "$RunName-freeze.json"
    if (Test-Path -LiteralPath $freezePath) { throw 'Freeze already exists; do not overwrite evidence.' }
    if ((git -C $repo rev-parse HEAD) -ne $expectedHead -or (git -C $repo branch --show-current) -ne 'codex/2.51-handoff-20261016') { throw 'Source identity differs from approved batch.' }
    $helpers=foreach ($helper in @('run-runtime-20261018-loyalty-r1-gate.ps1','synthetic-safety.php')) { [pscustomobject]@{Path=$helper;Sha256=(Get-FileHash -LiteralPath (Join-Path $root $helper) -Algorithm SHA256).Hash} }
    [pscustomobject]@{Repository=$repo;Head=$expectedHead;Branch='codex/2.51-handoff-20261016';CreatedAt=(Get-Date).ToUniversalTime().ToString('o');Files=@(Get-FrozenFiles);HarnessFiles=@($helpers)} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $freezePath -Encoding utf8
    [pscustomobject]@{FreezeManifestPath=$freezePath;FreezeManifestSha256=(Get-FileHash -LiteralPath $freezePath -Algorithm SHA256).Hash} | ConvertTo-Json
    return
}
if (-not $ApprovedFrozenSource) { throw 'Await root frozen-source GO.' }
$freezePath=Assert-UnderRoot $FreezeManifestPath $root
if ((Get-FileHash -LiteralPath $freezePath -Algorithm SHA256).Hash -ne $FreezeManifestSha256) { throw 'Approved manifest hash mismatch.' }
$freeze=Get-Content -LiteralPath $freezePath -Raw | ConvertFrom-Json
Assert-Freeze $freeze
$run=Assert-UnderRoot (Join-Path $root $RunName) $root
if (Test-Path -LiteralPath $run) { throw 'Run already exists; preserve evidence and diagnose before an approved named retry.' }
if (Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue) { throw 'Selected loopback database port is occupied.' }
$archive=Join-Path $baseline 'downloads\wordpress-latest.zip'
$wpcli=Join-Path $baseline 'wp-cli.phar'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne 'EB58A90ED55147F90F7BD55D0D3334960A69B7E8A4CC142C8DDFEA8965218227') { throw 'Cached official WordPress archive differs from recorded provenance.' }
if ((Get-FileHash -LiteralPath $wpcli -Algorithm SHA256).Hash -ne 'CE34DDD838F7351D6759068D09793F26755463B4A4610A5A5C0A97B68220D85C') { throw 'Cached official WP-CLI differs from recorded provenance.' }
$sha1=(Get-Content -LiteralPath (Join-Path $baseline 'downloads\wordpress-latest.zip.sha1') -Raw).Trim()
$sha512=(Get-Content -LiteralPath (Join-Path $baseline 'downloads\wp-cli.phar.sha512') -Raw).Trim().Split(' ')[0]
if ($sha1 -notmatch '^[A-Fa-f0-9]{40}$' -or (Get-FileHash -LiteralPath $archive -Algorithm SHA1).Hash -ne $sha1) { throw 'Cached WordPress SHA1 mismatch.' }
if ($sha512 -notmatch '^[A-Fa-f0-9]{128}$' -or (Get-FileHash -LiteralPath $wpcli -Algorithm SHA512).Hash -ne $sha512) { throw 'Cached WP-CLI SHA512 mismatch.' }
New-Item -ItemType Directory -Path $run | Out-Null
$wordpress=Join-Path $run 'wordpress'
$data=Join-Path $run 'synthetic-mariadb-data'
$ini=Join-Path $run 'php.ini'
$scratch=Join-Path $run 'scratch'
$dbProcess=$null
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$oldPassword=$env:MYSQL_PWD
$oldIniScan=$env:PHP_INI_SCAN_DIR;$oldWpConfig=$env:WP_CLI_CONFIG_PATH;$oldWpPackages=$env:WP_CLI_PACKAGES_DIR
$applicationEnvironment=@{};$locationPushed=$false
$gateInvoked=$false;$gatePassed=$false;$stable=$false;$forcedStop=$false;$stopped=$true;$failure=$null;$shutdownFailure=$null
$started=(Get-Date).ToUniversalTime().ToString('o')
function Invoke-Wp([string[]]$WpArguments) {
    & $php -c $ini $wpcli @WpArguments "--path=$wordpress" '--skip-themes' >> (Join-Path $run 'setup.log') 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Synthetic WP-CLI operation failed: $($WpArguments[0]); inspect private local setup log." }
}
try {
    # Preserve supported application overrides in memory only, then keep them out
    # of bootstrap and every inherited worker process. Never log their contents.
    foreach ($entry in @(Get-ChildItem Env: | Where-Object { $_.Name -like 'DOUGHBOSS_*' })) {
        $applicationEnvironment[$entry.Name]=$entry.Value
        [Environment]::SetEnvironmentVariable($entry.Name,$null,'Process')
    }
    Expand-Archive -LiteralPath $archive -DestinationPath $run
    if (Test-Path -LiteralPath (Join-Path $wordpress 'wp-config.php')) { throw 'Official WordPress archive unexpectedly contains configured site.' }
    $iniText=Get-Content -LiteralPath (Join-Path $baseline 'php.ini') -Raw
    if ($iniText -match '(?im)^\s*(auto_prepend_file|auto_append_file)\s*=') { throw 'Unexpected inherited PHP prepend/append configuration.' }
    $applicationLog=(Join-Path $run 'application.log').Replace('\','/')
    $iniText+="`ndisable_functions=mail`nerror_log=`"$applicationLog`"`n"
    $iniText | Set-Content -LiteralPath $ini -Encoding utf8
    New-Item -ItemType Directory -Path $scratch | Out-Null
    $env:TEMP=$scratch;$env:TMP=$scratch
    $iniScan=Join-Path $run 'empty-ini-scan';New-Item -ItemType Directory -Path $iniScan | Out-Null
    $packages=Join-Path $run 'empty-wp-packages';New-Item -ItemType Directory -Path $packages | Out-Null
    $wpConfig=Join-Path $run 'isolated-wp-cli.yml';'{}' | Set-Content -LiteralPath $wpConfig -Encoding utf8
    $env:PHP_INI_SCAN_DIR=$iniScan;$env:WP_CLI_CONFIG_PATH=$wpConfig;$env:WP_CLI_PACKAGES_DIR=$packages
    Push-Location -LiteralPath $run;$locationPushed=$true
    $plugin=Join-Path $wordpress 'wp-content\plugins\doughboss'
    if (Test-Path -LiteralPath $plugin) { throw 'Fresh official archive unexpectedly contains DoughBoss; refusing overwrite.' }
    $parity=foreach ($entry in @($freeze.Files | Where-Object { $_.Runtime })) {
        $source=Assert-UnderRoot (Join-Path $repo $entry.Path) $repo
        $destination=Assert-UnderRoot (Join-Path $plugin $entry.Path) $plugin
        New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($destination)) -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination
        if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne $entry.Sha256) { throw "Installed runtime parity mismatch: $($entry.Path)" }
        [pscustomobject]@{Path=$entry.Path;Sha256=$entry.Sha256;Matched=$true}
    }
    $parity | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $run 'runtime-parity.json') -Encoding utf8
    # No old plugin or dataset is changed: the original installed test plugin is its preserved baseline.
    $mu=Join-Path $wordpress 'wp-content\mu-plugins'
    New-Item -ItemType Directory -Path $mu | Out-Null
    Copy-Item -LiteralPath (Join-Path $root 'synthetic-safety.php') -Destination (Join-Path $mu 'synthetic-safety.php')
    $password=[Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(24))
    & (Join-Path $bin 'mariadb-install-db.exe') "--datadir=$data" "--password=$password" "--port=$port" --silent >> (Join-Path $run 'initialize.log') 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Fresh isolated MariaDB initialization failed.' }
    $env:MYSQL_PWD=$password
    $dbProcess=Start-Process -FilePath (Join-Path $bin 'mariadbd.exe') -ArgumentList @('--no-defaults',"--datadir=$data",'--bind-address=127.0.0.1',"--port=$port",'--skip-name-resolve','--skip-log-bin','--console') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $run 'mariadb.stdout.log') -RedirectStandardError (Join-Path $run 'mariadb.stderr.log')
    $null=$dbProcess.Handle
    $ready=$false
    for ($attempt=0;$attempt -lt 100;$attempt++) {
        $dbProcess.Refresh()
        if ($dbProcess.HasExited) { throw 'Owned isolated MariaDB exited during startup.' }
        $listeners=@(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
        if ($listeners.Count -eq 1 -and $listeners[0].LocalAddress -eq '127.0.0.1' -and $listeners[0].OwningProcess -eq $dbProcess.Id) {
            & (Join-Path $bin 'mariadb-admin.exe') --no-defaults --host=127.0.0.1 "--port=$port" --user=root ping >> (Join-Path $run 'setup.log') 2>&1
            if ($LASTEXITCODE -eq 0) { $ready=$true;break }
        }
        Start-Sleep -Milliseconds 100
    }
    if (-not $ready) { throw 'Owned isolated loopback MariaDB readiness failed.' }
    $listeners | Select-Object LocalAddress,LocalPort,OwningProcess | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $run 'listener.json')
    & (Join-Path $bin 'mariadb.exe') --no-defaults --host=127.0.0.1 "--port=$port" --user=root '--execute=CREATE DATABASE doughboss_wp_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;' >> (Join-Path $run 'setup.log') 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Fresh synthetic database creation failed.' }
    Invoke-Wp @('config','create','--dbname=doughboss_wp_test','--dbuser=root',"--dbpass=$password","--dbhost=127.0.0.1:$port",'--skip-check','--skip-salts')
    foreach ($setting in @(@('WP_ENVIRONMENT_TYPE','local',''),@('DISABLE_WP_CRON','true','--raw'),@('AUTOMATIC_UPDATER_DISABLED','true','--raw'),@('WP_AUTO_UPDATE_CORE','false','--raw'))) {
        $arguments=@('config','set',$setting[0],$setting[1]);if ($setting[2]) { $arguments+=$setting[2] };Invoke-Wp $arguments
    }
    $adminPassword=[Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(24))
    Invoke-Wp @('core','install','--url=http://doughboss.local.test','--title=Dough Boss','--admin_user=synthetic_admin',"--admin_password=$adminPassword",'--admin_email=synthetic@example.invalid','--skip-email')
    Invoke-Wp @('plugin','activate','doughboss')
    Invoke-Wp @('eval',"if ('local' !== wp_get_environment_type() || 'doughboss_wp_test' !== DB_NAME || '127.0.0.1:33119' !== DB_HOST || 'http://doughboss.local.test' !== untrailingslashit(home_url()) || true !== WP_HTTP_BLOCK_EXTERNAL || function_exists('mail') || !is_wp_error(apply_filters('pre_http_request',false,array(),'https://example.invalid')) || true !== apply_filters('pre_wp_mail',null,array())) { exit(2); } echo 'SYNTHETIC_GUARDS_OK';")
    Assert-Freeze $freeze
    # A separate disposable 12-process pickup race precedes the source gate.
    $pickupScratch=Join-Path $run 'pickup-race'
    New-Item -ItemType Directory -Path $pickupScratch | Out-Null
    $priorPickupMode=$env:DOUGHBOSS_PICKUP_RACE_MODE
    $priorPickupScratch=$env:DOUGHBOSS_PICKUP_RACE_SCRATCH
    $pickupWorkers=[System.Collections.Generic.List[System.Diagnostics.Process]]::new()
    try {
        $env:DOUGHBOSS_PICKUP_RACE_MODE='prepare'
        $env:DOUGHBOSS_PICKUP_RACE_SCRATCH=$pickupScratch
        $pickupSource=Join-Path $repo 'tests\integration\pickup-race-worker.php'
        Invoke-Wp @('eval-file',$pickupSource)
        $env:DOUGHBOSS_PICKUP_RACE_MODE='hold'
        $pickupArguments=@('-c',$ini,$wpcli,"--exec=define('WP_HTTP_BLOCK_EXTERNAL',true);",'eval-file',$pickupSource,"--path=$wordpress",'--skip-themes')
        $pickupRuns=foreach ($number in 1..12) {
            $stdout=Join-Path $pickupScratch "worker-$number.stdout.log"
            $stderr=Join-Path $pickupScratch "worker-$number.stderr.log"
            $process=Start-Process -FilePath $php -ArgumentList $pickupArguments -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
            $null=$process.Handle
            $pickupWorkers.Add($process)
            [pscustomobject]@{Process=$process;Stdout=$stdout;Stderr=$stderr}
        }
        $deadline=(Get-Date).AddSeconds(25)
        $allReady=$false
        do {
            $observed=@(Get-ChildItem -LiteralPath $pickupScratch -Filter 'ready-*.json' -File | ForEach-Object {
                [int](Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json).pid
            } | Sort-Object -Unique)
            $expected=@($pickupRuns | ForEach-Object { [int]$_.Process.Id } | Sort-Object)
            if (($observed -join ',') -eq ($expected -join ',')) { $allReady=$true;break }
            foreach ($worker in $pickupRuns) {
                if ($worker.Process.HasExited) { throw 'Pickup race worker exited before explicit barrier.' }
            }
            Start-Sleep -Milliseconds 50
        } while ((Get-Date) -lt $deadline)
        if (-not $allReady) { throw 'Twelve pickup workers did not reach the explicit barrier.' }
        New-Item -ItemType File -Path (Join-Path $pickupScratch 'go') | Out-Null
        $success=0;$full=0
        foreach ($worker in $pickupRuns) {
            if (-not $worker.Process.WaitForExit(30000)) { throw 'Pickup race worker timed out.' }
            $worker.Process.Refresh()
            $stdout=Get-Content -LiteralPath $worker.Stdout -Raw
            $stderr=Get-Content -LiteralPath $worker.Stderr -Raw
            if ($worker.Process.ExitCode -ne 0 -or -not [string]::IsNullOrWhiteSpace($stderr)) { throw 'Pickup race worker failed; inspect its isolated stdout/stderr.' }
            if ($stdout -match '(?m)^PICKUP_HOLD_OK$') { $success++ }
            elseif ($stdout -match '(?m)^PICKUP_FULL_OK$') { $full++ }
            else { throw 'Pickup race worker omitted its exact success marker.' }
        }
        if ($success -ne 6 -or $full -ne 6) { throw "Pickup race expected six holds/six full refusals; got $success/$full." }
        $env:DOUGHBOSS_PICKUP_RACE_MODE='verify'
        Invoke-Wp @('eval-file',$pickupSource)
        [pscustomobject]@{Workers=12;ReadyPids=$expected;SuccessfulHolds=$success;FullRefusals=$full;DurableStateVerified=$true;ProviderHttp='blocked';SyntheticOnly=$true} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $run 'pickup-race-result.json') -Encoding utf8
    } finally {
        foreach ($process in $pickupWorkers) {
            if (-not $process.HasExited) { $process.Kill();$process.WaitForExit(5000) | Out-Null }
        }
        $env:DOUGHBOSS_PICKUP_RACE_MODE=$priorPickupMode
        $env:DOUGHBOSS_PICKUP_RACE_SCRATCH=$priorPickupScratch
    }

    $gateInvoked=$true
    & (Join-Path $repo 'scripts\test-wordpress-integration.ps1') -PhpPath $php -PhpIniPath $ini -WpCliPath $wpcli -WordPressPath $wordpress *> (Join-Path $run 'gate.log')
    $gatePassed=$true
    Assert-Freeze $freeze
    foreach ($entry in @($freeze.Files | Where-Object { $_.Runtime })) {
        if ((Get-FileHash -LiteralPath (Join-Path $plugin $entry.Path) -Algorithm SHA256).Hash -ne $entry.Sha256) { throw 'Installed runtime changed during gate.' }
    }
    if ((Get-FileHash -LiteralPath $freezePath -Algorithm SHA256).Hash -ne $FreezeManifestSha256) { throw 'Approved freeze manifest changed during gate.' }
    $stable=$true
} catch {
    $failure=$_.Exception.Message
    $gatePassed=$false
} finally {
    try {
        if ($dbProcess -and -not $dbProcess.HasExited) {
            $stopTool=Start-Process -FilePath (Join-Path $bin 'mariadb-admin.exe') -ArgumentList @('--no-defaults','--host=127.0.0.1',"--port=$port",'--user=root','shutdown') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $run 'shutdown.stdout.log') -RedirectStandardError (Join-Path $run 'shutdown.stderr.log')
            if (-not $stopTool.WaitForExit(10000)) { $stopTool.Kill();$stopTool.WaitForExit();throw 'Owned database shutdown tool timed out.' }
            if (-not $dbProcess.WaitForExit(10000)) { throw 'Owned database did not exit after shutdown.' }
        }
    } catch { $shutdownFailure=$_.Exception.Message }
    if ($dbProcess -and -not $dbProcess.HasExited) { $forcedStop=$true;$dbProcess.Kill();$dbProcess.WaitForExit(10000) | Out-Null }
    $env:TEMP=$oldTemp;$env:TMP=$oldTmp;$env:MYSQL_PWD=$oldPassword
    $env:PHP_INI_SCAN_DIR=$oldIniScan;$env:WP_CLI_CONFIG_PATH=$oldWpConfig;$env:WP_CLI_PACKAGES_DIR=$oldWpPackages
    foreach ($name in $applicationEnvironment.Keys) { [Environment]::SetEnvironmentVariable($name,$applicationEnvironment[$name],'Process') }
    if ($locationPushed) { Pop-Location }
    $stopped=($null -eq $dbProcess -or $dbProcess.HasExited)
    $remaining=@(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
    $ok=($gatePassed -and $stable -and $stopped -and -not $remaining.Count -and -not $shutdownFailure -and -not $forcedStop)
    [pscustomobject]@{Passed=$ok;Failure=$failure;GateInvoked=$gateInvoked;SourceGatePassed=$gatePassed;HashesStable=$stable;Repository=$repo;Head=$expectedHead;FreezeManifestSha256=$FreezeManifestSha256;HarnessFiles=$freeze.HarnessFiles;DatabasePort=$port;DatabaseName='doughboss_wp_test';DatabasePid=if($dbProcess){$dbProcess.Id}else{$null};DatabaseStopped=$stopped;PortStillListening=[bool]$remaining.Count;ShutdownFailure=$shutdownFailure;ForcedStop=$forcedStop;HttpAndMailGuardsVerified=$gateInvoked;FreshDataset=$true;OldFixtureUntouched=$true;StartedAt=$started;FinishedAt=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $run 'result.json') -Encoding utf8
}
if (-not $ok) { throw "Isolated chain gate not accepted. Inspect result.json and local logs under $run." }
Write-Output "RUNTIME_GATE_PASS: source hashes stable, isolated MySQL gate passed, owned loopback process stopped; evidence=$run"
