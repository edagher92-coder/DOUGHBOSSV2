<?php
/** Disposable instance only: final HTTP block and default mail preemption. */
// Canonical gate workers define this via --exec before WordPress bootstrap.
// Setup commands rely on this guarded fallback; an existing non-true value fails below.
if ( ! defined( 'WP_HTTP_BLOCK_EXTERNAL' ) ) {
	define( 'WP_HTTP_BLOCK_EXTERNAL', true );
}
if ( ! defined( 'WP_ENVIRONMENT_TYPE' ) || 'local' !== WP_ENVIRONMENT_TYPE
	|| ! defined( 'DB_NAME' ) || 'doughboss_wp_test' !== DB_NAME
	|| ! defined( 'DB_HOST' ) || '127.0.0.1:33119' !== DB_HOST
	|| ! defined( 'WP_HTTP_BLOCK_EXTERNAL' ) || true !== WP_HTTP_BLOCK_EXTERNAL ) {
	fwrite( STDERR, "Synthetic instance safety configuration mismatch.\n" );
	exit( 2 );
}
// Synthetic response filters can replace false with arrays/WP_Error. Anything
// left unhandled must never reach the network, including loopback requests.
add_filter( 'pre_http_request', static function ( $preempt ) {
	return false === $preempt ? new WP_Error( 'synthetic_network_blocked', 'Disposable test instance has no outbound HTTP.' ) : $preempt;
}, PHP_INT_MAX, 1 );
// Fixture-specific mail callbacks may return their own synthetic success/failure.
// Native mail() is independently disabled in this instance's generated php.ini.
add_filter( 'pre_wp_mail', static function () { return true; }, -PHP_INT_MAX, 1 );
