Public-source checkpoint only. No operation admission, VM image, backup, credential or provider configuration.
R7 captures a bounded sysfs inventory before the unchanged fail-closed guard.
R8 permits only loop1..7 with zero sectors, ro=0, no backing entry and no backing symlink.
Verify SOURCE-MANIFEST.json before use. Source is a fixed-profile staging tool, not a general VM runner.
The retained R4 source is immutable comparison evidence for the preparation tests.
To reproduce source-byte synthetic checks on the original host, place sources in the original isolated
test root specified by run_integration_tests.py and run it using trusted Python 3.14 -I -S -B.
The runner overwrites only its own local diagnostic receipts and mocks child execution.
Shell negative-case execution and installed/private restore acceptance are not established by these tests.
Do not run an operation caller without a separately reviewed fresh plan, pinned inputs/tools and absent outputs.
