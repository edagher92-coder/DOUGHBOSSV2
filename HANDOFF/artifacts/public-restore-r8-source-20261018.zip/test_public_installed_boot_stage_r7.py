"""Synthetic-only tests. No child process, real images, provider or network."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import hashlib
import re
import sys
import types

HERE = Path(__file__).absolute().parent

def load_source(name, expected=None):
    path = HERE / (name + ".py")
    data = path.read_bytes()
    if expected is not None and hashlib.sha256(data).hexdigest() != expected:
        raise RuntimeError("SOURCE_PIN")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module

stage = load_source("public_installed_boot_stage_r7")



SERIAL = b"\n".join((stage.LIVE, stage.SUCCESS, stage.EXIT)) + b"\n"


def output(header=None, kernel=b"synthetic-kernel", initramfs=b"synthetic-initramfs"):
    if header is None:
        header = (stage.MAGIC + f"kernel_bytes={len(kernel)}\nkernel_sha256={stage.sha256(kernel)}\n"
                  f"initramfs_bytes={len(initramfs)}\ninitramfs_sha256={stage.sha256(initramfs)}\nEND\n".encode())
    data = bytearray(stage.OUTPUT_BYTES)
    data[:len(header)] = header
    data[stage.MIB:stage.MIB+len(kernel)] = kernel
    data[16*stage.MIB:16*stage.MIB+len(initramfs)] = initramfs
    return bytes(data)


class PreparationTests(unittest.TestCase):
    def setUp(self):
        # Prohibit child-process/image-operation routes even if added later.
        self.guards = [patch("subprocess.Popen", side_effect=AssertionError("CHILD_FORBIDDEN")),
                       patch("os.system", side_effect=AssertionError("CHILD_FORBIDDEN"))]
        for guard in self.guards:
            guard.start()
            self.addCleanup(guard.stop)
        self.root = Path(tempfile.gettempdir()).absolute() / "synthetic-public-stage-r7"

    def test_script_public_only_and_bounded(self):
        script = stage.render_guest_script()
        self.assertLessEqual(len(script), 4096)
        self.assertEqual(script.decode("ascii").encode("ascii"), script)
        self.assertIn(b"mount -t ext4 -o ro,noload /dev/vda1", script)
        self.assertNotIn(b"mount /dev/vda2", script)
        self.assertNotIn(b"chroot", script)
        self.assertNotIn(b"apk ", script)
        for check in (b"12582912", b"131072", b"/sys/block/vda/ro", b"/sys/block/vdb/ro",
                      b"/sys/block/vdc/ro", b"/sys/class/net", b"ip route", b"umount", b"poweroff -f"):
            self.assertIn(check, script)

    def test_script_disk_identity_and_padding(self):
        disk = stage.render_script_disk()
        script = stage.render_guest_script()
        self.assertEqual(len(disk), 4096)
        self.assertEqual(disk[:len(script)], script)
        self.assertFalse(any(disk[len(script):]))
        self.assertIn(stage.sha256(script), stage.serial_command())
        self.assertIn(f"count={len(script)}", stage.serial_command())

    def test_topology_exact_readonly_inputs(self):
        argv = stage.qemu_argv(self.root)
        stage.validate_argv(argv, self.root)
        drives = [argv[n+1] for n, arg in enumerate(argv) if arg == "-drive"]
        self.assertEqual(len(drives), 4)
        self.assertTrue(all("readonly=on" in d for d in drives[:3]))
        self.assertNotIn("readonly=on", drives[3])
        self.assertIn("media=cdrom", drives[0])
        self.assertIn(stage.BASE, drives[1])
        self.assertIn(stage.SCRIPT_DISK, drives[2])
        self.assertEqual(argv[argv.index("-append")+1], stage.APPEND)
        self.assertNotIn("root=UUID", stage.APPEND)
        self.assertEqual(argv[argv.index("-nic")+1], "none")
        self.assertEqual(argv.count("-no-user-config"), 1)

    def test_forbidden_flags_and_argument_mutation(self):
        argv = stage.qemu_argv(self.root)
        argv.remove("-no-user-config")
        with self.assertRaisesRegex(stage.Stop, "TOPOLOGY"):
            stage.validate_argv(argv, self.root)
        for extra in (["-netdev", "user,id=n"], ["-virtfs", "local,path=C:/"],
                      ["-monitor", "tcp::4444"], ["-device", "vfio-pci"], ["-snapshot"]):
            with self.subTest(extra=extra), self.assertRaises(stage.Stop):
                stage.validate_argv(stage.qemu_argv(self.root) + extra, self.root)
        argv = stage.qemu_argv(self.root)
        index = next(n for n, value in enumerate(argv) if stage.BASE in value)
        argv[index] = argv[index].replace(",readonly=on", "")
        with self.assertRaisesRegex(stage.Stop, "TOPOLOGY"):
            stage.validate_argv(argv, self.root)

    def test_forbidden_paths(self):
        for path in ("relative", str(self.root / ".." / "escape"), str(self.root) + ",readonly=off"):
            with self.subTest(path=path), self.assertRaises(stage.Stop):
                stage.qemu_argv(path)
        with self.assertRaises(stage.Stop):
            stage.safe_path(self.root, "../escape", exists=False)

    def test_freshness_regular_inputs_and_reparse(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in (stage.BASE, stage.TOOL, stage.ISO, stage.KERNEL, stage.INITRAMFS):
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.touch(exist_ok=False)
            stage.check_paths(root)
            (root / stage.OUTPUT).touch(exist_ok=False)
            with self.assertRaisesRegex(stage.Stop, "STALE_OUTPUT"):
                stage.check_paths(root)
            with patch.object(stage.os, "lstat") as mocked:
                mocked.return_value.st_mode = 0
                mocked.return_value.st_file_attributes = 0x400
                with self.assertRaisesRegex(stage.Stop, "PATH_REPARSE"):
                    stage.safe_path(root, stage.BASE)

    def test_manifest_has_no_admission_or_boot_claim(self):
        manifest = stage.render_manifest(self.root)
        self.assertEqual(manifest["status"], "NOT_ADMITTED")
        self.assertFalse(manifest["execution_implemented"])
        self.assertFalse(manifest["restore_acceptance"])
        self.assertEqual(manifest["mode"], stage.MODE)
        self.assertIn("PENDING", manifest["base_tool_pins"]["actual_input_reverification"])
        self.assertEqual(manifest["script_disk_sha256"], stage.sha256(stage.render_script_disk()))

    def test_accepted_pin_chain_no_source_execution_or_tofu(self):
        source = (b"BASE_SHA='" + b"a"*64 + b"'\nBASE_SIZE=100\nBASE_MTIME_NS=123\n"
                  b"PIN=('qemu-system-x86_64.exe','" + b"b"*64 + b"')\n"
                  b"raise RuntimeError('NEVER EXECUTE THIS SOURCE')\n")
        driver_hash = stage.sha256(source)
        freeze = json.dumps({"files": [{"Path": stage.PIN_DRIVER,
                                        "Bytes": len(source), "Sha256": driver_hash}]}).encode()
        freeze_hash = stage.sha256(freeze)
        result = json.dumps({"rootAdmissionFreezeSha256": freeze_hash}).encode()
        with patch.object(stage, "ACCEPTED_FREEZE_SHA", freeze_hash), patch.object(stage, "ACCEPTED_DRIVER_SHA", driver_hash):
            pins = stage.parse_public_pin_chain(result, freeze, source)
            self.assertEqual(pins[stage.BASE], {"bytes": 100, "mtime_ns": 123, "sha256": "a"*64})
            self.assertEqual(pins[stage.TOOL]["sha256"], "b"*64)
            for documents in ((b"{}", freeze, source), (b'{"rootAdmissionFreezeSha256":1}', freeze, source),
                              (result, freeze+b" ", source),
                              (result, freeze, source+b" ")):
                with self.subTest(documents=documents), self.assertRaises(stage.Stop):
                    stage.parse_public_pin_chain(*documents)
        with self.assertRaisesRegex(stage.Stop, "PIN_DUPLICATE"):
            stage._json(b'{"x":1,"x":2}')


class ParserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.good = output()

    def test_valid_synthetic_output(self):
        artifacts = stage.parse_output(self.good, SERIAL, 0)
        self.assertEqual(artifacts.kernel, b"synthetic-kernel")
        self.assertEqual(artifacts.initramfs, b"synthetic-initramfs")

    def test_exact_file_size(self):
        for data in (self.good[:-1], self.good + b"\0", bytearray(self.good)):
            with self.subTest(size=len(data)), self.assertRaisesRegex(stage.Stop, "OUTPUT_SIZE"):
                stage.parse_output(data, SERIAL, 0)

    def test_failed_exit_marker_missing_duplicate_and_failure(self):
        for code in (1, -1, None, False):
            with self.subTest(code=code), self.assertRaisesRegex(stage.Stop, "QEMU_EXIT"):
                stage.parse_output(self.good, SERIAL, code)
        for serial in (b"", SERIAL.replace(stage.SUCCESS, b"PUBLIC_STAGE_R7_STATUS=FAIL"),
                       SERIAL + stage.EXIT + b"\n", SERIAL.replace(stage.EXIT, b""),
                       SERIAL.replace(stage.LIVE, b"PUBLIC_STAGE_R7_LIVE=6.18.56-0-virt"),
                       SERIAL.replace(stage.SUCCESS, b"echo " + stage.SUCCESS)):
            with self.subTest(serial=serial), self.assertRaisesRegex(stage.Stop, "SERIAL_STATUS"):
                stage.parse_output(self.good, serial, 0)

    def test_serial_limit(self):
        with self.assertRaisesRegex(stage.Stop, "SERIAL_BOUND"):
            stage.parse_output(self.good, b"x" * (4 * stage.MIB + 1), 0)

    def test_status_order(self):
        with self.assertRaisesRegex(stage.Stop, "SERIAL_STATUS_ORDER"):
            stage.parse_output(self.good, b"\n".join((stage.SUCCESS, stage.LIVE, stage.EXIT)), 0)

    def test_header_unknown_duplicate_malformed_bounds(self):
        original = self.good[:self.good.index(b"END\n")+4]
        headers = [original.replace(b"END\n", b"unknown=1\nEND\n"),
                   original.replace(b"END\n", b"kernel_bytes=1\nEND\n"),
                   original.replace(b"kernel_bytes=16", b"kernel_bytes=0"),
                   original.replace(b"kernel_bytes=16", b"kernel_bytes=15728641"),
                   original.replace(b"initramfs_bytes=19", b"initramfs_bytes=49283073"),
                   original.replace(b"kernel_bytes=16", b"kernel_bytes=01"),
                   original.replace(b"END\n", b"END\r\n"),
                   original.replace(b"kernel_sha256=", b"kernel_sha256=G")]
        # Use actual fixture lengths; avoid silently ineffective substitutions.
        for old in (b"kernel_bytes=16", b"initramfs_bytes=19"):
            self.assertIn(old, original)
        for header in headers:
            with self.subTest(header=header), self.assertRaises(stage.Stop):
                stage.parse_output(output(header), SERIAL, 0)

    def test_all_unused_padding_is_zero(self):
        for offset in (4095, 8192, stage.MIB + 100, 16 * stage.MIB - 1,
                       16 * stage.MIB + 100, stage.OUTPUT_BYTES - 1):
            data = bytearray(self.good)
            data[offset] = 1
            with self.subTest(offset=offset), self.assertRaises(stage.Stop):
                stage.parse_output(bytes(data), SERIAL, 0)

    def test_output_hash_mismatch_both_slots(self):
        for offset in (stage.MIB, 16 * stage.MIB):
            data = bytearray(self.good)
            data[offset] ^= 1
            with self.subTest(offset=offset), self.assertRaisesRegex(stage.Stop, "OUTPUT_HASH"):
                stage.parse_output(bytes(data), SERIAL, 0)



class DiagnosticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.baseline = load_source("public_installed_boot_stage_r4", "16ff8d9f059517b64e3788d1cb375e48909144a301069ce1af0189a85aac9bb4")
        cls.script = stage.render_guest_script().decode("ascii")
        cls.good = output()

    def test_inventory_probe_is_read_only_bounded_and_before_original_guard(self):
        probe = stage.INVENTORY_PROBE.decode("ascii")
        self.assertIn('for probe in /sys/block/*; do', probe)
        self.assertIn('if [ "$count" -gt 32 ]; then', probe)
        self.assertIn('sectors=$(cat "$probe/size")', probe)
        self.assertIn('ro=$(cat "$probe/ro")', probe)
        self.assertIn('"$probe/loop/backing_file"', probe)
        for forbidden in ('/dev/', 'mount ', 'umount ', 'dd ', 'eval ', ' >', 'curl ', 'wget '):
            self.assertNotIn(forbidden, probe)
        self.assertLess(self.script.index(probe), self.script.index('for d in /sys/block/*; do'))
        self.assertIn('sr0|loop0) check=BLOCK_DEVICE_READ_ONLY;', self.script)
        self.assertIn('*) exit 1', self.script)

    def test_all_old_guards_and_operations_are_preserved(self):
        self.assertEqual(self.script.count(stage.INVENTORY_PROBE.decode("ascii")), 1)
        script = self.script.replace(stage.INVENTORY_PROBE.decode("ascii"), "", 1)
        script = script.replace("PUBLIC_INSTALLED_BOOT_STAGE_R7", "PUBLIC_INSTALLED_BOOT_STAGE_R4")
        script = script.replace("PUBLIC_STAGE_R7", "PUBLIC_STAGE_R4")
        script = script.replace("public-installed-boot-stage-r7", "public-installed-boot-stage-r4")
        script = re.sub(r"^[ \t]*check=[A-Z0-9_]+\n", "", script, flags=re.MULTILINE)
        script = script.replace(
            ' sync || { if [ "$e" = 0 ]; then check=CLEANUP_SYNC; fi; e=1; }',
            " sync || e=1")
        script = script.replace(
            'if [ "$mounted" = 1 ]; then umount "$b" || { if [ "$e" = 0 ]; then check=CLEANUP_UNMOUNT; fi; e=1; }; fi',
            'if [ "$mounted" = 1 ]; then umount "$b" || e=1; fi')
        script = script.replace(
            'else echo PUBLIC_STAGE_R4_CHECK_FAIL=$check; echo PUBLIC_STAGE_R4_STATUS=FAIL; fi',
            'else echo PUBLIC_STAGE_R4_STATUS=FAIL; fi')
        script = script.replace(
            'sr0|loop0) check=BLOCK_DEVICE_READ_ONLY; [ "$(cat "$d/ro")" = 1 ]',
            'sr0|loop0) [ "$(cat "$d/ro")" = 1 ]')
        self.assertEqual(script.encode("ascii"), self.baseline.render_guest_script())

    def test_each_guard_has_its_fixed_preceding_label(self):
        guards = [
    [
        "[ \"$(uname -r)\" = \"{LIVE_VERSION}\" ]",
        "LIVE_VERSION"
    ],
    [
        "[ \"$(cat /sys/block/vda/size)\" = 12582912 ]",
        "VDA_SIZE"
    ],
    [
        "[ \"$(cat /sys/block/vda/ro)\" = 1 ]",
        "VDA_READ_ONLY"
    ],
    [
        "[ \"$(cat /sys/block/vdb/size)\" = 8 ]",
        "VDB_SIZE"
    ],
    [
        "[ \"$(cat /sys/block/vdb/ro)\" = 1 ]",
        "VDB_READ_ONLY"
    ],
    [
        "[ \"$(cat /sys/block/vdc/size)\" = 131072 ]",
        "VDC_SIZE"
    ],
    [
        "[ \"$(cat /sys/block/vdc/ro)\" = 0 ]",
        "VDC_READ_WRITE"
    ],
    [
        "[ \"$(ls /sys/class/net)\" = lo ]",
        "NETWORK_INTERFACE_SET"
    ],
    [
        "r=$(ip route); [ -z \"$r\" ]",
        "IPV4_ROUTE_SET"
    ],
    [
        "r=$(ip -6 route show default); [ -z \"$r\" ]",
        "IPV6_DEFAULT_ROUTE"
    ],
    [
        "if grep -q '^/dev/vda' /proc/mounts; then exit 1; fi",
        "SOURCE_ALREADY_MOUNTED"
    ],
    [
        "set -- $(sha256sum /dev/vdc)",
        "OUTPUT_NOT_ZERO"
    ],
    [
        "[ ! -e \"$b\" ]",
        "MOUNTPOINT_ABSENT"
    ],
    [
        "mkdir -m 700 \"$b\"",
        "MOUNTPOINT_CREATE"
    ],
    [
        "blkid /dev/vda1 | grep -q ' UUID=\"{BOOT_UUID}\"'",
        "BOOT_UUID"
    ],
    [
        "mount -t ext4 -o ro,noload /dev/vda1 \"$b\"",
        "SOURCE_MOUNT"
    ],
    [
        "[ -f \"$b/vmlinuz-virt\" ]",
        "KERNEL_REGULAR"
    ],
    [
        "[ ! -L \"$b/vmlinuz-virt\" ]",
        "KERNEL_NOT_SYMLINK"
    ],
    [
        "[ -f \"$b/initramfs-virt\" ]",
        "INITRAMFS_REGULAR"
    ],
    [
        "[ ! -L \"$b/initramfs-virt\" ]",
        "INITRAMFS_NOT_SYMLINK"
    ],
    [
        "k=$(wc -c < \"$b/vmlinuz-virt\")",
        "KERNEL_SIZE"
    ],
    [
        "i=$(wc -c < \"$b/initramfs-virt\")",
        "INITRAMFS_SIZE"
    ],
    [
        "[ \"$k\" -gt 0 ]",
        "KERNEL_SIZE_POSITIVE"
    ],
    [
        "[ \"$k\" -le 15728640 ]",
        "KERNEL_SIZE_BOUND"
    ],
    [
        "[ \"$i\" -gt 0 ]",
        "INITRAMFS_SIZE_POSITIVE"
    ],
    [
        "[ \"$i\" -le 49283072 ]",
        "INITRAMFS_SIZE_BOUND"
    ],
    [
        "set -- $(sha256sum \"$b/vmlinuz-virt\"); kh=$1",
        "KERNEL_HASH"
    ],
    [
        "set -- $(sha256sum \"$b/initramfs-virt\"); ih=$1",
        "INITRAMFS_HASH"
    ],
    [
        "dd if=\"$b/vmlinuz-virt\" of=/dev/vdc bs=1048576 seek=1 count=15 conv=notrunc",
        "KERNEL_COPY"
    ],
    [
        "dd if=\"$b/initramfs-virt\" of=/dev/vdc bs=1048576 seek=16 count=47 conv=notrunc",
        "INITRAMFS_COPY"
    ],
    [
        "printf 'PUBLIC_INSTALLED_BOOT_STAGE_R7",
        "HEADER_CREATE"
    ],
    [
        "dd if=\"$b-header\" of=/dev/vdc bs=4096 count=1 conv=sync,notrunc",
        "HEADER_COPY"
    ]
]
        for command, label in guards:
            command = command.replace("{LIVE_VERSION}", stage.LIVE_VERSION)
            command = command.replace("{BOOT_UUID}", stage.BOOT_UUID)
            with self.subTest(label=label):
                self.assertIn("check=" + label + "\n" + command, self.script)
        self.assertIn("check=BLOCK_DEVICE_SET\n case", self.script)
        self.assertIn("check=CLASS_BLOCK_SET\n case", self.script)
        self.assertIn("sr0|loop0) check=BLOCK_DEVICE_READ_ONLY;", self.script)

    def test_every_failure_label_rejects_even_forged_success(self):
        labels = set(re.findall(r"check=([A-Z][A-Z0-9_]+)", self.script))
        self.assertGreaterEqual(len(labels), 38)
        for label in labels:
            serial = b"PUBLIC_STAGE_R7_CHECK_FAIL=" + label.encode("ascii") + b"\n" + SERIAL
            with self.subTest(label=label), self.assertRaisesRegex(stage.Stop, "SERIAL_CHECK_FAIL"):
                stage.parse_output(self.good, serial, 0)

    def test_failed_status_and_label_cannot_release_artifacts(self):
        serial = SERIAL.replace(stage.SUCCESS, b"PUBLIC_STAGE_R7_STATUS=FAIL")
        serial += b"PUBLIC_STAGE_R7_CHECK_FAIL=VDA_SIZE\n"
        with self.assertRaisesRegex(stage.Stop, "SERIAL_CHECK_FAIL"):
            stage.parse_output(self.good, serial, 0)

    def test_cleanup_keeps_the_original_failure_label(self):
        self.assertIn('sync || { if [ "$e" = 0 ]; then check=CLEANUP_SYNC; fi; e=1; }', self.script)
        self.assertIn('umount "$b" || { if [ "$e" = 0 ]; then check=CLEANUP_UNMOUNT; fi; e=1; }', self.script)

    def test_new_artifact_names_do_not_reuse_failed_receipts(self):
        self.assertFalse(set(stage.OUTPUT_NAMES) & set(self.baseline.OUTPUT_NAMES))
        self.assertEqual(len(stage.render_script_disk()), self.baseline.SCRIPT_BYTES)


if __name__ == "__main__":
    unittest.main()



