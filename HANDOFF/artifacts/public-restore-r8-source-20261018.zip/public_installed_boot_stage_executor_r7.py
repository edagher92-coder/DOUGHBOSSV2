"""Root-callable public staging executor; CLI/import never admit or launch.

Preparation only until root supplies a reviewed, hash-bound Admission. This is
not restore acceptance, installed-kernel boot acceptance, or tool-closure proof.
"""
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

import public_installed_boot_stage_r7 as stage

EXECUTOR = "public_installed_boot_stage_executor_r7.py"
MODULE = "public_installed_boot_stage_r7.py"
PROFILE = {"mode": stage.MODE, "public_only": True, "restore_acceptance": False,
           "seconds": 600, "log_bytes": 4 * stage.MIB, "write_bytes": 4,
           "write_interval": 0.2, "cleanup_seconds": 3,
           "support_closure": "ROOT_REVIEWED_PUBLIC_TOOL_CLOSURE"}
PROFILE_SHA256 = stage.sha256(json.dumps(PROFILE, sort_keys=True).encode("ascii"))
REQUIRED = (EXECUTOR, MODULE, stage.BASE, stage.TOOL, stage.ISO, stage.KERNEL,
            stage.INITRAMFS, stage.PIN_RESULT, stage.PIN_FREEZE, stage.PIN_DRIVER)
APPROVAL = "ROOT_APPROVED_PUBLIC_INSTALLED_BOOT_STAGE_ONLY"
# Fixed line-reader handoff; its real guest echo behavior remains a barrier.
TERMINAL_HANDSHAKE = b"exec /bin/sh -c 'while IFS= read -r l; do eval \"$l\"; done'\n"
READY_MARKER = b"PUBLIC_STAGE_R7_READY"
READY_COMMAND = b"printf 'PUBLIC_STAGE_R7_READY\\n'\n"


@dataclass(frozen=True)
class Pin:
    name: str
    size: int
    sha256: str
    mtime_ns: int | None = None


@dataclass(frozen=True)
class Admission:
    """Explicit root authority, never loaded from guest, CLI or result files.

    Root must review tool DLL/firmware/config closure and include its public
    files as additional pins. The assertion below is not automatic discovery.
    """
    root: str
    executor_sha256: str
    module_sha256: str
    profile_sha256: str
    pins: tuple[Pin, ...]
    approval: str
    public_tool_closure_reviewed: bool


def _identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)


def _digest(path):
    before = os.stat(path)
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        if _identity(os.fstat(source.fileno())) != _identity(before):
            raise stage.Stop("INPUT_IDENTITY")
        for block in iter(lambda: source.read(stage.MIB), b""):
            digest.update(block)
        if _identity(os.fstat(source.fileno())) != _identity(before):
            raise stage.Stop("INPUT_IDENTITY")
    if _identity(os.stat(path)) != _identity(before):
        raise stage.Stop("INPUT_IDENTITY")
    return _identity(before), digest.hexdigest()


def _admit(root, admission):
    root = stage._root(root)
    if (type(admission) is not Admission or admission.root != str(root)
            or admission.approval != APPROVAL
            or admission.profile_sha256 != PROFILE_SHA256
            or admission.public_tool_closure_reviewed is not True
            or type(admission.pins) is not tuple):
        raise stage.Stop("NOT_ADMITTED")
    pins = {}
    for pin in admission.pins:
        if (type(pin) is not Pin or pin.name in pins or type(pin.size) is not int
                or pin.size < 0 or not re.fullmatch(r"[0-9a-f]{64}", pin.sha256)
                or (pin.mtime_ns is not None and
                    (type(pin.mtime_ns) is not int or pin.mtime_ns <= 0))):
            raise stage.Stop("ADMISSION_PIN_SCHEMA")
        stage.safe_path(root, pin.name)
        # Extra pins are tool dependencies, never arbitrary/private paths.
        if pin.name not in REQUIRED and (not pin.name.startswith("qemu-test-tools/")
                                        or "\\" in pin.name):
            raise stage.Stop("ADMISSION_PIN_SCOPE")
        pins[pin.name] = pin
    if not set(REQUIRED).issubset(pins):
        raise stage.Stop("ADMISSION_PINS_MISSING")
    if (pins[EXECUTOR].sha256 != admission.executor_sha256
            or pins[MODULE].sha256 != admission.module_sha256):
        raise stage.Stop("ADMISSION_CODE_BINDING")
    # Bind the actual imported modules, not similarly named alternate files.
    if (Path(__file__).absolute() != stage.safe_path(root, EXECUTOR)
            or Path(stage.__file__).absolute() != stage.safe_path(root, MODULE)):
        raise stage.Stop("ADMISSION_MODULE_LOCATION")
    for name in stage.OUTPUT_NAMES:
        target = stage.safe_path(root, name, exists=False)
        if os.path.lexists(target):
            raise stage.Stop("STALE_OUTPUT")
    return root, pins


def _verify_inputs(root, pins, previous=None):
    snapshots = {}
    for name, pin in pins.items():
        path = stage.safe_path(root, name)
        identity, digest = _digest(path)
        if (identity[2] != pin.size or digest != pin.sha256
                or (pin.mtime_ns is not None and identity[3] != pin.mtime_ns)):
            raise stage.Stop("INPUT_PIN:" + name)
        if previous is not None and previous[name] != identity:
            raise stage.Stop("INPUT_IDENTITY:" + name)
        snapshots[name] = identity
    chain = stage.load_public_pin_chain(root)
    for name, expected in chain.items():
        pin = pins[name]
        if (pin.sha256 != expected["sha256"]
                or ("bytes" in expected and pin.size != expected["bytes"])
                or ("mtime_ns" in expected and pin.mtime_ns != expected["mtime_ns"])):
            raise stage.Stop("ACCEPTED_CHAIN_PIN:" + name)
    for name, (size, digest) in stage.BOOTSTRAP_PINS.items():
        if pins[name].size != size or pins[name].sha256 != digest:
            raise stage.Stop("BOOTSTRAP_PIN:" + name)
    return snapshots


def _exclusive(root, name):
    path = stage.safe_path(root, name, exists=False)
    descriptor = os.open(path, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
    return os.fdopen(descriptor, "w+b")


def _artifact_identity(root, name, identity, size):
    path = stage.safe_path(root, name)
    info = os.stat(path)
    if ((info.st_dev, info.st_ino) != identity[:2]
            or info.st_size != size or info.st_nlink != 1):
        raise stage.Stop("ARTIFACT_IDENTITY:" + name)
    return path


def _create_disks(root):
    identities = {}
    with _exclusive(root, stage.SCRIPT_DISK) as script:
        data = stage.render_script_disk()
        if len(data) != 4096 or script.write(data) != len(data):
            raise stage.Stop("SCRIPT_WRITE")
        script.flush()
        os.fsync(script.fileno())
        identities[stage.SCRIPT_DISK] = _identity(os.fstat(script.fileno()))
    with _exclusive(root, stage.OUTPUT) as output:
        block = bytes(stage.MIB)
        remaining = stage.OUTPUT_BYTES
        while remaining:
            part = block[:min(len(block), remaining)]
            if output.write(part) != len(part):
                raise stage.Stop("OUTPUT_WRITE")
            remaining -= len(part)
        output.flush()
        os.fsync(output.fileno())
        identities[stage.OUTPUT] = _identity(os.fstat(output.fileno()))
    return identities


def _validate_serial(serial):
    """Qwen draft, corrected to reject conflicting values for every prefix.

    Guest labels provide bounded diagnostics only; every failure still rejects.
    """
    if type(serial) is not bytes or len(serial) > PROFILE["log_bytes"]:
        raise stage.Stop("SERIAL_BOUND")
    lines = serial.splitlines()
    prefix = b"PUBLIC_STAGE_R7_CHECK_FAIL="
    failures = [line for line in lines if line.startswith(prefix)]
    if failures:
        if len(failures) == 1:
            label = failures[0][len(prefix):]
            if re.fullmatch(rb"[A-Z][A-Z0-9_]{0,63}", label):
                raise stage.Stop("SERIAL_CHECK_FAIL:" + label.decode("ascii"))
        raise stage.Stop("SERIAL_CHECK_FAIL")
    for prefix, expected in ((b"PUBLIC_STAGE_R7_LIVE=", stage.LIVE),
                             (b"PUBLIC_STAGE_R7_STATUS=", stage.SUCCESS),
                             (b"PUBLIC_STAGE_R7_EXIT=", stage.EXIT)):
        if [line for line in lines if line.startswith(prefix)] != [expected]:
            raise stage.Stop("SERIAL_STATUS")
    if not lines.index(stage.LIVE) < lines.index(stage.SUCCESS) < lines.index(stage.EXIT):
        raise stage.Stop("SERIAL_STATUS_ORDER")


def _run(root, log):
    """One owned child, bounded nonblocking reads, no process-name cleanup."""
    argv = stage.qemu_argv(root)
    stage.validate_argv(argv, root)
    env = {key: os.environ[key] for key in ("SystemRoot", "WINDIR") if key in os.environ}
    child = subprocess.Popen(argv, cwd=root, env=env, stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             bufsize=0, shell=False, close_fds=True)
    owner_pid, owner_args = child.pid, tuple(child.args)
    serial = bytearray()
    deadline = time.monotonic() + PROFILE["seconds"]
    eof = False
    last_write = None

    def owned():
        if child.pid != owner_pid or tuple(child.args) != owner_args:
            raise stage.Stop("PROCESS_IDENTITY")

    def pump():
        nonlocal eof
        owned()
        if time.monotonic() >= deadline:
            raise stage.Stop("TIMEOUT")
        try:
            block = os.read(child.stdout.fileno(), 4096)
        except BlockingIOError:
            block = None
        if block == b"":
            eof = True
        if block:
            if len(serial) + len(block) > PROFILE["log_bytes"]:
                raise stage.Stop("LOG_OVERFLOW")
            serial.extend(block)
            if log.write(block) != len(block):
                raise stage.Stop("LOG_WRITE")
            log.flush()
        return bool(block)

    def send(command, before_first_write=None):
        nonlocal last_write
        owned()
        if child.poll() is not None:
            raise stage.Stop("PROCESS_EARLY_EXIT")
        for offset in range(0, len(command), 4):
            while last_write is not None and time.monotonic() - last_write < 0.2:
                pump()
                time.sleep(0.02)
            pump()
            if child.poll() is not None:
                raise stage.Stop("PROCESS_EARLY_EXIT")
            if offset == 0 and before_first_write is not None:
                if before_first_write() is not True:
                    raise stage.Stop("TERMINAL_HANDSHAKE")
            block = command[offset:offset + 4]
            if child.stdin.write(block) != len(block):
                raise stage.Stop("SERIAL_WRITE")
            child.stdin.flush()
            last_write = time.monotonic()

    def wait_for(predicate, allow_exit=False):
        while not predicate():
            pump()
            if not allow_exit and child.poll() is not None and not predicate():
                raise stage.Stop("PROCESS_EARLY_EXIT")
            if eof and not predicate() and not allow_exit:
                raise stage.Stop("SERIAL_EOF")
            time.sleep(0.02)

    def exact_echo(command, start):
        expected = command.replace(b"\r", b"")
        wait_for(lambda: b"\n" in bytes(serial[start:]).replace(b"\r", b""))
        actual = bytes(serial[start:]).replace(b"\r", b"").split(b"\n", 1)[0] + b"\n"
        if actual != expected:
            raise stage.Stop("SERIAL_ECHO")

    def prompt():
        # The observed Alpine initial prompt appends exactly one DSR request.
        # Do not strip general ANSI/control sequences or accept other suffixes.
        suffix = rb"(?:\x1b\[6n)?"
        return re.search(rb"(?:^|\n)[^\r\n\x1b]*[~/:]# " + suffix + rb"$",
                         bytes(serial)) is not None

    try:
        os.set_blocking(child.stdout.fileno(), False)
        wait_for(lambda: bytes(serial).endswith(b"login: "))
        start = len(serial)
        send(b"root\n")
        exact_echo(b"root\n", start)
        wait_for(prompt)
        # Leave the interactive line editor using only a short exact command.
        # No prompt, DSR, error or other suffix is permitted after this echo.
        start = len(serial)
        send(TERMINAL_HANDSHAKE)
        exact_echo(TERMINAL_HANDSHAKE, start)
        exec_end = start + bytes(serial[start:]).index(b"\n") + 1

        def after_exec():
            if bytes(serial[exec_end:]):
                raise stage.Stop("TERMINAL_HANDSHAKE")
            return True

        after_exec()
        start = len(serial)
        send(READY_COMMAND, before_first_write=after_exec)
        exact_echo(READY_COMMAND, start)
        ready_start = start + bytes(serial[start:]).index(b"\n") + 1
        expected_ready = READY_MARKER + b"\n"

        def ready_barrier():
            # Retain only the existing CRLF normalization, never ANSI stripping.
            # Exactly one fixed READY line and no suffix is the roundtrip proof.
            tail = bytes(serial[ready_start:]).replace(b"\r", b"")
            if not expected_ready.startswith(tail):
                raise stage.Stop("TERMINAL_HANDSHAKE")
            return tail == expected_ready

        wait_for(ready_barrier)
        start = len(serial)
        command = stage.serial_command().encode("ascii") + b"\n"
        # Recheck after send()'s pre-write read and before its first long byte.
        send(command, before_first_write=ready_barrier)
        exact_echo(command, start)
        # The fixed guest script owns sync, unmount, markers and poweroff -f.
        # A process may exit while pipe bytes remain, or EOF may precede exit.
        # Drain through BOTH conditions before accepting its exact markers.
        wait_for(lambda: child.poll() is not None and eof, allow_exit=True)
        code = child.wait(timeout=PROFILE["cleanup_seconds"])
        if type(code) is not int or code != 0:
            raise stage.Stop("QEMU_EXIT")
        _validate_serial(bytes(serial))
        return bytes(serial), code
    finally:
        # Popen methods target its owned OS process handle; never kill by name/PID lookup.
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=PROFILE["cleanup_seconds"])
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=PROFILE["cleanup_seconds"])
        child.stdin.close()
        child.stdout.close()
        if child.poll() is None:
            raise stage.Stop("PROCESS_NOT_CLOSED")


def _read_output(root, identities):
    path = _artifact_identity(root, stage.OUTPUT, identities[stage.OUTPUT], stage.OUTPUT_BYTES)
    before = _identity(os.stat(path))
    with open(path, "rb") as source:
        if _identity(os.fstat(source.fileno())) != before:
            raise stage.Stop("OUTPUT_IDENTITY")
        data = source.read(stage.OUTPUT_BYTES + 1)
        if _identity(os.fstat(source.fileno())) != before:
            raise stage.Stop("OUTPUT_IDENTITY")
    if _identity(os.stat(path)) != before:
        raise stage.Stop("OUTPUT_IDENTITY")
    return data


def execute(root, admission=None):
    """Single explicit admitted operation. No retries; preserve diagnostics on failure."""
    root, pins = _admit(root, admission)
    pre = _verify_inputs(root, pins)
    report = {"mode": stage.MODE, "public_only": True, "restore_acceptance": False,
              "installed_boot_acceptance": False, "status": "FAILED",
              "profile_sha256": PROFILE_SHA256, "input_pins": {p.name: p.sha256 for p in pins.values()},
              "post_pins_verified": False, "clean_closeout": False,
              "diagnostics_preserved": True}
    result_name, log_name = stage.OUTPUT_NAMES[3], stage.OUTPUT_NAMES[2]
    post_attempted = False
    with _exclusive(root, result_name) as result:
        try:
            with _exclusive(root, log_name) as log:
                identities = _create_disks(root)
                _verify_inputs(root, pins, pre)
                script_path = _artifact_identity(root, stage.SCRIPT_DISK,
                                                identities[stage.SCRIPT_DISK], 4096)
                if _digest(script_path)[1] != stage.sha256(stage.render_script_disk()):
                    raise stage.Stop("SCRIPT_PIN")
                _artifact_identity(root, stage.OUTPUT, identities[stage.OUTPUT], stage.OUTPUT_BYTES)
                serial, exit_code = _run(root, log)
                report["clean_closeout"] = True
            post_attempted = True
            _verify_inputs(root, pins, pre)
            report["post_pins_verified"] = True
            _artifact_identity(root, stage.SCRIPT_DISK, identities[stage.SCRIPT_DISK], 4096)
            if _digest(script_path)[1] != stage.sha256(stage.render_script_disk()):
                raise stage.Stop("SCRIPT_POST_PIN")
            artifacts = stage.parse_output(_read_output(root, identities), serial, exit_code)
            # Nothing is extracted until clean closeout, postpins and parser acceptance.
            for name, data in zip(stage.OUTPUT_NAMES[4:], (artifacts.kernel, artifacts.initramfs)):
                with _exclusive(root, name) as target:
                    if target.write(data) != len(data):
                        raise stage.Stop("EXTRACTION_WRITE")
                    target.flush()
                    os.fsync(target.fileno())
            report.update(status="PUBLIC_STAGE_ONLY_OK", kernel_sha256=artifacts.kernel_sha256,
                          initramfs_sha256=artifacts.initramfs_sha256)
        except Exception as error:
            report["error"] = str(error) if isinstance(error, stage.Stop) else type(error).__name__
            # A failed run still rechecks inputs; no extraction or retry follows.
            if not post_attempted:
                try:
                    _verify_inputs(root, pins, pre)
                    report["post_pins_verified"] = True
                except Exception as post_error:
                    report["post_pin_error"] = str(post_error) if isinstance(post_error, stage.Stop) else type(post_error).__name__
        finally:
            result.write(json.dumps(report, sort_keys=True, indent=2).encode("ascii"))
            result.flush()
            os.fsync(result.fileno())
    return report


if __name__ == "__main__":
    raise SystemExit("NOT_ADMITTED: CLI cannot execute; root-owned hash-bound Admission required")

