"""Public ISO -> read-only installed /boot extraction PREPARATION ONLY.

No launch, image creation, extraction writes, or admission is implemented. Root
must bind an accepted public base/tool pin manifest and review an executor.
Import, CLI, and synthetic parsing cannot start processes or mutate images.
"""
from dataclasses import dataclass
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import stat

MODE = "PUBLIC_INSTALLED_BOOT_STAGE_R7"
STATUS = "NOT_ADMITTED"
MIB = 1024 * 1024
OUTPUT_BYTES = 64 * MIB
SCRIPT_BYTES = 4096
LIVE_VERSION = "6.18.52-0-virt"
INSTALLED_VERSION = "6.18.56-0-virt"
BOOT_UUID = "942cf962-dfdd-45a9-a423-f1cd90f9d2e6"
APPEND = "modules=loop,squashfs,sd-mod,usb-storage console=ttyS0,115200"
ISO = "alpine-virt-3.24.2-x86_64.iso"
KERNEL = "bootstrap-kernel/boot/vmlinuz-virt"
INITRAMFS = "bootstrap-kernel/boot/initramfs-virt"
BASE = "restore-guest.qcow2"
TOOL = "qemu-test-tools/qemu-system-x86_64.exe"
SCRIPT_DISK = "public-installed-boot-stage-r7-script.raw"
OUTPUT = "public-installed-boot-stage-r7-output.raw"
OUTPUT_NAMES = (SCRIPT_DISK, OUTPUT, "public-installed-boot-stage-r7-serial.log",
                "PUBLIC-INSTALLED-BOOT-STAGE-R7-RESULT.json",
                "public-installed-boot-stage-r7-vmlinuz-virt",
                "public-installed-boot-stage-r7-initramfs-virt")
BOOTSTRAP_PINS = {
    ISO: (69206016, "3ab424762af704b2c2a9e57df1dc37f982af260071504d977f2fb96822e7130b"),
    KERNEL: (12608512, "40f620bc8c93d952e57dd8dfc0f94fca1759d192a4fc4a260705d50ca378559c"),
    INITRAMFS: (9840259, "7ec8c3fa13403a4e0f08cca6991230147b134198e9ed726964afaddb52be6eaf"),
}
MAGIC = b"PUBLIC_INSTALLED_BOOT_STAGE_R7\n"
SUCCESS = b"PUBLIC_STAGE_R7_STATUS=OK"
EXIT = b"PUBLIC_STAGE_R7_EXIT=0"
LIVE = b"PUBLIC_STAGE_R7_LIVE=6.18.52-0-virt"
HEADER = re.compile(
    rb"PUBLIC_INSTALLED_BOOT_STAGE_R7\n"
    rb"kernel_bytes=([1-9][0-9]*)\nkernel_sha256=([0-9a-f]{64})\n"
    rb"initramfs_bytes=([1-9][0-9]*)\ninitramfs_sha256=([0-9a-f]{64})\nEND\n")
ACCEPTED_FREEZE_SHA = "c72615ba91414476d901eb21ab0d75f9ab00b14b40e7f492e72296cfea54e987"
ACCEPTED_DRIVER_SHA = "6827af15c1e8b5ce259f94bf5799cf68611f20664d5fa3f4b59d578b27383a71"
PIN_RESULT = "NATIVE-ADMISSION-PUBLIC-LINUX-R13-NOAPIC-RESULT.json"
PIN_FREEZE = "NATIVE-PUBLIC-LINUX-R13-DRIVER-FREEZE.json"
PIN_DRIVER = "public_linux_r13_driver.py"


INVENTORY_PROBE = b"check=BLOCK_INVENTORY_DIAGNOSTIC\ncount=0\nfor probe in /sys/block/*; do\n  count=$((count + 1))\n  if [ \"$count\" -gt 32 ]; then\n    exit 1\n  fi\n  name=${probe##*/}\n  sectors=$(cat \"$probe/size\")\n  ro=$(cat \"$probe/ro\")\n  if [ -e \"$probe/loop/backing_file\" ] || [ -L \"$probe/loop/backing_file\" ]; then\n    backing=1\n  else\n    backing=0\n  fi\n  printf 'PUBLIC_STAGE_R7_DEVICE=%s,%s,%s,%s\\n' \"$name\" \"$sectors\" \"$ro\" \"$backing\"\ndone\necho 'PUBLIC_STAGE_R7_DEVICE_END'\n"


class Stop(ValueError):
    """Fail-closed preparation or untrusted-result rejection."""


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def render_guest_script():
    """Fixed ASCII public script, never source-root mount or source execution."""
    zero_hash = sha256(bytes(OUTPUT_BYTES))
    script = f'''#!/bin/sh
set -eu
b=/run/public-installed-boot-stage-r7
mounted=0
check=SCRIPT_START
finish() {{
 e=$?
 trap - EXIT
 sync || {{ if [ "$e" = 0 ]; then check=CLEANUP_SYNC; fi; e=1; }}
 if [ "$mounted" = 1 ]; then umount "$b" || {{ if [ "$e" = 0 ]; then check=CLEANUP_UNMOUNT; fi; e=1; }}; fi
 if [ "$e" = 0 ]; then echo PUBLIC_STAGE_R7_STATUS=OK; else echo PUBLIC_STAGE_R7_CHECK_FAIL=$check; echo PUBLIC_STAGE_R7_STATUS=FAIL; fi
 echo PUBLIC_STAGE_R7_EXIT=$e
 poweroff -f
 exit "$e"
}}
trap finish EXIT
check=LIVE_VERSION
[ "$(uname -r)" = "{LIVE_VERSION}" ]
echo PUBLIC_STAGE_R7_LIVE={LIVE_VERSION}
check=VDA_SIZE
[ "$(cat /sys/block/vda/size)" = 12582912 ]
check=VDA_READ_ONLY
[ "$(cat /sys/block/vda/ro)" = 1 ]
check=VDB_SIZE
[ "$(cat /sys/block/vdb/size)" = 8 ]
check=VDB_READ_ONLY
[ "$(cat /sys/block/vdb/ro)" = 1 ]
check=VDC_SIZE
[ "$(cat /sys/block/vdc/size)" = 131072 ]
check=VDC_READ_WRITE
[ "$(cat /sys/block/vdc/ro)" = 0 ]
check=NETWORK_INTERFACE_SET
[ "$(ls /sys/class/net)" = lo ]
check=IPV4_ROUTE_SET
r=$(ip route); [ -z "$r" ]
check=IPV6_DEFAULT_ROUTE
r=$(ip -6 route show default); [ -z "$r" ]
for d in /sys/block/*; do
 check=BLOCK_DEVICE_SET
 case "${{d##*/}}" in
 vda|vdb|vdc) ;;
 sr0|loop0) check=BLOCK_DEVICE_READ_ONLY; [ "$(cat "$d/ro")" = 1 ] ;;
 *) exit 1 ;;
 esac
done
for d in /sys/class/block/*; do
 check=CLASS_BLOCK_SET
 case "${{d##*/}}" in vda|vda1|vda2|vdb|vdc|sr0|loop0) ;; *) exit 1 ;; esac
done
check=SOURCE_ALREADY_MOUNTED
if grep -q '^/dev/vda' /proc/mounts; then exit 1; fi
check=OUTPUT_NOT_ZERO
set -- $(sha256sum /dev/vdc)
[ "$1" = "{zero_hash}" ]
check=MOUNTPOINT_ABSENT
[ ! -e "$b" ]
check=MOUNTPOINT_CREATE
mkdir -m 700 "$b"
check=BOOT_UUID
blkid /dev/vda1 | grep -q ' UUID="{BOOT_UUID}"'
check=SOURCE_MOUNT
mount -t ext4 -o ro,noload /dev/vda1 "$b"
mounted=1
check=KERNEL_REGULAR
[ -f "$b/vmlinuz-virt" ]
check=KERNEL_NOT_SYMLINK
[ ! -L "$b/vmlinuz-virt" ]
check=INITRAMFS_REGULAR
[ -f "$b/initramfs-virt" ]
check=INITRAMFS_NOT_SYMLINK
[ ! -L "$b/initramfs-virt" ]
check=KERNEL_SIZE
k=$(wc -c < "$b/vmlinuz-virt")
check=INITRAMFS_SIZE
i=$(wc -c < "$b/initramfs-virt")
check=KERNEL_SIZE_POSITIVE
[ "$k" -gt 0 ]
check=KERNEL_SIZE_BOUND
[ "$k" -le 15728640 ]
check=INITRAMFS_SIZE_POSITIVE
[ "$i" -gt 0 ]
check=INITRAMFS_SIZE_BOUND
[ "$i" -le 49283072 ]
check=KERNEL_HASH
set -- $(sha256sum "$b/vmlinuz-virt"); kh=$1
check=INITRAMFS_HASH
set -- $(sha256sum "$b/initramfs-virt"); ih=$1
check=KERNEL_COPY
dd if="$b/vmlinuz-virt" of=/dev/vdc bs=1048576 seek=1 count=15 conv=notrunc
check=INITRAMFS_COPY
dd if="$b/initramfs-virt" of=/dev/vdc bs=1048576 seek=16 count=47 conv=notrunc
check=HEADER_CREATE
printf 'PUBLIC_INSTALLED_BOOT_STAGE_R7\\nkernel_bytes=%s\\nkernel_sha256=%s\\ninitramfs_bytes=%s\\ninitramfs_sha256=%s\\nEND\\n' "$k" "$kh" "$i" "$ih" > "$b-header"
check=HEADER_COPY
dd if="$b-header" of=/dev/vdc bs=4096 count=1 conv=sync,notrunc
'''.encode("ascii")
    anchor = b"for d in /sys/block/*; do\n check=BLOCK_DEVICE_SET\n"
    if script.count(anchor) != 1:
        raise Stop("INVENTORY_INSERTION_POINT")
    script = script.replace(anchor, INVENTORY_PROBE + anchor, 1)
    if len(script) > SCRIPT_BYTES:
        raise Stop("SCRIPT_TOO_LARGE")
    return script


def render_script_disk():
    """Return bytes only. Caller must exclusively create the reviewed raw input."""
    return render_guest_script().ljust(SCRIPT_BYTES, b"\0")


def serial_command():
    """Future executor must verify exact echo, pace four chars / >=200 ms."""
    script = render_guest_script()
    return (f"dd if=/dev/vdb of=/run/public-stage-r3.sh bs=1 count={len(script)}"
            f" && echo '{sha256(script)}  /run/public-stage-r3.sh' | sha256sum -c -"
            " && sh /run/public-stage-r3.sh")


def _root(root):
    root = Path(root)
    if not root.is_absolute() or ".." in root.parts or re.search(r"[,=\r\n\0]", str(root)):
        raise Stop("ROOT_PATH")
    return root


def safe_path(root, relative, exists=True):
    """No symlink/reparse components, path traversal, special files or escape."""
    root = _root(root)
    rel = Path(relative)
    if rel.is_absolute() or ".." in rel.parts or re.search(r"[,=\r\n\0]", str(rel)):
        raise Stop("INPUT_PATH")
    path = root / rel
    for item in (*reversed(path.parents), path):
        if not os.path.lexists(item):
            if item != path or exists:
                raise Stop("PATH_MISSING")
            continue
        info = os.lstat(item)
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise Stop("PATH_REPARSE")
        if item == path and not stat.S_ISREG(info.st_mode):
            raise Stop("NOT_REGULAR_FILE")
    return path


def check_paths(root):
    """Read-only existence/freshness checks, not input identity admission."""
    for name in (BASE, TOOL, ISO, KERNEL, INITRAMFS):
        safe_path(root, name)
    for name in OUTPUT_NAMES:
        target = safe_path(root, name, exists=False)
        if os.path.lexists(target):
            raise Stop("STALE_OUTPUT")


def _json(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise Stop("PIN_DUPLICATE")
            result[key] = value
        return result
    try:
        return json.loads(data, object_pairs_hook=unique)
    except (UnicodeError, json.JSONDecodeError) as error:
        raise Stop("PIN_JSON") from error


def parse_public_pin_chain(result_data, freeze_data, driver_data):
    """Accepted R13 operation -> frozen manifest -> literal pins; never import.

    Trust anchors were independently verified by root, not learned from files.
    This resolves expected identities, but DOES NOT hash or admit actual images.
    """
    result, freeze = _json(result_data), _json(freeze_data)
    claimed = result.get("rootAdmissionFreezeSha256") if isinstance(result, dict) else None
    if not isinstance(claimed, str) or claimed.lower() != ACCEPTED_FREEZE_SHA:
        raise Stop("PIN_RESULT_BINDING")
    if sha256(freeze_data) != ACCEPTED_FREEZE_SHA or sha256(driver_data) != ACCEPTED_DRIVER_SHA:
        raise Stop("PIN_CHAIN_HASH")
    if not isinstance(freeze, dict) or not isinstance(freeze.get("files"), list):
        raise Stop("PIN_FREEZE_SCHEMA")
    entries = [e for e in freeze["files"] if isinstance(e, dict) and e.get("Path") == PIN_DRIVER]
    if len(entries) != 1 or entries[0].get("Sha256", "").lower() != ACCEPTED_DRIVER_SHA or entries[0].get("Bytes") != len(driver_data):
        raise Stop("PIN_DRIVER_BINDING")
    tree = ast.parse(driver_data)
    values = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in {"BASE_SHA", "BASE_SIZE", "BASE_MTIME_NS"}:
                values[node.targets[0].id] = ast.literal_eval(node.value)
    tools = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Tuple) and len(node.elts) == 2:
            if all(isinstance(part, ast.Constant) and isinstance(part.value, str) for part in node.elts):
                name, digest = (part.value for part in node.elts)
                if name == "qemu-system-x86_64.exe":
                    tools.append(digest.lower())
    if set(values) != {"BASE_SHA", "BASE_SIZE", "BASE_MTIME_NS"} or len(tools) != 1:
        raise Stop("PIN_LITERAL_SCHEMA")
    if any(type(values[key]) is not int or values[key] <= 0 for key in ("BASE_SIZE", "BASE_MTIME_NS")):
        raise Stop("PIN_LITERAL_SIZE")
    if not isinstance(values["BASE_SHA"], str) or not re.fullmatch(r"[0-9a-f]{64}", values["BASE_SHA"]) or not re.fullmatch(r"[0-9a-f]{64}", tools[0]):
        raise Stop("PIN_LITERAL_HASH")
    return {BASE: {"sha256": values["BASE_SHA"], "bytes": values["BASE_SIZE"],
                   "mtime_ns": values["BASE_MTIME_NS"]}, TOOL: {"sha256": tools[0]}}


def load_public_pin_chain(root):
    return parse_public_pin_chain(*(safe_path(root, name).read_bytes()
                                    for name in (PIN_RESULT, PIN_FREEZE, PIN_DRIVER)))


def qemu_argv(root):
    """Render ONLY; this does not verify pins, create images, or launch QEMU."""
    root = _root(root)
    p = lambda name: (root / name).as_posix()
    return [str(root / TOOL), "-machine", "pc", "-accel", "tcg,thread=single",
            "-cpu", "qemu64", "-smp", "2", "-m", "2048", "-nodefaults",
            "-no-user-config",
            "-display", "none", "-monitor", "none", "-serial", "stdio",
            "-nic", "none", "-no-reboot", "-kernel", p(KERNEL), "-initrd", p(INITRAMFS),
            "-append", APPEND, "-boot", "d",
            "-drive", f"file={p(ISO)},format=raw,media=cdrom,if=ide,readonly=on",
            "-drive", f"file={p(BASE)},format=qcow2,if=virtio,readonly=on",
            "-drive", f"file={p(SCRIPT_DISK)},format=raw,if=virtio,readonly=on",
            "-drive", f"file={p(OUTPUT)},format=raw,if=virtio"]


def validate_argv(argv, root):
    if type(argv) is not list or argv != qemu_argv(root):
        raise Stop("TOPOLOGY")


def render_manifest(root):
    script = render_guest_script()
    return {"mode": MODE, "status": STATUS, "public_only": True,
            "restore_acceptance": False, "execution_implemented": False,
            "base_tool_pins": {"result": PIN_RESULT, "freeze": PIN_FREEZE,
                               "freeze_sha256": ACCEPTED_FREEZE_SHA, "source": PIN_DRIVER,
                               "source_sha256": ACCEPTED_DRIVER_SHA,
                               "actual_input_reverification": "PENDING_ROOT_ADMISSION"},
            "argv": qemu_argv(root), "append_evidence": "bootstrap-install-retry.log",
            "bootstrap_pins": BOOTSTRAP_PINS,
            "script_bytes": len(script), "script_sha256": sha256(script),
            "script_disk_bytes": SCRIPT_BYTES, "script_disk_sha256": sha256(render_script_disk()),
            "output_bytes": OUTPUT_BYTES, "fresh_output_names": OUTPUT_NAMES,
            "serial": {"write_characters": 4, "minimum_interval_seconds": 0.2,
                       "maximum_log_bytes": 4 * MIB, "maximum_seconds": 600,
                       "exact_login_echo_required": True, "exact_command_echo_required": True},
            "pending": ["root input pin binding and before/after file identity verification",
                        "exclusive output creation; zero-filled 64 MiB output",
                        "bounded serial login/command/status executor; no retries",
                        "owned process identity, timeout, clean shutdown and log closeout",
                        "exclusive known-path extraction only after accepted pinned result",
                        "installed 6.18.56 pair boot/module/runtime acceptance"]}


@dataclass(frozen=True)
class Artifacts:
    kernel: bytes
    initramfs: bytes
    kernel_sha256: str
    initramfs_sha256: str


def parse_output(data, serial, qemu_exit):
    """Validate an in-memory, synthetic or post-closeout raw output, no writes.

    Caller must first prove output-file identity/size, input pins and clean owned
    QEMU closeout. These parser checks alone are not an admitted/pinned result.
    """
    if type(qemu_exit) is not int or qemu_exit != 0:
        raise Stop("QEMU_EXIT")
    if type(serial) is not bytes or len(serial) > 4 * MIB:
        raise Stop("SERIAL_BOUND")
    lines = serial.splitlines()
    if any(line.startswith(b"PUBLIC_STAGE_R7_CHECK_FAIL=") for line in lines):
        raise Stop("SERIAL_CHECK_FAIL")
    for prefix, expected in ((b"PUBLIC_STAGE_R7_STATUS=", SUCCESS),
                             (b"PUBLIC_STAGE_R7_EXIT=", EXIT),
                             (b"PUBLIC_STAGE_R7_LIVE=", LIVE)):
        if [line for line in lines if line.startswith(prefix)] != [expected]:
            raise Stop("SERIAL_STATUS")
    if not lines.index(LIVE) < lines.index(SUCCESS) < lines.index(EXIT):
        raise Stop("SERIAL_STATUS_ORDER")
    if type(data) is not bytes or len(data) != OUTPUT_BYTES:
        raise Stop("OUTPUT_SIZE")
    match = HEADER.match(data[:4096])
    if not match or any(data[match.end():4096]):
        raise Stop("HEADER_SCHEMA")
    k, kh, i, ih = match.groups()
    if len(k) > 8 or len(i) > 8:
        raise Stop("HEADER_BOUNDS")
    k, i = int(k), int(i)
    if not 0 < k <= 15 * MIB or not 0 < i <= 47 * MIB:
        raise Stop("HEADER_BOUNDS")
    for start, end in ((4096, MIB), (MIB + k, 16 * MIB),
                       (16 * MIB + i, OUTPUT_BYTES)):
        if any(data[start:end]):
            raise Stop("OUTPUT_PADDING")
    kernel, initramfs = data[MIB:MIB+k], data[16*MIB:16*MIB+i]
    if sha256(kernel).encode() != kh or sha256(initramfs).encode() != ih:
        raise Stop("OUTPUT_HASH")
    return Artifacts(kernel, initramfs, kh.decode(), ih.decode())


if __name__ == "__main__":
    raise SystemExit("NOT_ADMITTED: preparation-only; no execution implemented")



