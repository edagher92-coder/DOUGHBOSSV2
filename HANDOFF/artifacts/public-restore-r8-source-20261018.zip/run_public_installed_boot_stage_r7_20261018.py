"""Root-callable R6 caller for the reviewed R6 public stage; imports are inert."""

PLAN = "PUBLIC-INSTALLED-BOOT-STAGE-R7-OPERATION-20261018.json"
CALLER = "run_public_installed_boot_stage_r7_20261018.py"
MODULE = "public_installed_boot_stage_r7.py"
EXECUTOR = "public_installed_boot_stage_executor_r7.py"
ACTUAL = "qemu-test-tools"


def require_interpreter():
    import sys
    if not (sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode):
        raise SystemExit("NOT_ADMITTED: interpreter requires -I -S -B")


def checked_root(root):
    import os
    import pathlib
    import stat
    root = pathlib.Path(root)
    if not root.is_absolute() or ".." in root.parts or any(c in str(root) for c in ",=\r\n\0"):
        raise RuntimeError("ROOT_PATH")
    for path in (*reversed(root.parents), root):
        info = os.lstat(path)
        if (not stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode)
                or getattr(info, "st_file_attributes", 0) & 0x400):
            raise RuntimeError("ROOT_NOT_PLAIN_DIRECTORY")
    return root


def checked_file(root, name):
    import os
    import pathlib
    import stat
    if (type(name) is not str or not name or "\\" in name or ":" in name
            or any(c in name for c in "\r\n\0") or any(p in ("", ".", "..") for p in name.split("/"))):
        raise RuntimeError("INPUT_PATH")
    relative = pathlib.Path(name)
    if relative.is_absolute():
        raise RuntimeError("INPUT_PATH")
    path = root / relative
    for part in (*reversed(path.parents), path):
        info = os.lstat(part)
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("PATH_REPARSE")
        if part == path:
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise RuntimeError("NOT_SINGLE_REGULAR_FILE")
        elif not stat.S_ISDIR(info.st_mode):
            raise RuntimeError("PATH_NOT_DIRECTORY")
    return path


def read_bound(root, name, expected):
    import hashlib
    import os
    import re
    if type(expected) is not str or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise RuntimeError("PIN_SCHEMA")
    path = checked_file(root, name)
    def identity(info):
        return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_nlink
    before = identity(os.lstat(path))
    with path.open("rb") as source:
        if identity(os.fstat(source.fileno())) != before:
            raise RuntimeError("INPUT_IDENTITY")
        data = source.read()
        if identity(os.fstat(source.fileno())) != before:
            raise RuntimeError("INPUT_IDENTITY")
    if identity(os.lstat(checked_file(root, name))) != before:
        raise RuntimeError("INPUT_IDENTITY")
    if hashlib.sha256(data).hexdigest() != expected:
        raise RuntimeError("CODE_OR_CHAIN_PIN:" + name)
    return data


def public_files(root, relative=ACTUAL):
    import os
    import stat
    base = root / relative
    info = os.lstat(base)
    if (not stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode)
            or getattr(info, "st_file_attributes", 0) & 0x400):
        raise RuntimeError("TOOL_ROOT_NOT_PLAIN_DIRECTORY")
    found = []
    def walk_error(error):
        raise error
    for directory, dirs, files in os.walk(base, followlinks=False, onerror=walk_error):
        for name in dirs + files:
            path = type(root)(directory) / name
            info = os.lstat(path)
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise RuntimeError("TOOL_REPARSE")
            if name in dirs and not stat.S_ISDIR(info.st_mode):
                raise RuntimeError("TOOL_NOT_PLAIN_DIRECTORY")
            if name in files:
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                    raise RuntimeError("TOOL_NOT_SINGLE_REGULAR_FILE")
                found.append(path.relative_to(base).as_posix())
    return sorted(found)


def load_verified(root, sources):
    import sys
    import types
    names = (MODULE[:-3], EXECUTOR[:-3])
    if any(name in sys.modules for name in names):
        raise RuntimeError("LOCAL_MODULE_PRELOADED")
    code = [compile(sources[name + ".py"], str(root / (name + ".py")), "exec", dont_inherit=True) for name in names]
    loaded = []
    try:
        for name, compiled in zip(names, code):
            module = types.ModuleType(name)
            module.__file__ = str(root / (name + ".py"))
            module.__package__ = ""
            sys.modules[name] = module
            loaded.append(module)
            exec(compiled, module.__dict__)
    except BaseException:
        for module in loaded:
            if sys.modules.get(module.__name__) is module:
                del sys.modules[module.__name__]
        raise
    return tuple(loaded)


def main():
    import sys
    require_interpreter()
    if len(sys.argv) != 2:
        raise SystemExit("NOT_ADMITTED: exact root operation-plan SHA-256 required")
    import json
    import pathlib
    root = checked_root(pathlib.Path.cwd())
    plan_bytes = read_bound(root, PLAN, sys.argv[1])
    plan = json.loads(plan_bytes)
    if (type(plan) is not dict or plan.get("operation_admission") != "OPERATION_ADMITTED_PUBLIC_ONLY"
            or plan.get("independent_operation_review") != "SHIP"):
        raise RuntimeError("NOT_ADMITTED")
    files = plan.get("files")
    if type(files) is not dict or not {CALLER, MODULE, EXECUTOR}.issubset(files):
        raise RuntimeError("BOUND_FILES_SCHEMA")
    sources = {name: read_bound(root, name, digest) for name, digest in files.items()}
    if pathlib.Path(__file__).absolute() != checked_file(root, CALLER):
        raise RuntimeError("CALLER_LOCATION")
    raw = read_bound(root, plan["tool_closure_receipt"], plan["tool_closure_receipt_sha256"])
    closure = json.loads(raw)
    rows = closure["pins"]
    if closure["status"] != "PUBLIC_TOOL_CLOSURE_MATCHED" or len(rows) != 3385:
        raise RuntimeError("TOOL_CLOSURE_SCHEMA")
    excluded = {"qemu-test-tools/share/QEMU,cgthree.bin", "qemu-test-tools/share/QEMU,tcx.bin"}
    if set(plan["non_profile_roms"]) != excluded:
        raise RuntimeError("EXCLUSION_PROFILE")
    by_name = {p["name"]: p for p in rows}
    if len(by_name) != len(rows):
        raise RuntimeError("DUPLICATE_CLOSURE_PIN")
    # Retain verified source bytes; neither a source reread nor a local .pyc loader is used.
    s, e = load_verified(root, sources)
    if s.qemu_argv(root) != plan["argv"] or e.PROFILE_SHA256 != plan["profile_sha256"]:
        raise RuntimeError("PROFILE_PIN")
    def check_inventory_and_non_profile_roms():
        actual = {ACTUAL + "/" + name for name in public_files(root)}
        if actual != set(by_name):
            raise RuntimeError("TOOL_INVENTORY_DRIFT")
        for name in sorted(excluded):
            identity, digest = e._digest(checked_file(root, name))
            p = by_name[name]
            if digest != p["sha256"] or identity[2] != p["size"] or identity[3] != p["mtime_ns"]:
                raise RuntimeError("NON_PROFILE_ROM_DRIFT")
    check_inventory_and_non_profile_roms()
    pins = {name: e.Pin(name, p["size"], p["sha256"], p["mtime_ns"]) for name, p in by_name.items() if name not in excluded}
    chain = s.load_public_pin_chain(root)
    for name in e.REQUIRED:
        if name in pins:
            if name in chain and pins[name].sha256 != chain[name]["sha256"]:
                raise RuntimeError("ACCEPTED_TOOL_PIN")
            continue
        size = checked_file(root, name).stat().st_size
        if name in chain:
            fact = chain[name]
            if size != fact["bytes"]:
                raise RuntimeError("ACCEPTED_BASE_SIZE")
            pins[name] = e.Pin(name, size, fact["sha256"], fact["mtime_ns"])
        elif name in s.BOOTSTRAP_PINS:
            expected_size, digest = s.BOOTSTRAP_PINS[name]
            if size != expected_size:
                raise RuntimeError("BOOTSTRAP_SIZE")
            pins[name] = e.Pin(name, size, digest)
        else:
            pins[name] = e.Pin(name, size, files[name])
    admission = e.Admission(str(root), files[e.EXECUTOR], files[e.MODULE], plan["profile_sha256"], tuple(pins.values()), e.APPROVAL, True)
    print("PUBLIC_STAGE_OPERATION_START", flush=True)
    operation_error = None
    try:
        result = e.execute(root, admission)
    except BaseException as error:
        operation_error = error
        raise
    finally:
        try:
            check_inventory_and_non_profile_roms()
        except BaseException as error:
            if operation_error is None:
                raise
            print("POST_OPERATION_CHECK_FAILED:" + type(error).__name__, file=sys.stderr)
    print(json.dumps({key: result.get(key) for key in ("status", "error", "clean_closeout", "post_pins_verified", "kernel_sha256", "initramfs_sha256")}), flush=True)
    sys.exit(0 if result.get("status") == "PUBLIC_STAGE_ONLY_OK" else 1)


if __name__ == "__main__":
    main()

