"""Synthetic-only caller checks: no real plan, VM, image tools, or private hashes."""
import builtins
import contextlib
import hashlib
import importlib.machinery
import importlib.util
import io
import json
import marshal
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).absolute().parent
CALLER = "run_public_installed_boot_stage_r8_20261018.py"
MODULE = "public_installed_boot_stage_r8.py"
EXECUTOR = "public_installed_boot_stage_executor_r8.py"


def read_caller(path):
    module = types.ModuleType("synthetic_r8_caller")
    module.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    return module


class CallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="synthetic-public-r8-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).absolute()
        self.names = (MODULE[:-3], EXECUTOR[:-3])
        self.previous = {name: sys.modules.pop(name, None) for name in self.names}
        self.addCleanup(self.clean_modules)
        for name in (CALLER, MODULE, EXECUTOR):
            (self.root / name).write_bytes((HERE / name).read_bytes())
        self.caller = read_caller(self.root / CALLER)
        self.sources = {name: (self.root / name).read_bytes() for name in (MODULE, EXECUTOR)}
        self.executions = []
        self.addCleanup(patch.stopall)
        patch("subprocess.Popen", side_effect=AssertionError("CHILD_FORBIDDEN")).start()
        patch("os.system", side_effect=AssertionError("CHILD_FORBIDDEN")).start()

    def clean_modules(self):
        for name, previous in self.previous.items():
            sys.modules.pop(name, None)
            if previous is not None:
                sys.modules[name] = previous

    def fixture(self):
        s, e = self.caller.load_verified(self.root, self.sources)
        argv, profile, required = s.qemu_argv(self.root), e.PROFILE_SHA256, e.REQUIRED
        self.chain = {}
        for name in required:
            path = self.root / name
            if not path.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"synthetic input only")
            info = path.stat()
            self.chain[name] = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                                "bytes": info.st_size, "mtime_ns": info.st_mtime_ns}
        rows = []
        excluded = ["qemu-test-tools/share/QEMU,cgthree.bin", "qemu-test-tools/share/QEMU,tcx.bin"]
        tool = "qemu-test-tools/qemu-system-x86_64.exe"
        for name in [tool, *excluded]:
            path = self.root / name
            if not path.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"synthetic public tool")
            info = path.stat()
            rows.append({"name": name, "size": info.st_size, "mtime_ns": info.st_mtime_ns,
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        for number in range(3385 - len(rows)):
            rows.append({"name": f"qemu-test-tools/synthetic-{number}.bin", "size": 0,
                         "mtime_ns": 1, "sha256": hashlib.sha256(b"").hexdigest()})
        raw = json.dumps({"status": "PUBLIC_TOOL_CLOSURE_MATCHED", "pins": rows}).encode()
        (self.root / "synthetic-closure.json").write_bytes(raw)
        self.inventory = [row["name"].removeprefix("qemu-test-tools/") for row in rows]
        self.plan = {"operation_admission": "OPERATION_ADMITTED_PUBLIC_ONLY",
                     "independent_operation_review": "SHIP",
                     "files": {name: hashlib.sha256((self.root / name).read_bytes()).hexdigest()
                               for name in (CALLER, MODULE, EXECUTOR)},
                     "tool_closure_receipt": "synthetic-closure.json",
                     "tool_closure_receipt_sha256": hashlib.sha256(raw).hexdigest(),
                     "argv": argv, "profile_sha256": profile, "non_profile_roms": excluded}
        for name in self.names:
            sys.modules.pop(name, None)
        original = self.caller.load_verified
        def synthetic_loader(root, sources):
            stage, executor = original(root, sources)
            stage.load_public_pin_chain = lambda root: self.chain
            def fake_execute(root, admission):
                self.executions.append(admission)
                return {"status": "PUBLIC_STAGE_ONLY_OK", "clean_closeout": True,
                        "post_pins_verified": True}
            executor.execute = fake_execute
            return stage, executor
        patch.object(self.caller, "load_verified", side_effect=synthetic_loader).start()
        patch.object(self.caller, "public_files", return_value=self.inventory).start()
        return s, e

    def invoke(self, plan=None):
        raw = json.dumps(self.plan if plan is None else plan).encode()
        (self.root / self.caller.PLAN).write_bytes(raw)
        digest = hashlib.sha256(raw).hexdigest()
        previous = Path.cwd()
        try:
            os.chdir(self.root)
            with patch.object(sys, "argv", [CALLER, digest]), contextlib.redirect_stdout(io.StringIO()):
                self.caller.main()
        finally:
            os.chdir(previous)

    def test_import_is_inert_even_when_imports_are_forbidden(self):
        source = (self.root / CALLER).read_bytes()
        with patch.object(builtins, "__import__", side_effect=AssertionError("IMPORT_FORBIDDEN")):
            exec(compile(source, CALLER, "exec"), {"__name__": "inert_import"})

    def test_each_missing_interpreter_flag_stops_before_plan_io(self):
        for missing in ("isolated", "no_site", "dont_write_bytecode"):
            values = dict(isolated=1, no_site=1, dont_write_bytecode=1)
            values[missing] = 0
            with self.subTest(missing=missing), patch.object(sys, "flags", types.SimpleNamespace(**values)), \
                    patch.object(self.caller, "read_bound", side_effect=AssertionError("PLAN_IO_FORBIDDEN")):
                with self.assertRaisesRegex(SystemExit, "-I -S -B"):
                    self.caller.main()

    def test_default_cli_has_no_admission_or_io(self):
        with patch.object(sys, "argv", [CALLER]), patch.object(self.caller, "read_bound", side_effect=AssertionError("IO_FORBIDDEN")):
            with self.assertRaisesRegex(SystemExit, "NOT_ADMITTED"):
                self.caller.main()

    def test_wrong_source_pin_stops_before_local_exec(self):
        self.fixture()
        self.plan["files"][MODULE] = "0" * 64
        with patch.object(self.caller, "load_verified", side_effect=AssertionError("EXEC_FORBIDDEN")):
            with self.assertRaisesRegex(RuntimeError, "CODE_OR_CHAIN_PIN"):
                self.invoke()
        self.assertEqual(self.executions, [])

    def test_missing_operation_admission_stops_before_local_exec(self):
        self.fixture()
        del self.plan["operation_admission"]
        with patch.object(self.caller, "load_verified", side_effect=AssertionError("EXEC_FORBIDDEN")):
            with self.assertRaisesRegex(RuntimeError, "NOT_ADMITTED"):
                self.invoke()

    def test_wrong_plan_pin_cannot_execute(self):
        (self.root / self.caller.PLAN).write_bytes(b"{}")
        previous = Path.cwd()
        try:
            os.chdir(self.root)
            with patch.object(sys, "argv", [CALLER, "0" * 64]):
                with self.assertRaisesRegex(RuntimeError, "CODE_OR_CHAIN_PIN"):
                    self.caller.main()
        finally:
            os.chdir(previous)

    def test_path_escape_and_hardlink_sources_are_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "INPUT_PATH"):
            self.caller.read_bound(self.root, "../outside.py", "0" * 64)
        linked = self.root / "linked.py"
        os.link(self.root / MODULE, linked)
        with self.assertRaisesRegex(RuntimeError, "NOT_SINGLE_REGULAR_FILE"):
            self.caller.read_bound(self.root, MODULE, hashlib.sha256(self.sources[MODULE]).hexdigest())

    def test_preloaded_stage_is_not_overwritten(self):
        for name in self.names:
            with self.subTest(name=name):
                prior = types.ModuleType(name)
                sys.modules[name] = prior
                with self.assertRaisesRegex(RuntimeError, "LOCAL_MODULE_PRELOADED"):
                    self.caller.load_verified(self.root, self.sources)
                self.assertIs(sys.modules[name], prior)
                del sys.modules[name]

    def test_loader_executes_retained_verified_bytes_not_changed_source_path(self):
        (self.root / MODULE).write_bytes(b"raise AssertionError('UNVERIFIED_REREAD')")
        stage, executor = self.caller.load_verified(self.root, self.sources)
        self.assertEqual(stage.MODE, "PUBLIC_INSTALLED_BOOT_STAGE_R8")
        self.assertIs(executor.stage, stage)

    def test_verified_loader_ignores_timestamp_and_sourceless_poison(self):
        poison = compile("raise AssertionError('POISON_EXECUTED')", "poison.py", "exec")
        for name in (MODULE, EXECUTOR):
            path = self.root / name
            info = path.stat()
            payload = importlib.util.MAGIC_NUMBER + struct.pack("<III", 0, int(info.st_mtime) & 0xffffffff, info.st_size) + marshal.dumps(poison)
            cache = Path(importlib.util.cache_from_source(str(path)))
            cache.parent.mkdir(exist_ok=True)
            cache.write_bytes(payload)
            path.with_suffix(".pyc").write_bytes(payload)
        original_import = builtins.__import__
        def guard(name, *args, **kwargs):
            if name in {"public_installed_boot_stage_r1", "public_installed_boot_stage_executor_r1",
                        "verify_public_qemu_tool_closure_20261017"}:
                raise AssertionError("OLD_LOCAL_IMPORT_FORBIDDEN")
            return original_import(name, *args, **kwargs)
        with patch.object(importlib.machinery.SourceFileLoader, "get_code", side_effect=AssertionError("SOURCE_IMPORT_FORBIDDEN")), \
                patch.object(importlib.machinery.SourcelessFileLoader, "get_code", side_effect=AssertionError("PYC_IMPORT_FORBIDDEN")), \
                patch.object(builtins, "__import__", side_effect=guard):
            stage, executor = self.caller.load_verified(self.root, self.sources)
        self.assertIs(executor.stage, stage)
        self.assertEqual(stage.MODE, "PUBLIC_INSTALLED_BOOT_STAGE_R8")
        self.assertEqual(executor.MODULE, MODULE)
        self.assertEqual(stage.__file__, str(self.root / MODULE))

    def test_full_caller_uses_frozen_r8_wiring_with_fake_execute(self):
        self.fixture()
        with self.assertRaises(SystemExit) as outcome:
            self.invoke()
        self.assertEqual(outcome.exception.code, 0)
        self.assertEqual(len(self.executions), 1)
        self.assertEqual(self.executions[0].profile_sha256, self.plan["profile_sha256"])
        self.assertEqual(self.executions[0].module_sha256, self.plan["files"][MODULE])
        self.assertEqual(self.executions[0].executor_sha256, self.plan["files"][EXECUTOR])

    def test_r8_profile_mismatch_stops_before_execute(self):
        self.fixture()
        self.plan["profile_sha256"] = "0" * 64
        with self.assertRaisesRegex(RuntimeError, "PROFILE_PIN"):
            self.invoke()
        self.assertEqual(self.executions, [])

    def test_r8_postcheck_does_not_hide_original_operation_exception(self):
        self.fixture()
        loader = self.caller.load_verified.side_effect
        def failing_loader(root, sources):
            stage, executor = loader(root, sources)
            executor.execute = lambda *args: (_ for _ in ()).throw(RuntimeError("original-operation"))
            return stage, executor
        with patch.object(self.caller, "load_verified", side_effect=failing_loader), \
                patch.object(self.caller, "public_files", side_effect=[self.inventory, self.inventory + ["added.dll"]]), \
                contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, "^original-operation$"):
                self.invoke()

    def test_post_operation_inventory_drift_is_not_success(self):
        self.fixture()
        with patch.object(self.caller, "public_files", side_effect=[self.inventory, self.inventory + ["added.dll"]]):
            with self.assertRaisesRegex(RuntimeError, "TOOL_INVENTORY_DRIFT"):
                self.invoke()
        self.assertEqual(len(self.executions), 1)

    def test_embedded_inventory_rejects_hardlinks_and_root_reparse(self):
        base = self.root / "qemu-test-tools"
        base.mkdir()
        (base / "one.bin").write_bytes(b"synthetic")
        self.assertEqual(self.caller.public_files(self.root), ["one.bin"])
        os.link(base / "one.bin", base / "two.bin")
        with self.assertRaisesRegex(RuntimeError, "TOOL_NOT_SINGLE_REGULAR_FILE"):
            self.caller.public_files(self.root)
        with patch("os.lstat", return_value=types.SimpleNamespace(st_mode=0o040755, st_file_attributes=0x400)):
            with self.assertRaisesRegex(RuntimeError, "TOOL_ROOT_NOT_PLAIN_DIRECTORY"):
                self.caller.public_files(self.root)


if __name__ == "__main__":
    unittest.main()
