"""Public-only integration of the exact R4 snapshot loader and closed writer.

No private input, native bind invocation, filesystem preparation or VM is used.
The session-control fixture demonstrates a classifier boundary, not private cause.
"""
import builtins
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import native_admission_binding_r4 as binding
import private_native_r4_contract_r1 as contract
from test_native_prefix_structure_r4 import schema, CONTROLS
from test_restore_preparer_native_r1 import SAVE, RESTORE

class BoundSnapshotIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        manifest = (HERE / "NATIVE-ADMISSION-PUBLIC-SOURCE-r4.json").read_bytes()
        assert hashlib.sha256(manifest).hexdigest() == "e9583a98a68c9ea021f8e0a4aa991301188eb2de2837f782de25894c809b51fa"
        pins = {row["Path"]: row["Sha256"].lower() for row in json.loads(manifest)["sourceFiles"]}
        names = ("native_source_preparation_r2.py", "restore_preparer_r3_indexed_r1.py",
                 "restore_preparer_native_r1.py", "native_prefix_reasons_r3.py",
                 "native_g056_structure_r1.py", "native_prefix_structure_r4.py",
                 "native_admission_binding_r4.py", "test_native_prefix_structure_r4.py",
                 "test_restore_preparer_native_r1.py", "private_native_r4_contract_r1.py")
        pins[names[-1]] = "478a3a174ee5688e82f3e9492e048bdbb42ecc8a4c8b00bf52d7416aa6c5438c"
        cls.snapshots = {name: (HERE / name).read_bytes() for name in names}
        assert all(hashlib.sha256(data).hexdigest() == pins[name] for name, data in cls.snapshots.items())
        cls.original_import = builtins.__import__
        cls.preparation = binding.module_snapshot(cls.snapshots[names[0]], "bound_preparation_wrapper", HERE / names[0])
        cls.base, cls.native = cls.preparation.load_dependencies(cls.snapshots[names[1]], cls.snapshots[names[2]])
        reasons = binding.diagnostic_snapshot(cls.snapshots[names[3]], "bound_native_reasons", HERE / names[3], {})
        structure = binding.diagnostic_snapshot(cls.snapshots[names[4]], "bound_native_structure", HERE / names[4],
                                                {"native_prefix_reasons_r3": reasons})
        cls.prefix = binding.diagnostic_snapshot(cls.snapshots[names[5]], "bound_native_prefix", HERE / names[5],
                                                 {"native_prefix_reasons_r3": reasons, "native_g056_structure_r1": structure})

    @classmethod
    def tearDownClass(cls):
        assert builtins.__import__ is cls.original_import
        assert all((HERE / name).read_bytes() == data for name, data in cls.snapshots.items())

    def capture(self, text):
        try:
            self.prefix.derive_native_prefix(text, self.base, self.native)
        except self.prefix.PrefixBindingError as error:
            self.assertEqual((error.stage, error.reason), ("NATIVE_PREFLIGHT", "G056"))
            return error
        self.fail("Expected synthetic G056")

    def encode(self, error):
        output = io.StringIO()
        with mock.patch.object(binding, "bind", side_effect=error) as bind, \
                mock.patch("subprocess.Popen", side_effect=AssertionError("forbidden")), \
                contextlib.redirect_stdout(output):
            code = binding.main(["--bind-native-admission-r4", "--builder-sha256", "0" * 64,
                                 "--prefix-sha256", "1" * 64])
        self.assertEqual(code, 1)
        bind.assert_called_once_with("0" * 64, "1" * 64, allowed=True)
        raw = output.getvalue().encode("ascii")
        result = contract.parse_binding(raw, code, b"")
        self.assertFalse(result["preparation_executed"] or result["database_started"] or result["application_boot_allowed"])
        return result, raw

    def test_snapshot_success_matches_the_accepted_r3_path(self):
        text = CONTROLS + schema()
        self.assertEqual(self.prefix.derive_native_prefix(text, self.base, self.native),
                         self.prefix.reasons.derive_native_prefix(text, self.base, self.native))

    def test_all_six_known_contexts_survive_exact_loader_and_writer(self):
        for context in ("INSERT_VALUE", "CREATE_DEFAULT"):
            for kind, token in (("WORD", "PUBLIC_WORD"), ("IDENT", "`PUBLIC_IDENT`"), ("SYMBOL", "(1)")):
                with self.subTest(context=context, kind=kind):
                    text = CONTROLS + schema()
                    if context == "INSERT_VALUE": text += "INSERT INTO synthetic_posts VALUES (" + token + ");"
                    else: text = text.replace("CREATE TABLE synthetic_posts (id int);",
                                              "CREATE TABLE synthetic_posts (id int DEFAULT " + token + ");")
                    result, raw = self.encode(self.capture(text))
                    self.assertEqual((result["structure_context"], result["token_kind"]), (context, kind))
                    self.assertNotIn(b"PUBLIC_WORD", raw)
                    self.assertNotIn(b"PUBLIC_IDENT", raw)

    def charset_scope(self, charset):
        return CONTROLS + schema().replace("CREATE TABLE synthetic_posts (id int);",
                   SAVE + "/*!40101 SET character_set_client=" + charset + " */;"
                   + "CREATE TABLE synthetic_posts (id int);" + RESTORE)

    def test_supported_session_control_remains_accepted(self):
        prefix, normalized, facts = self.prefix.derive_native_prefix(self.charset_scope("utf8mb4"), self.base, self.native)
        self.assertEqual(prefix, "synthetic_")
        self.assertIsInstance(normalized, str)
        self.assertIsInstance(facts, dict)

    def test_rejected_session_controls_remain_unclassified_without_grammar_change(self):
        for charset in ("utf8", "utf8mb3", "latin1"):
            with self.subTest(charset=charset):
                result, raw = self.encode(self.capture(self.charset_scope(charset)))
                self.assertEqual((result["structure_context"], result["token_kind"]), ("UNCLASSIFIED", "UNCLASSIFIED"))
                self.assertNotIn(b"character_set_client", raw)
                self.assertNotIn(charset.encode("ascii"), raw)

if __name__ == "__main__":
    unittest.main()
