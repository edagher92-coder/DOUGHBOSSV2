"""Synthetic source-byte checks only; this runner cannot admit a VM operation."""
import hashlib
import io
import json
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

ROOT = Path(r"C:\Codex\Temp\doughboss-linux-restore-20261014-9bd2e853")


def load(name, expected=None):
    path = ROOT / (name + ".py")
    source = path.read_bytes()
    if expected and hashlib.sha256(source).hexdigest() != expected:
        raise RuntimeError("SOURCE_PIN:" + name)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(source, str(path), "exec", dont_inherit=True), module.__dict__)
    return module


def main():
    assert sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode
    stage_tests = load("test_public_installed_boot_stage_r6",
                       "bed60ce8dc9c686626aef9a66d02ae85571233cfe5c8c44e8e6ca274f3f19327")
    if hashlib.sha256(Path(stage_tests.stage.__file__).read_bytes()).hexdigest() != "829d4a5f152a028df96818f61e167eee61a73ac3502f26859b88ceab75ff7dc3":
        raise RuntimeError("ACCEPTED_STAGE_PIN")
    load("public_installed_boot_stage_executor_r6")
    modules = [stage_tests, load("test_public_installed_boot_stage_executor_r6"),
               load("test_public_installed_boot_stage_caller_r6")]
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(m) for m in modules)
    stream = io.StringIO()
    with patch("subprocess.Popen", side_effect=AssertionError("REAL_CHILD_FORBIDDEN")), \
            patch("os.system", side_effect=AssertionError("REAL_CHILD_FORBIDDEN")):
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    print(stream.getvalue())
    report = {"tests": result.testsRun, "failures": len(result.failures),
              "errors": len(result.errors), "successful": result.wasSuccessful(),
              "scope": "synthetic source-byte integration; no VM or operation admission",
              "sha256": {n + ".py": hashlib.sha256((ROOT/(n+".py")).read_bytes()).hexdigest()
                         for n in ("public_installed_boot_stage_r6", "public_installed_boot_stage_executor_r6",
                                   "run_public_installed_boot_stage_r6_20261018",
                                   "test_public_installed_boot_stage_executor_r6", "test_public_installed_boot_stage_caller_r6")}}
    Path(__file__).with_name("integration-tests.log").write_text(stream.getvalue(), encoding="utf-8")
    Path(__file__).with_name("integration-tests.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
