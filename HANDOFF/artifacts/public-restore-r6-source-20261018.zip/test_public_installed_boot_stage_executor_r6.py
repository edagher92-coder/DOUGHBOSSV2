"""Mocked/synthetic checks only: no child, QEMU, images or real input hashes."""
import contextlib
import io
import json
from pathlib import Path
import runpy
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import public_installed_boot_stage_executor_r6 as executor
import public_installed_boot_stage_r6 as stage


class MemoryFile(io.BytesIO):
    def close(self):
        self.saved = self.getvalue()
        super().close()

    def fileno(self):
        return 123


class SyntheticChild:
    def __init__(self, argv, scenario="ok"):
        self.args, self.pid, self.scenario = argv, 1234, scenario
        self.code, self.pending, self.writes = None, bytearray(), []
        self.commands, self.line_echo, self.ready = [], False, False
        self.eof_sent, self.exit_polls = False, 0
        self.queue = [] if scenario == "timeout" else [b"alpine login: "]
        self.stdin = SimpleNamespace(write=self.write, flush=lambda: None, close=lambda: None)
        self.stdout = SimpleNamespace(fileno=lambda: 234, close=lambda: None)
        self.terminated = self.killed = False

    def write(self, data):
        self.writes.append(data)
        self.pending.extend(data)
        if self.pending.endswith(b"\n"):
            command = bytes(self.pending)
            self.pending.clear()
            self.commands.append(command)
            if command == b"root\n":
                self.queue.append(b"wrong\r\n" if self.scenario == "echo" else
                                  b"root\r\nlocalhost:~# \x1b[6n")
            elif command == b"export TERM=dumb\n":
                # Actual R1: TERM alone leaves the interactive DSR behavior on.
                self.queue.append(command.replace(b"\n", b"\r\n") + b"localhost:~# \x1b[6n")
            elif command == b"set +o emacs; export TERM=dumb\n":
                # Actual R2 error, not an assumed capability of this guest.
                self.queue.append(command.replace(b"\n", b"\r\n") +
                                  b"-sh: set: illegal option +o emacs\r\nlocalhost:~# \x1b[6n")
            elif command == executor.TERMINAL_HANDSHAKE:
                self.line_echo = True
                echo = command.replace(b"\n", b"\r\n")
                if self.scenario == "exec-echo":
                    echo = b"wrong-exec\r\n"
                suffix = {
                    "exec-error": b"-sh: exec: /bin/sh: invalid option +i\r\n",
                    "exec-prompt": b"localhost:~# ",
                    "exec-dsr": b"\x1b[6n",
                    "exec-prompt-dsr": b"localhost:~# \x1b[6n",
                    "exec-ansi": b"\x1b[0m",
                }.get(self.scenario, b"")
                self.queue.append(echo + suffix)
                if self.scenario == "exec-dsr-fragment":
                    self.queue.append(b"\x1b[6n")
                elif self.scenario == "exec-error-fragment":
                    self.queue.append(b"-sh: exec failed\r\n")
            elif command == executor.READY_COMMAND:
                if not self.line_echo:
                    raise AssertionError("READY_REQUIRES_LINE_ECHO_MODE")
                self.ready = True
                echo = command.replace(b"\n", b"\r\n")
                if self.scenario == "marker-echo":
                    echo = b"wrong-ready-command\r\n"
                ready = executor.READY_MARKER + b"\r\n"
                if self.scenario == "marker-error":
                    ready = b"-sh: printf: error\r\n"
                elif self.scenario == "marker-wrong":
                    ready = b"PUBLIC_STAGE_R6_NOT_READY\r\n"
                elif self.scenario == "marker-extra":
                    ready += b"unexpected\r\n"
                elif self.scenario == "marker-duplicate":
                    ready += ready
                elif self.scenario == "marker-prompt":
                    ready += b"localhost:~# "
                elif self.scenario == "marker-dsr":
                    ready += b"\x1b[6n"
                elif self.scenario == "marker-lf":
                    ready = executor.READY_MARKER + b"\n"
                self.queue.append(echo)
                if self.scenario == "marker-split":
                    self.queue.extend((ready[:5], ready[5:]))
                else:
                    self.queue.append(ready)
                if self.scenario == "marker-dsr-fragment":
                    self.queue.append(b"\x1b[6n")
                elif self.scenario == "marker-error-fragment":
                    self.queue.append(b"-sh: delayed error\r\n")
            elif command == b"poweroff\n":
                raise AssertionError("GUEST_SCRIPT_ALREADY_OWNS_POWEROFF")
            else:
                if not self.line_echo or not self.ready:
                    raise AssertionError("LONG_COMMAND_REQUIRES_LINE_ECHO_AND_READY")
                self.queue.append(command.replace(b"\n", b"\r\n") +
                                  b"\r\n".join((stage.LIVE, stage.SUCCESS, stage.EXIT)) +
                                  b"\r\n")
                if self.scenario == "guest-check-fail":
                    self.queue.append(b"PUBLIC_STAGE_R6_CHECK_FAIL=SOURCE_MOUNT\r\n")
                if self.scenario == "tail":
                    self.queue.append(b"shutdown diagnostic tail\r\n")
                if self.scenario != "eof-first":
                    self.code = 7 if self.scenario == "exit" else 0
        return len(data)

    def read(self, descriptor, count):
        if self.scenario == "identity":
            self.pid += 1
        if self.scenario == "overflow":
            return b"x" * 4096
        if self.queue:
            return self.queue.pop(0)
        if self.scenario == "eof-first" and self.ready and len(self.commands) == 4:
            self.eof_sent = True
            return b""
        if self.code is not None:
            return b""
        raise BlockingIOError

    def poll(self):
        if self.eof_sent and self.code is None:
            self.exit_polls += 1
            if self.exit_polls >= 3:
                self.code = 0
        return self.code

    def wait(self, timeout):
        if self.code is None:
            raise executor.subprocess.TimeoutExpired(self.args, timeout)
        return self.code

    def terminate(self):
        self.terminated = True
        self.code = -15

    def kill(self):
        self.killed = True
        self.code = -9


class ExecutorTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(executor.__file__).parent.absolute()
        self.forbid = patch("subprocess.Popen", side_effect=AssertionError("NO_CHILD"))
        self.forbid.start()
        self.addCleanup(self.forbid.stop)

    def admission(self, **changes):
        pins = tuple(executor.Pin(name, 1, "a" * 64) for name in executor.REQUIRED)
        fields = dict(root=str(self.root), executor_sha256="a" * 64,
                      module_sha256="a" * 64, profile_sha256=executor.PROFILE_SHA256,
                      pins=pins, approval=executor.APPROVAL, public_tool_closure_reviewed=True)
        fields.update(changes)
        return executor.Admission(**fields)

    def test_cli_rejects_without_process_or_output(self):
        with patch.object(executor, "_exclusive", side_effect=AssertionError("NO_WRITE")):
            with self.assertRaisesRegex(SystemExit, "NOT_ADMITTED"):
                runpy.run_path(executor.__file__, run_name="__main__")

    def test_no_implicit_admission(self):
        with self.assertRaisesRegex(stage.Stop, "NOT_ADMITTED"):
            executor.execute(self.root)

    def test_admission_profile_approval_and_closure(self):
        for changes in ({"profile_sha256": "bad"}, {"approval": "yes"},
                        {"public_tool_closure_reviewed": False}, {"root": "relative"}):
            with self.subTest(changes=changes), self.assertRaisesRegex(stage.Stop, "NOT_ADMITTED"):
                executor._admit(self.root, self.admission(**changes))

    def test_stale_output_rejected_before_any_writes(self):
        with patch.object(stage, "safe_path", side_effect=lambda r, n, exists=True: r / n):
            with patch.object(executor.os.path, "lexists", return_value=True):
                with self.assertRaisesRegex(stage.Stop, "STALE_OUTPUT"):
                    executor._admit(self.root, self.admission())

    def test_duplicate_pin_and_private_extra_rejected(self):
        pins = self.admission().pins
        for extra in (pins[0], executor.Pin("private-backup.tar", 1, "b" * 64)):
            with patch.object(stage, "safe_path", side_effect=lambda r, n, exists=True: r / n):
                with self.assertRaises(stage.Stop):
                    executor._admit(self.root, self.admission(pins=pins + (extra,)))

    def test_missing_and_code_binding_pins(self):
        with patch.object(stage, "safe_path", side_effect=lambda r, n, exists=True: r / n):
            for admission in (self.admission(pins=()), self.admission(executor_sha256="b" * 64)):
                with self.assertRaises(stage.Stop):
                    executor._admit(self.root, admission)

    def test_input_bad_hash_and_identity_drift(self):
        pin = executor.Pin("synthetic", 3, "a" * 64)
        with patch.object(stage, "safe_path", return_value=self.root / "synthetic"):
            with patch.object(executor, "_digest", return_value=((1, 2, 3, 4), "b" * 64)):
                with self.assertRaisesRegex(stage.Stop, "INPUT_PIN"):
                    executor._verify_inputs(self.root, {pin.name: pin})
            with patch.object(executor, "_digest", return_value=((1, 2, 3, 4), "a" * 64)):
                with self.assertRaisesRegex(stage.Stop, "INPUT_IDENTITY"):
                    executor._verify_inputs(self.root, {pin.name: pin}, {pin.name: (1, 9, 3, 4)})

    def test_zero_byte_public_tool_pin_retains_hash_guard(self):
        digest = stage.sha256(b"")
        pin = executor.Pin("qemu-test-tools/empty.cache", 0, digest, 4)
        safe = lambda r, n, exists=True: r / n
        with patch.object(stage, "safe_path", side_effect=safe):
            _, admitted = executor._admit(self.root, self.admission(pins=self.admission().pins + (pin,)))
            self.assertEqual(admitted[pin.name], pin)
            negative = executor.Pin(pin.name, -1, digest, 4)
            with self.assertRaisesRegex(stage.Stop, "ADMISSION_PIN_SCHEMA"):
                executor._admit(self.root, self.admission(pins=self.admission().pins + (negative,)))
        with patch.object(stage, "safe_path", side_effect=safe), \
                patch.object(stage, "load_public_pin_chain", return_value={}), \
                patch.object(stage, "BOOTSTRAP_PINS", {}), \
                patch.object(executor, "_digest", return_value=((1, 2, 0, 4), digest)):
            self.assertEqual(executor._verify_inputs(self.root, {pin.name: pin})[pin.name], (1, 2, 0, 4))
            wrong = executor.Pin(pin.name, 0, "b" * 64, 4)
            with self.assertRaisesRegex(stage.Stop, "INPUT_PIN"):
                executor._verify_inputs(self.root, {wrong.name: wrong})


    def test_artifact_inode_size_and_link_drift(self):
        for changes in ({"st_ino": 9}, {"st_size": 5}, {"st_nlink": 2}):
            fields = dict(st_dev=1, st_ino=2, st_size=3, st_mtime_ns=4, st_nlink=1)
            fields.update(changes)
            with patch.object(stage, "safe_path", return_value=self.root / "synthetic"):
                with patch.object(executor.os, "stat", return_value=SimpleNamespace(**fields)):
                    with self.assertRaisesRegex(stage.Stop, "ARTIFACT_IDENTITY"):
                        executor._artifact_identity(self.root, "synthetic", (1, 2, 3, 4), 3)

    def run_transport(self, scenario):
        child = SyntheticChild(stage.qemu_argv(self.root), scenario)
        now = [0.0]
        write_times = []
        original_write = child.write

        def write(data):
            write_times.append(now[0])
            return original_write(data)

        child.stdin.write = write
        with contextlib.ExitStack() as stack:
            launch = stack.enter_context(patch.object(executor.subprocess, "Popen", return_value=child))
            stack.enter_context(patch.object(executor.os, "set_blocking"))
            stack.enter_context(patch.object(executor.os, "read", side_effect=child.read))
            stack.enter_context(patch.object(executor.time, "monotonic", side_effect=lambda: now[0]))
            stack.enter_context(patch.object(executor.time, "sleep", side_effect=lambda delay: now.__setitem__(0, now[0] + delay)))
            stack.enter_context(patch.dict(executor.PROFILE, seconds=3 if scenario == "timeout" else 600,
                                          log_bytes=8192 if scenario == "overflow" else 4 * stage.MIB))
            try:
                result = executor._run(self.root, io.BytesIO())
            finally:
                self.last_child = child
                self.assertEqual(launch.call_count, 1)
        return result, write_times

    def test_transport_clean_closeout_and_pacing(self):
        (serial, code), times = self.run_transport("ok")
        self.assertEqual(code, 0)
        self.assertIn(stage.SUCCESS, serial)
        self.assertFalse(self.last_child.terminated)
        self.assertTrue(all(len(chunk) <= 4 for chunk in self.last_child.writes))
        self.assertTrue(all(b - a >= 0.2 for a, b in zip(times, times[1:])))

    def test_r6_guest_failure_survives_forged_success_and_clean_process_exit(self):
        with self.assertRaisesRegex(stage.Stop, "^SERIAL_CHECK_FAIL:SOURCE_MOUNT$"):
            self.run_transport("guest-check-fail")
        self.assertEqual(self.last_child.poll(), 0)

    def test_r6_serial_accepts_only_unique_ordered_prefix_values(self):
        valid = b"\r\n".join((stage.LIVE, stage.SUCCESS, stage.EXIT)) + b"\r\n"
        self.assertIsNone(executor._validate_serial(valid))
        for conflicting in (b"PUBLIC_STAGE_R6_STATUS=FAIL", b"PUBLIC_STAGE_R6_LIVE=wrong",
                            b"PUBLIC_STAGE_R6_EXIT=1", stage.SUCCESS):
            with self.subTest(conflicting=conflicting), self.assertRaisesRegex(stage.Stop, "^SERIAL_STATUS$"):
                executor._validate_serial(valid + conflicting + b"\n")
        with self.assertRaisesRegex(stage.Stop, "^SERIAL_STATUS_ORDER$"):
            executor._validate_serial(b"\n".join((stage.SUCCESS, stage.LIVE, stage.EXIT)))

    def test_r6_failure_labels_are_bounded_untrusted_diagnostics(self):
        prefix = b"PUBLIC_STAGE_R6_CHECK_FAIL="
        valid = b"\n".join((stage.LIVE, stage.SUCCESS, stage.EXIT)) + b"\n"
        for labels in ((b"bad label",), (b"A"*65,), (b"SOURCE_MOUNT", b"SOURCE_MOUNT"), (b"\xff",)):
            serial = valid + b"\n".join(prefix + label for label in labels)
            with self.subTest(labels=labels), self.assertRaisesRegex(stage.Stop, "^SERIAL_CHECK_FAIL$"):
                executor._validate_serial(serial)

    def test_r6_serial_input_type_and_size_bound(self):
        for serial in ("not bytes", bytearray(), b"x"*(executor.PROFILE["log_bytes"]+1)):
            with self.subTest(type=type(serial).__name__), self.assertRaisesRegex(stage.Stop, "^SERIAL_BOUND$"):
                executor._validate_serial(serial)

    def test_fixed_line_reader_handoff_is_literal_and_newline_terminated(self):
        self.assertEqual(
            executor.TERMINAL_HANDSHAKE,
            b"exec /bin/sh -c 'while IFS= read -r l; do eval \"$l\"; done'\n",
        )

    def test_no_prompt_line_echo_and_exact_ready_before_long_command(self):
        for scenario in ("ok", "marker-lf", "marker-split"):
            with self.subTest(scenario=scenario):
                (serial, code), _ = self.run_transport(scenario)
                self.assertEqual(code, 0)
                self.assertIn(b"localhost:~# \x1b[6n", serial)
                self.assertEqual(self.last_child.commands,
                                 [b"root\n", executor.TERMINAL_HANDSHAKE, executor.READY_COMMAND,
                                  stage.serial_command().encode("ascii") + b"\n"])
                normalized = serial.replace(b"\r", b"")
                self.assertIn(executor.TERMINAL_HANDSHAKE + executor.READY_COMMAND +
                              executor.READY_MARKER + b"\n", normalized)
                self.assertNotIn(b"poweroff\n", self.last_child.commands)

    def test_term_only_reproduces_r1_second_dsr_without_marker_or_long_command(self):
        with patch.object(executor, "TERMINAL_HANDSHAKE", b"export TERM=dumb\n"):
            with self.assertRaisesRegex(stage.Stop, "TERMINAL_HANDSHAKE"):
                self.run_transport("ok")
        self.assertEqual(self.last_child.commands, [b"root\n", b"export TERM=dumb\n"])
        self.assertIsNotNone(self.last_child.poll())

    def test_actual_r2_emacs_error_rejected_without_marker_or_long_command(self):
        legacy = b"set +o emacs; export TERM=dumb\n"
        with patch.object(executor, "TERMINAL_HANDSHAKE", legacy):
            with self.assertRaisesRegex(stage.Stop, "TERMINAL_HANDSHAKE"):
                self.run_transport("ok")
        self.assertEqual(self.last_child.commands, [b"root\n", legacy])
        self.assertIsNotNone(self.last_child.poll())

    def test_exec_error_prompt_dsr_and_ansi_rejected_before_marker(self):
        for scenario in ("exec-error", "exec-prompt", "exec-dsr", "exec-prompt-dsr",
                         "exec-ansi", "exec-dsr-fragment", "exec-error-fragment"):
            with self.subTest(scenario=scenario):
                with self.assertRaisesRegex(stage.Stop, "TERMINAL_HANDSHAKE"):
                    self.run_transport(scenario)
                self.assertEqual(self.last_child.commands, [b"root\n", executor.TERMINAL_HANDSHAKE])
                self.assertEqual(self.last_child.pending, b"")
                self.assertIsNotNone(self.last_child.poll())

    def test_exec_exact_echo_is_required_before_marker(self):
        with self.assertRaisesRegex(stage.Stop, "SERIAL_ECHO"):
            self.run_transport("exec-echo")
        self.assertEqual(self.last_child.commands, [b"root\n", executor.TERMINAL_HANDSHAKE])
        self.assertIsNotNone(self.last_child.poll())

    def test_marker_error_extra_prompt_dsr_and_duplicates_rejected_before_long_command(self):
        for scenario in ("marker-error", "marker-wrong", "marker-extra", "marker-duplicate",
                         "marker-prompt", "marker-dsr", "marker-dsr-fragment",
                         "marker-error-fragment"):
            with self.subTest(scenario=scenario):
                with self.assertRaisesRegex(stage.Stop, "TERMINAL_HANDSHAKE"):
                    self.run_transport(scenario)
                self.assertEqual(self.last_child.commands,
                                 [b"root\n", executor.TERMINAL_HANDSHAKE, executor.READY_COMMAND])
                self.assertEqual(self.last_child.pending, b"")
                self.assertIsNotNone(self.last_child.poll())

    def test_marker_exact_echo_is_required_before_long_command(self):
        with self.assertRaisesRegex(stage.Stop, "SERIAL_ECHO"):
            self.run_transport("marker-echo")
        self.assertEqual(self.last_child.commands,
                         [b"root\n", executor.TERMINAL_HANDSHAKE, executor.READY_COMMAND])
        self.assertIsNotNone(self.last_child.poll())



    def test_exited_process_tail_is_drained_through_eof_without_second_poweroff(self):
        (serial, code), _ = self.run_transport("tail")
        self.assertEqual(code, 0)
        self.assertTrue(serial.endswith(b"shutdown diagnostic tail\r\n"))
        self.assertFalse(self.last_child.terminated)
        self.assertNotIn(b"poweroff\n", self.last_child.commands)

    def test_stdout_eof_does_not_closeout_until_process_exits(self):
        (serial, code), _ = self.run_transport("eof-first")
        self.assertEqual(code, 0)
        self.assertGreaterEqual(self.last_child.exit_polls, 3)
        self.assertFalse(self.last_child.terminated)

    def test_transport_timeout_overflow_identity_echo_and_failed_exit(self):
        for scenario, error in (("timeout", "TIMEOUT"), ("overflow", "LOG_OVERFLOW"),
                                ("identity", "PROCESS_IDENTITY"), ("echo", "SERIAL_ECHO"),
                                ("exit", "QEMU_EXIT")):
            with self.subTest(scenario=scenario), self.assertRaisesRegex(stage.Stop, error):
                self.run_transport(scenario)
            self.assertIsNotNone(self.last_child.poll())

    def pipeline(self, failure=None):
        opened = {}
        verifies = [0]

        def exclusive(root, name):
            opened[name] = MemoryFile()
            return opened[name]

        def verify(*args):
            verifies[0] += 1
            if failure == "postpins" and verifies[0] >= 3:
                raise stage.Stop("INPUT_PIN:synthetic")
            return {}

        artifacts = stage.Artifacts(b"k", b"i", stage.sha256(b"k"), stage.sha256(b"i"))
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(executor, "_admit", return_value=(self.root, {})))
            stack.enter_context(patch.object(executor, "_verify_inputs", side_effect=verify))
            stack.enter_context(patch.object(executor, "_exclusive", side_effect=exclusive))
            stack.enter_context(patch.object(executor.os, "fsync"))
            stack.enter_context(patch.object(executor, "_create_disks", return_value={stage.SCRIPT_DISK: (), stage.OUTPUT: ()}))
            stack.enter_context(patch.object(executor, "_artifact_identity", return_value=self.root / "synthetic"))
            stack.enter_context(patch.object(executor, "_digest", return_value=((), stage.sha256(stage.render_script_disk()))))
            runner = stack.enter_context(patch.object(executor, "_run", return_value=(b"synthetic", 0)))
            if failure == "exit":
                runner.side_effect = stage.Stop("QEMU_EXIT")
            stack.enter_context(patch.object(executor, "_read_output", return_value=b"synthetic"))
            parser = stack.enter_context(patch.object(stage, "parse_output", return_value=artifacts))
            if failure == "malformed":
                parser.side_effect = stage.Stop("HEADER_SCHEMA")
            result = executor.execute(self.root, object())
        self.assertEqual(json.loads(opened[stage.OUTPUT_NAMES[3]].saved), result)
        return result, opened, parser

    def test_failed_exit_postpins_and_malformed_never_extract(self):
        for failure in ("exit", "postpins", "malformed"):
            result, opened, parser = self.pipeline(failure)
            self.assertEqual(result["status"], "FAILED")
            self.assertNotIn(stage.OUTPUT_NAMES[4], opened)
            self.assertNotIn(stage.OUTPUT_NAMES[5], opened)
            if failure != "malformed":
                parser.assert_not_called()

    def test_success_extracts_only_public_stage_no_boot_or_restore_claim(self):
        result, opened, parser = self.pipeline()
        self.assertEqual(result["status"], "PUBLIC_STAGE_ONLY_OK")
        self.assertTrue(result["clean_closeout"])
        self.assertTrue(result["post_pins_verified"])
        self.assertFalse(result["restore_acceptance"])
        self.assertFalse(result["installed_boot_acceptance"])
        self.assertEqual(opened[stage.OUTPUT_NAMES[4]].saved, b"k")
        self.assertEqual(opened[stage.OUTPUT_NAMES[5]].saved, b"i")


if __name__ == "__main__":
    unittest.main()
