Public-source checkpoint only; no operation admission, VM image, backup or provider configuration.
The R6 stage/executor/caller are fixed-profile tools, not a general VM runner.
Verify SOURCE-MANIFEST.json before use. Source hashes are the reviewed identities.
To reproduce the recorded tests on the original host, place source files in the
original isolated test directory named in run_integration_tests.py and run that
test runner with trusted Python 3.14 using -I -S -B. It compiles source bytes and
mocks child execution. Do not run the operation caller without a separately
reviewed fresh plan, exact tool/input pins and absent output paths.
The retained R4 stage is comparison evidence for the immutable R6 preparation tests.
The source archive does not establish installed boot, private restore or live release.
