<?php
/**
 * Settings access helpers.
 *
 * @package DoughBoss
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Thin wrapper around the doughboss_settings option.
 *
 * Centralises reads so the rest of the plugin never has to know the option
 * shape, and provides typed getters with sane fallbacks.
 */
class DoughBoss_Settings {

	const OPTION_KEY = 'doughboss_settings';

	/**
	 * Return the full settings array merged over defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return wp_parse_args( $stored, self::defaults() );
	}

	/**
	 * Get a single setting by key.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback when the key is absent.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Merge a partial array of settings into the stored option (preserving the
	 * keys not supplied) and persist. Used by programmatic config writers such
	 * as the POSPal connect endpoint.
	 *
	 * @param array $partial Keys to set/overwrite.
	 * @return array The merged settings now stored.
	 */
	public static function update( array $partial ) {
		$current = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}
		$merged = array_merge( $current, $partial );
		update_option( self::OPTION_KEY, $merged );
		return $merged;
	}

	/**
	 * Default settings used when nothing is stored yet.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'currency_symbol' => '$',
			'currency_code'   => 'AUD',
			'tax_rate'        => 10,
			'gst_inclusive'   => 1,
			'delivery_fee'    => 0,
			'enable_pickup'   => 1,
			'enable_delivery' => 0,
			'ordering_open'   => 1,
			'sizes'           => array(),
			'toppings'        => array(),
			// Payments (Stripe) — off by default; keys added later.
			'payments_enabled' => 0,
			'stripe_mode'      => 'test',
			'stripe_test_pk'   => '',
			'stripe_test_sk'   => '',
			'stripe_live_pk'   => '',
			'stripe_live_sk'   => '',
			'stripe_test_whsec' => '',
			'stripe_live_whsec' => '',
			// POSPal POS (Open Platform) — off by default; Revesby store for the pilot.
			// The secret appKey is read env-first (DOUGHBOSS_POSPAL_APPKEY constant/env);
			// this option is only a fallback and is best left blank where env is set.
			'pospal_enabled'    => 0,
			'pospal_host'       => '',
			'pospal_app_id'     => '',
			'pospal_app_key'    => '',
			// POSPal coupon-rule mapping: which POSPal coupon (优惠券) rule UID
			// represents the $5 / $10 student vouchers. Blank = grant disabled for
			// that value (the GRANT leg is dormant until at least one is set).
			'pospal_coupon_uid_5'  => '',
			'pospal_coupon_uid_10' => '',
			// Standalone staff console (separate origin, e.g. GitHub Pages) allowed
			// to call the doughboss/v1 routes cross-origin via Application Password.
			'app_origin'        => 'https://edagher92-coder.github.io',
			// Real-time push (Mercure hub) — off by default. The publish JWT is a
			// secret, read env-first (DOUGHBOSS_MERCURE_PUBLISH_JWT); this option is
			// only a fallback and is best left blank where env is set.
			'mercure_enabled'       => 0,
			'mercure_hub_url'       => '',
			'mercure_publish_jwt'   => '',
			'mercure_subscribe_jwt' => '',
			'mercure_topic_prefix'  => 'doughboss',
			// ntfy push notifications — off by default. The bearer token is a secret,
			// read env-first (DOUGHBOSS_NTFY_TOKEN); this option is only a fallback.
			'ntfy_enabled'  => 0,
			'ntfy_server'   => 'https://ntfy.sh',
			'ntfy_topic'    => '',
			'ntfy_token'    => '',
			'ntfy_priority' => 'high',
			// SMS (ClickSend) — off by default. The API key is a secret, read
			// env-first (DOUGHBOSS_CLICKSEND_API_KEY); this option is only a fallback.
			'sms_enabled'           => 0,
			'clicksend_username'    => '',
			'clicksend_api_key'     => '',
			'sms_from'              => '',
			'sms_on_ready'          => 1,
			'sms_on_voucher_claim'  => 0,
			// Receipt printer (CloudPRNT / ePOS) — off by default. The shared token
			// is a secret, read env-first (DOUGHBOSS_PRINTER_TOKEN); this option is
			// only a fallback.
			'printer_enabled'  => 0,
			'printer_protocol' => 'cloudprnt',
			'printer_token'    => '',
			'printer_width'    => 48,
		);
	}

	/**
	 * Allowed origin for the standalone staff console (CORS). Empty disables
	 * cross-origin access. Filterable via 'doughboss_app_origin'.
	 *
	 * @return string
	 */
	public static function app_origin() {
		return untrailingslashit( (string) apply_filters( 'doughboss_app_origin', self::get( 'app_origin', '' ) ) );
	}

	/**
	 * Whether prices already include tax (GST-inclusive, the Australian norm).
	 *
	 * @return bool
	 */
	public static function gst_inclusive() {
		return (bool) self::get( 'gst_inclusive', 1 );
	}

	/**
	 * Configured pizza sizes.
	 *
	 * @return array[] List of array{slug:string,label:string,price:float}.
	 */
	public static function sizes() {
		$sizes = self::get( 'sizes', array() );
		return is_array( $sizes ) ? array_values( $sizes ) : array();
	}

	/**
	 * Configured toppings.
	 *
	 * @return array[] List of array{slug:string,label:string,price:float}.
	 */
	public static function toppings() {
		$toppings = self::get( 'toppings', array() );
		return is_array( $toppings ) ? array_values( $toppings ) : array();
	}

	/**
	 * Look up a single size definition by slug.
	 *
	 * @param string $slug Size slug.
	 * @return array|null
	 */
	public static function find_size( $slug ) {
		foreach ( self::sizes() as $size ) {
			if ( isset( $size['slug'] ) && $size['slug'] === $slug ) {
				return $size;
			}
		}
		return null;
	}

	/**
	 * Look up a single topping definition by slug.
	 *
	 * @param string $slug Topping slug.
	 * @return array|null
	 */
	public static function find_topping( $slug ) {
		foreach ( self::toppings() as $topping ) {
			if ( isset( $topping['slug'] ) && $topping['slug'] === $slug ) {
				return $topping;
			}
		}
		return null;
	}

	/**
	 * Tax rate as a fraction (e.g. 8.25% -> 0.0825).
	 *
	 * @return float
	 */
	public static function tax_fraction() {
		return (float) self::get( 'tax_rate', 0 ) / 100;
	}

	/**
	 * Is online ordering currently accepting orders?
	 *
	 * @return bool
	 */
	public static function ordering_open() {
		return (bool) self::get( 'ordering_open', 1 );
	}

	/**
	 * Format a numeric amount for display using the configured symbol.
	 *
	 * @param float $amount Amount.
	 * @return string
	 */
	public static function format_price( $amount ) {
		$symbol = self::get( 'currency_symbol', '$' );
		return $symbol . number_format( (float) $amount, 2 );
	}

	/**
	 * Whether online card payments are switched on by the operator.
	 *
	 * @return bool
	 */
	public static function payments_enabled() {
		return (bool) self::get( 'payments_enabled', 0 );
	}

	/**
	 * Active Stripe mode: 'test' or 'live'.
	 *
	 * @return string
	 */
	public static function stripe_mode() {
		return 'live' === self::get( 'stripe_mode', 'test' ) ? 'live' : 'test';
	}

	/**
	 * Stripe publishable key for the active mode.
	 *
	 * @return string
	 */
	public static function stripe_publishable_key() {
		return (string) self::get( 'live' === self::stripe_mode() ? 'stripe_live_pk' : 'stripe_test_pk', '' );
	}

	/**
	 * Stripe secret key for the active mode.
	 *
	 * @return string
	 */
	public static function stripe_secret_key() {
		return (string) self::get( 'live' === self::stripe_mode() ? 'stripe_live_sk' : 'stripe_test_sk', '' );
	}

	/**
	 * Stripe webhook signing secret for the active mode (server-side only).
	 *
	 * @return string
	 */
	public static function stripe_webhook_secret() {
		return (string) self::get( 'live' === self::stripe_mode() ? 'stripe_live_whsec' : 'stripe_test_whsec', '' );
	}

	/**
	 * Whether Stripe is both enabled and fully configured for the active mode
	 * (so the storefront should actually collect card payment).
	 *
	 * @return bool
	 */
	public static function stripe_ready() {
		return self::payments_enabled() && '' !== self::stripe_publishable_key() && '' !== self::stripe_secret_key();
	}

	/**
	 * Whether the POSPal POS integration is switched on by the operator.
	 *
	 * @return bool
	 */
	public static function pospal_enabled() {
		return (bool) self::get( 'pospal_enabled', 0 );
	}

	/**
	 * POSPal area host, trailing slash removed (e.g. https://area28-win.pospal.cn:443).
	 *
	 * @return string
	 */
	public static function pospal_host() {
		return untrailingslashit( (string) self::get( 'pospal_host', '' ) );
	}

	/**
	 * POSPal public application id.
	 *
	 * @return string
	 */
	public static function pospal_app_id() {
		return (string) self::get( 'pospal_app_id', '' );
	}

	/**
	 * POSPal secret application key. Read env-first — the constant
	 * DOUGHBOSS_POSPAL_APPKEY or the matching environment variable take
	 * precedence over the stored option, so the secret can be kept out of the
	 * database (and therefore out of backups). Only ever used server-side to
	 * sign requests; never echoed to a client.
	 *
	 * @return string
	 */
	public static function pospal_app_key() {
		if ( defined( 'DOUGHBOSS_POSPAL_APPKEY' ) && '' !== (string) DOUGHBOSS_POSPAL_APPKEY ) {
			return (string) DOUGHBOSS_POSPAL_APPKEY;
		}
		$env = getenv( 'DOUGHBOSS_POSPAL_APPKEY' );
		if ( false !== $env && '' !== $env ) {
			return (string) $env;
		}
		return (string) self::get( 'pospal_app_key', '' );
	}

	/**
	 * Whether POSPal is both enabled and fully configured (host + appId + appKey).
	 *
	 * @return bool
	 */
	public static function pospal_ready() {
		return self::pospal_enabled() && '' !== self::pospal_host() && '' !== self::pospal_app_id() && '' !== self::pospal_app_key();
	}

	/**
	 * POSPal coupon-rule UID mapped to the $5 voucher (blank when unmapped).
	 *
	 * @return string
	 */
	public static function pospal_coupon_uid_5() {
		return (string) self::get( 'pospal_coupon_uid_5', '' );
	}

	/**
	 * POSPal coupon-rule UID mapped to the $10 voucher (blank when unmapped).
	 *
	 * @return string
	 */
	public static function pospal_coupon_uid_10() {
		return (string) self::get( 'pospal_coupon_uid_10', '' );
	}

	/**
	 * Map a dollar voucher value to the configured POSPal coupon-rule UID.
	 *
	 * Only the pilot's $5 and $10 student vouchers are mapped today; any other
	 * value returns '' (no rule), which the grant flow treats as "skip — nothing
	 * to grant in POSPal".
	 *
	 * @param int|float|string $value Voucher dollar value (e.g. 5, 10, '5.00').
	 * @return string The mapped coupon-rule UID, or '' when none is configured.
	 */
	public static function pospal_coupon_uid_for( $value ) {
		$dollars = (int) round( (float) $value );
		switch ( $dollars ) {
			case 5:
				return self::pospal_coupon_uid_5();
			case 10:
				return self::pospal_coupon_uid_10();
			default:
				return '';
		}
	}

	/**
	 * Whether the POSPal coupon-GRANT leg should run: POSPal is fully configured
	 * AND at least one coupon-rule UID is mapped. When false the whole grant/revoke
	 * sync stays dormant and voucher claims behave exactly as before.
	 *
	 * @return bool
	 */
	public static function pospal_grant_enabled() {
		return self::pospal_ready() && ( '' !== self::pospal_coupon_uid_5() || '' !== self::pospal_coupon_uid_10() );
	}

	/**
	 * Whether the Mercure real-time push integration is switched on by the operator.
	 *
	 * @return bool
	 */
	public static function mercure_enabled() {
		return (bool) self::get( 'mercure_enabled', 0 );
	}

	/**
	 * Mercure hub URL, trailing slash removed (e.g. https://hub.example.com/.well-known/mercure).
	 *
	 * @return string
	 */
	public static function mercure_hub_url() {
		return untrailingslashit( (string) self::get( 'mercure_hub_url', '' ) );
	}

	/**
	 * Mercure publisher JWT. Read env-first — the constant
	 * DOUGHBOSS_MERCURE_PUBLISH_JWT or the matching environment variable take
	 * precedence over the stored option, so the secret can be kept out of the
	 * database (and therefore out of backups). Only ever used server-side to
	 * authenticate publishes to the hub; never echoed to a client.
	 *
	 * @return string
	 */
	public static function mercure_publish_jwt() {
		if ( defined( 'DOUGHBOSS_MERCURE_PUBLISH_JWT' ) && '' !== (string) DOUGHBOSS_MERCURE_PUBLISH_JWT ) {
			return (string) DOUGHBOSS_MERCURE_PUBLISH_JWT;
		}
		$env = getenv( 'DOUGHBOSS_MERCURE_PUBLISH_JWT' );
		if ( false !== $env && '' !== $env ) {
			return (string) $env;
		}
		return (string) self::get( 'mercure_publish_jwt', '' );
	}

	/**
	 * Mercure subscriber JWT, handed to browser clients so they may subscribe to
	 * topics. Not a publish credential, so it is read from the stored option.
	 *
	 * @return string
	 */
	public static function mercure_subscribe_jwt() {
		return (string) self::get( 'mercure_subscribe_jwt', '' );
	}

	/**
	 * Prefix used when composing Mercure topic URIs/names.
	 *
	 * @return string
	 */
	public static function mercure_topic_prefix() {
		return (string) self::get( 'mercure_topic_prefix', 'doughboss' );
	}

	/**
	 * Whether Mercure is both enabled and the minimum config (hub URL + publish
	 * JWT) is present, so the server should actually publish real-time updates.
	 *
	 * @return bool
	 */
	public static function mercure_ready() {
		return self::mercure_enabled() && '' !== self::mercure_hub_url() && '' !== self::mercure_publish_jwt();
	}

	/**
	 * Whether the ntfy push-notification integration is switched on by the operator.
	 *
	 * @return bool
	 */
	public static function ntfy_enabled() {
		return (bool) self::get( 'ntfy_enabled', 0 );
	}

	/**
	 * ntfy server base URL, trailing slash removed (default https://ntfy.sh).
	 *
	 * @return string
	 */
	public static function ntfy_server() {
		$server = untrailingslashit( (string) self::get( 'ntfy_server', 'https://ntfy.sh' ) );
		return '' !== $server ? $server : 'https://ntfy.sh';
	}

	/**
	 * ntfy topic to publish to (blank when unconfigured).
	 *
	 * @return string
	 */
	public static function ntfy_topic() {
		return (string) self::get( 'ntfy_topic', '' );
	}

	/**
	 * ntfy bearer token. Read env-first — the constant DOUGHBOSS_NTFY_TOKEN or the
	 * matching environment variable take precedence over the stored option, so the
	 * secret can be kept out of the database (and therefore out of backups). Only
	 * ever used server-side to authenticate publishes; never echoed to a client.
	 *
	 * @return string
	 */
	public static function ntfy_token() {
		if ( defined( 'DOUGHBOSS_NTFY_TOKEN' ) && '' !== (string) DOUGHBOSS_NTFY_TOKEN ) {
			return (string) DOUGHBOSS_NTFY_TOKEN;
		}
		$env = getenv( 'DOUGHBOSS_NTFY_TOKEN' );
		if ( false !== $env && '' !== $env ) {
			return (string) $env;
		}
		return (string) self::get( 'ntfy_token', '' );
	}

	/**
	 * ntfy message priority (default 'high').
	 *
	 * @return string
	 */
	public static function ntfy_priority() {
		return (string) self::get( 'ntfy_priority', 'high' );
	}

	/**
	 * Whether ntfy is both enabled and a topic is configured, so the server should
	 * actually publish notifications.
	 *
	 * @return bool
	 */
	public static function ntfy_ready() {
		return self::ntfy_enabled() && '' !== self::ntfy_topic();
	}

	/**
	 * Whether the SMS (ClickSend) integration is switched on by the operator.
	 *
	 * @return bool
	 */
	public static function sms_enabled() {
		return (bool) self::get( 'sms_enabled', 0 );
	}

	/**
	 * ClickSend account username.
	 *
	 * @return string
	 */
	public static function clicksend_username() {
		return (string) self::get( 'clicksend_username', '' );
	}

	/**
	 * ClickSend API key. Read env-first — the constant DOUGHBOSS_CLICKSEND_API_KEY
	 * or the matching environment variable take precedence over the stored option,
	 * so the secret can be kept out of the database (and therefore out of backups).
	 * Only ever used server-side to authenticate the API; never echoed to a client.
	 *
	 * @return string
	 */
	public static function clicksend_api_key() {
		if ( defined( 'DOUGHBOSS_CLICKSEND_API_KEY' ) && '' !== (string) DOUGHBOSS_CLICKSEND_API_KEY ) {
			return (string) DOUGHBOSS_CLICKSEND_API_KEY;
		}
		$env = getenv( 'DOUGHBOSS_CLICKSEND_API_KEY' );
		if ( false !== $env && '' !== $env ) {
			return (string) $env;
		}
		return (string) self::get( 'clicksend_api_key', '' );
	}

	/**
	 * The sender ID / from-number used for outbound SMS.
	 *
	 * @return string
	 */
	public static function sms_from() {
		return (string) self::get( 'sms_from', '' );
	}

	/**
	 * Whether to text the customer when their order is marked ready (default on).
	 *
	 * @return bool
	 */
	public static function sms_on_ready() {
		return (bool) self::get( 'sms_on_ready', 1 );
	}

	/**
	 * Whether to text the voucher code to the customer when a voucher is claimed
	 * (default off).
	 *
	 * @return bool
	 */
	public static function sms_on_voucher_claim() {
		return (bool) self::get( 'sms_on_voucher_claim', 0 );
	}

	/**
	 * Whether SMS is both enabled and fully configured (username + API key), so
	 * the server should actually send messages.
	 *
	 * @return bool
	 */
	public static function sms_ready() {
		return self::sms_enabled() && '' !== self::clicksend_username() && '' !== self::clicksend_api_key();
	}

	/**
	 * Whether the receipt-printer integration is switched on by the operator.
	 *
	 * @return bool
	 */
	public static function printer_enabled() {
		return (bool) self::get( 'printer_enabled', 0 );
	}

	/**
	 * Receipt printer protocol: 'cloudprnt' or 'epos' (default 'cloudprnt').
	 *
	 * @return string
	 */
	public static function printer_protocol() {
		return 'epos' === self::get( 'printer_protocol', 'cloudprnt' ) ? 'epos' : 'cloudprnt';
	}

	/**
	 * Receipt printer shared token. Read env-first — the constant
	 * DOUGHBOSS_PRINTER_TOKEN or the matching environment variable take precedence
	 * over the stored option, so the secret can be kept out of the database (and
	 * therefore out of backups). Used to authenticate the printer/poll exchange;
	 * never echoed to a client.
	 *
	 * @return string
	 */
	public static function printer_token() {
		if ( defined( 'DOUGHBOSS_PRINTER_TOKEN' ) && '' !== (string) DOUGHBOSS_PRINTER_TOKEN ) {
			return (string) DOUGHBOSS_PRINTER_TOKEN;
		}
		$env = getenv( 'DOUGHBOSS_PRINTER_TOKEN' );
		if ( false !== $env && '' !== $env ) {
			return (string) $env;
		}
		return (string) self::get( 'printer_token', '' );
	}

	/**
	 * Receipt width in characters (default 48 for an 80mm roll).
	 *
	 * @return int
	 */
	public static function printer_width() {
		return (int) self::get( 'printer_width', 48 );
	}

	/**
	 * Whether the printer is both enabled and a shared token is set, so the server
	 * should actually emit receipts.
	 *
	 * @return bool
	 */
	public static function printer_ready() {
		return self::printer_enabled() && '' !== self::printer_token();
	}
}
